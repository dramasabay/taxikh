<?php

use App\Http\Middleware\Locale;
use App\Http\Middleware\SecurityHeaders;
use App\Http\Middleware\SiteMaintenance;
use App\Http\Middleware\StaffAccess;
use App\Http\Middleware\TrackPageHistory;
use App\Http\Middleware\TrustedProxies;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Session\Middleware\StartSession;

$runtimeDirectories = [
    dirname(__DIR__).'/bootstrap/cache',
    dirname(__DIR__).'/storage/app/public',
    dirname(__DIR__).'/storage/framework/cache/data',
    dirname(__DIR__).'/storage/framework/sessions',
    dirname(__DIR__).'/storage/framework/views',
    dirname(__DIR__).'/storage/logs',
];

foreach ($runtimeDirectories as $runtimeDirectory) {
    if (! is_dir($runtimeDirectory)) {
        mkdir($runtimeDirectory, 0775, true);
    }
}

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', api: __DIR__.'/../routes/api.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $m): void {
        $m->trustHosts(at: fn () => array_map(
            fn (string $host) => '^'.preg_quote($host, '/').'$',
            config('security.allowed_hosts', [])
        ), subdomains: false);
        $m->replace(\Illuminate\Http\Middleware\TrustProxies::class, TrustedProxies::class);
        $m->alias(['locale' => Locale::class, 'staff' => StaffAccess::class]);
        $m->append(SecurityHeaders::class);
        $m->append(SiteMaintenance::class);
        $m->web(replace: [StartSession::class => TrackPageHistory::class]);
        $m->redirectGuestsTo('/staff/login');
    })
    ->withExceptions(function (Exceptions $e): void {
        $e->shouldRenderJsonWhen(fn (Request $r) => $r->is('api/*') || $r->expectsJson());
        $e->dontFlash(['current_password', 'password', 'password_confirmation', 'telegram_bot_token', 'google_maps_api_key']);
    })->create();
