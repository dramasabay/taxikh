# TAXIKH — PHP taxi booking platform

Version **2.0**, for **taxikh.com**. PHP / Laravel 13, MySQL or MariaDB, Blade, CSS and vanilla JavaScript AJAX. English, Khmer and Simplified Chinese. PHP dependencies are included; no npm build is required.

Customers book without logging in and **pay cash on arrival**. There is no checkout or online payment page. Demo routes, fares and illustrations are starter content: replace them with the client's actual services before opening bookings.

For self-hosting with Docker and an existing Nginx Proxy Manager, use [Docker hosting](docs/DOCKER-HOSTING.md). See [security review and fixes](docs/SECURITY-REVIEW.md) for the latest checks and deployment limits.

## Update your existing Laragon installation

1. Stop `START-WEBSITE.bat` and `START-NOTIFICATIONS.bat`. Back up the existing project folder and database.
2. Copy the contents of this ZIP's **mekong-ride** folder over your existing project. Keep the existing **.env, APP_KEY, database and storage/app/public uploads**. The folder name stays unchanged to make upgrading easier.
3. Run **UPDATE-LARAGON.bat** from Laragon Terminal. It runs migrations and adds missing defaults without replacing existing bookings, staff, custom prices or uploads.
4. Restart **START-WEBSITE.bat** and **START-NOTIFICATIONS.bat**. Refresh the browser; CSS/JS URLs include versions to avoid old cached files.
5. Open **/staff/login**. The public staff-login link has been removed; bookmark this private entry point.
6. Configure the new controls below. Run **CHECK-ERRORS.bat** if anything fails. It opens `storage/logs/diagnostics.log` and, if present, `storage/logs/laravel.log`.

The starter brand “Mekong Ride” changes to TAXIKH; a previously customized brand is preserved. Existing booking reference numbers remain valid. The update adds the hero and search blocks to the existing homepage order; you can hide/reorder both. Old live Google review fetching is disabled in favor of admin-supplied embeds. Your Google browser key is preserved for optional booking-address suggestions.

## New v2.0 controls

| Task | Dashboard location |
|---|---|
| Route cities, type, price, distance/time, map, description and gallery | Routes → Edit |
| Car images, capacity, category and feature lines | Vehicles → Edit |
| Optional stops, destination, image, price and applicable route | Extras → Add/Edit |
| Hide/reorder homepage sections; choose columns, rows, list/grid and sort | Settings → Homepage |
| Reorder or hide slides, menus, footer links, pages and other content | Content; drag rows or use arrows, then Save order & visibility |
| Google/Tripadvisor embeds and public review links | Settings → Google & Tripadvisor embeds |
| Brand, logo, phone, Telegram username, WhatsApp number and languages | Settings → Branding |
| Canonical domain, SEO titles/descriptions and search indexing | Settings → Search engine settings |
| Maintenance, backups, restore and data clearing | System tools |
| Permanent item removal | Manage list → Delete permanently |

**Route discovery:** From/To offers only cities from active routes with active vehicle fares. Typing “Pnom” can suggest “Phnom Penh”; a listed city must be selected. Destinations follow the selected origin. Home and Routes & tours do not request GPS. Category links filter city transfers, airport transfers and tours. Visitors can sort, choose grid/list, and paginate. Columns × rows controls records per page; smaller screens reduce the number of columns.

**Booking:** Check price carries cities, departure date and departure time into the matching route. If multiple routes match, the customer chooses one from the results. The booking page has vehicle categories/cards, optional image extras, customer details and a final confirmation. Exact pickup/drop-off details remain editable on the booking page. The saved map does not change when these details change. Prices are always recalculated by PHP; changing browser fields cannot change the fare. A sticky mobile price/action bar sits above Home / Booking / Support navigation.

**Brand and design:** Yellow `#FFD801`, bundled Montserrat fonts, Khmer font, dark/light modes, fixed header and flag menus. TAXIKH has original SVG logo/icon files in `public/assets/taxikh-logo.svg` and `taxikh-icon.svg`. Car/route media can be uploaded in the dashboard. Compact support icons link directly to the configured WhatsApp number and Telegram username; empty contact settings hide the corresponding icon.

## Set a fixed map for Phnom Penh → Pailin

1. In **Routes**, create/edit the route. Enter translated origin/destination names, route type, distance, estimated duration and vehicle fares. The city dropdowns use these names.
2. Open Google Maps on a computer, display the place or route, then use **Share → Embed a map → Copy HTML**, when offered for that map. Paste the iframe into **Route map embed** and save.
3. Alternatively, a publicly shared Google My Maps embed URL using `/maps/d/embed?mid=…` is accepted. The map must be accessible without your Google sign-in.
4. Open the route booking page to review it. Repeat for other routes.

This integration accepts Google Maps Share `/maps/embed?pb=…` and public My Maps embeds. It does not use the separate key-based Maps Embed API. The embed is a fixed third-party map, not live driver tracking or automatic distance pricing. What is visible depends on the map you shared; a place pin is not automatically converted to a drawn route. Only the approved HTTPS URL is stored; pasted scripts and iframe event handlers are discarded.

## Google and Tripadvisor reviews

Paste **your own business** embed code under Settings → Google & Tripadvisor embeds, and configure the public review links. Review frames can have a height from 200 to 900 px. Empty settings hide the section; no fake reviews, ratings or award badges are supplied.

Google Maps place embeds display the map/place information. A Google profile/share URL is not a review-carousel iframe: put it in the Google review link field. The old Google Places review API is no longer called. A review carousel requires a supported review widget from its provider; its appearance cannot be reproduced simply by pasting an ordinary Maps URL.

Tripadvisor offers business-specific widgets through its [official Widgets page](https://www.tripadvisor.com/Widgets). The app accepts official `tripadvisor.com/WidgetEmbed…` iframe URLs and the usual `jscache.com/wejs` widget code. Script widgets are reconstructed inside a sandboxed iframe so they cannot access the app's session or page. Provider changes, privacy blocking or unavailable widgets can prevent third-party content loading; the direct review links remain available. Your actual business embed code is needed to verify the live widget.

## Optional Google address autocomplete on booking

The homepage city dropdowns and saved route maps need no API key. Only optional **booking-address Google Places autocomplete/reverse geocoding** uses a browser API key.

Enable Maps JavaScript API, Places API (New), and Geocoding API for GPS-to-address lookup in the client's Google Cloud project. Configure billing and restrict the browser key to the site's origins and required APIs. Set it in **Settings → Optional address autocomplete**. The [Google Maps JavaScript API setup documentation](https://developers.google.com/maps/documentation/javascript/get-api-key) covers key restrictions. Blank key fields retain the saved key.

Manual addresses remain usable without Google. The location button requests one GPS point after the customer taps it; HTTPS or localhost and browser permission are required. A phone opening the PC's plain HTTP LAN address may not allow GPS. The customer's point and the admin's fixed map are separate.

## Backup, restore and maintenance

**Maintenance** pauses the public site and new bookings/inquiries with HTTP 503 and Retry-After. Staff can still sign in. Telegram queue jobs wait during maintenance. Reopen the site from System tools.

**Create backup** requires the administrator's current password. The private ZIP includes an encrypted/authenticated database manifest and uploaded JPG/PNG/WebP/PDF files. It includes bookings, staff accounts/password hashes, settings, catalogue, content and histories. It excludes `.env`, website code, logs, sessions and executable queue payloads. Backups are under `storage/app/private/backups`, downloadable only through the administrator dashboard. Keep the ZIP private and keep `.env`/APP_KEY separately: there is no recovery of encrypted booking links or backups without the original key.

**Restore** requires the same APP_KEY, the same migration/schema version, and the current active admin account in the backup. First enable maintenance, stop the queue worker and pause other staff editing. Upload the ZIP, enter your password, tick the stopped-worker confirmation and type `RESTORE`. The app validates the archive, creates a safety backup, restores media/data, invalidates staff sessions and cancels old pending/failed Telegram deliveries. It does not replay queue payloads. Sign in with the password from the backup. Review the site, switch maintenance off and restart the worker. Keep a matching release ZIP with your backups.

Archive checks reject path traversal, altered encryption, inconsistent schema and modified media. Existing immutable upload paths with conflicting contents are rejected. Database replacement is transactional; schema tables are not dropped and arbitrary SQL is never executed.

**Clear bookings & messages** deletes bookings, trip events, inquiries, dashboard alerts, Telegram delivery history and pending/failed jobs. It keeps staff accounts, settings, routes, vehicles, extras, content and uploaded media. It requires `CLEAR BOOKINGS`.

**Reset catalogue** also deletes routes, vehicle fares, vehicles, extras and CMS content. It keeps staff accounts, settings and uploaded media so the administrator can rebuild. It requires `RESET CATALOGUE`. The empty catalogue does not reseed automatically. Both actions require maintenance, password and stopped-worker confirmation, and create a safety backup before deletion. Building these controls does not itself clear any existing installation.

**Delete permanently** is available on management lists. It needs the administrator password and `DELETE`. Items referenced by bookings and protected staff/history records are retained; use Archive for those. A route's unused route-specific extras are deleted with it. Deleting catalogue content does not erase booking price snapshots.

Dashboard backup limits: 128 MB ZIP upload, up to 200 MB uncompressed media and 40 MB database JSON. Backups exceeding the ZIP limit are rejected; use server/database backup tools for larger installations. A dashboard data backup complements the release ZIP and the separately protected `.env`.

## New Laragon installation

1. Select **PHP 8.3+** and start MySQL. Extract `mekong-ride` to `C:\laragon\www\mekong-ride`.
2. Create database `mekong_ride`, using `utf8mb4`. Use MySQL 8+ or MariaDB 10.11+.
3. In Laragon Terminal:

   ```bat
   cd C:\laragon\www\mekong-ride
   copy .env.example .env
   ```

   Edit the database settings in `.env`. Typical local values:

   ```dotenv
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=mekong_ride
   DB_USERNAME=root
   DB_PASSWORD=
   APP_URL=http://127.0.0.1:8000
   ```

4. Run `INSTALL-LARAGON.bat`, or `php artisan ride:install`. Create your administrator account when prompted. No default staff password is shipped. If necessary, run `php artisan ride:admin` to create an admin later.
5. Run `START-WEBSITE.bat`. Open `http://127.0.0.1:8000/en`. Staff login: `http://127.0.0.1:8000/staff/login`. `/km` is Khmer; `/zh` is Simplified Chinese.
6. Start `START-NOTIFICATIONS.bat` in another terminal to process Telegram messages.

Enable PHP extensions `pdo_mysql`, `mbstring`, `fileinfo`, `openssl`, `curl`, `dom`, `xml`, `tokenizer`, `ctype`, and **zip**. Enable `pdo_sqlite` for the tests. For dashboard ZIP restore in Laragon's php.ini, use:

```ini
upload_max_filesize = 128M
post_max_size = 160M
memory_limit = 512M
max_file_uploads = 20
```

Restart PHP/Apache after changing php.ini. Image limits remain 8 MB each, PDF 10 MB, logo 2 MB, gallery 12 images. Uploaded SVG/executable files are rejected. Bundled SVGs are trusted project assets. `/media/` serves uploads without requiring a Windows storage symlink.

If a PHP 500 error occurs, run **CHECK-ERRORS.bat** from Laragon Terminal. It checks extensions, write permissions, migrations, DB and queue settings, and writes `storage/logs/diagnostics.log` without printing passwords or tokens. Use the reported failure to fix setup; do not regenerate an existing APP_KEY. Missing cache directories are created at bootstrap.

## Telegram and staff work

Create your own Telegram bot using BotFather. Add it to the administrator group and allow it to post. In Settings, enable Telegram and enter its bot token and group chat ID. The saved token is encrypted; leave the password field blank when retaining it. For driver messages, enter each driver's Telegram chat ID on their user record; the driver must start the bot first.

Keep the queue worker running. New bookings alert administrators/dispatchers in the dashboard. Assignment alerts notify the assigned driver. Check **Notifications** for queued/sent/failed deliveries and retry after fixing configuration. Telegram failures do not reject a successfully saved booking. Retries are at least once; a network timeout may cause a repeated Telegram message even though the customer booking is idempotent.

Staff roles: **admin** manages the platform and system tools; **dispatcher** manages bookings, drivers and messages but cannot change settings or wipe data; **driver** sees only assigned trips. Password updates are under the staff profile.

Drivers follow **Accept → On my way → Passenger onboard → Drop-off completed**. Completion records the time, reporting driver, optional note and optional one-time phone location. Cash stays unpaid unless explicitly marked received; it can be recorded during/after the trip. A returned trip before pickup removes the driver and requests admin reassignment. After pickup, the driver can request help; they remain assigned until admin resolves or reassigns the trip. The admin sees the reason and trip history. Stale driver pages cannot change a reassigned booking.

The system knows about drop-off through the driver's completion action. GPS is optional, driver-reported and expires after five minutes; it is not automatic arrival verification or continuous tracking. Existing v1.4 completion, driver handover and cash history are preserved. Dashboard alerts refresh every 15 seconds. Open a notification to load the latest trip details.

The v1.3.1 fixes remain: notification polling does not replace a form's return URL, successful staff saves redirect to explicit pages, contact validation shows useful field errors, and white flag dropdowns work in both themes. Customer inputs and booking request keys survive AJAX errors so retries do not duplicate reservations.

## Publish on taxikh.com

Use the project's **public** directory as the web root. Set the real database credentials, `APP_URL=https://taxikh.com`, `APP_ENV=production`, `APP_DEBUG=false`, and `SESSION_SECURE_COOKIE=true`. Keep the same APP_KEY when migrating existing records. Configure HTTPS, queue supervision and the scheduler. Set the public domain and translations in SEO settings, then allow indexing after the live site is ready. Submit `https://taxikh.com/sitemap.xml` through the client's Google Search Console. No search ranking, domain registration or Google indexing is automatically guaranteed by the code.

New records use the route/vehicle/extra catalogue API with server prices. See **docs/API.md**. Future native customer apps can use the guest APIs; native staff apps still need token authentication, device registration and push notifications. The current driver portal uses staff sessions, not mobile-app tokens.

## Verification

**64 PHP feature tests / 841 assertions** and **28 JavaScript interaction tests** passed using disposable data. Coverage includes multilingual pages, configured city selection, booking steps, extras/price integrity, contact errors, flag dropdowns, driver workflow, notification polling, role permissions, embed validation, backup/restore, maintenance and guarded data clearing. No test sent messages to a live Telegram group.

Run PHP regression tests with:

```bat
php vendor/bin/phpunit
```

JavaScript interactions were checked using DOM fixtures from the rendered Laravel pages. This is not a Windows Laragon or visual browser verification. The client's actual Google/Tripadvisor widgets, Google API key, Telegram bot and phone GPS still need checks with their own settings on the host. Third-party maps and widgets require internet access.

## Assets

Montserrat and Khmer fonts are bundled locally with their licenses. The editable TAXIKH SVG logo/icon is original. The starter car/route SVG illustrations and the generated `public/demo/taxi-hero-v2.png` hero are sample assets; they do not claim to show the client's actual fleet or business. Replace them through the dashboard where appropriate. No competitor review counts or award badges are used.
