<?php

namespace App\Jobs;

use App\Models\Setting;
use App\Services\TelegramService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

class SendTelegramDelivery implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public int $timeout = 20;

    public function __construct(public int $deliveryId) {}

    public function backoff(): array
    {
        return [10, 60, 180];
    }

    public function handle(TelegramService $telegram): void
    {
        if (Setting::get('maintenance_enabled', '0') === '1') {
            $this->release(60);

            return;
        }
        if (! $telegram->send($this->deliveryId)) {
            throw new \RuntimeException('Telegram delivery '.$this->deliveryId.' failed. Review the notification dashboard.');
        }
    }
}
