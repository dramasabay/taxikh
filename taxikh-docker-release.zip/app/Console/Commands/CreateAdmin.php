<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Validator;

class CreateAdmin extends Command
{
    protected $signature = 'ride:admin';

    protected $description = 'Create an administrator account with a unique password';

    public function handle(): int
    {
        $name = $this->ask('Administrator name');
        $email = $this->ask('Administrator email');
        $password = $this->secret('Password (at least 12 characters)');
        $confirmation = $this->secret('Confirm password');
        $validator = Validator::make(['name' => $name, 'email' => $email, 'password' => $password, 'password_confirmation' => $confirmation], [
            'name' => 'required|string|min:2|max:100', 'email' => 'required|email|max:150|unique:users', 'password' => 'required|string|min:12|max:200|confirmed',
        ]);
        if ($validator->fails()) {
            foreach ($validator->errors()->all() as $error) {
                $this->error($error);
            }

            return self::FAILURE;
        }
        User::create(['name' => $name, 'email' => $email, 'password' => $password, 'role' => 'admin', 'active' => true]);
        $this->info('Administrator created. Sign in at /staff/login.');

        return self::SUCCESS;
    }
}
