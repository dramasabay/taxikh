<?php

namespace App\Console\Commands;

use App\Jobs\SendTelegramDelivery;
use App\Models\TelegramDelivery;
use Illuminate\Console\Command;

class RecoverNotifications extends Command
{
    protected $signature = 'ride:recover-notifications';

    protected $description = 'Recover Telegram jobs left pending or sending after a worker interruption';

    public function handle(): int
    {
        $count = 0;
        TelegramDelivery::whereIn('status', ['pending', 'sending'])->where('updated_at', '<', now()->subMinutes(5))->eachById(function ($d) use (&$count) {
            $d->update(['status' => 'pending', 'last_error' => null]);
            SendTelegramDelivery::dispatch($d->id);
            $count++;
        });
        $this->info($count.' notifications requeued.');

        return self::SUCCESS;
    }
}
