<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class InstallRide extends Command
{
    protected $signature = 'ride:install {--skip-admin : Install schema and demo catalog without creating staff}';

    protected $description = 'Install the booking platform without replacing existing data';

    public function handle(): int
    {
        if (! file_exists(base_path('.env'))) {
            copy(base_path('.env.example'), base_path('.env'));
            $this->warn('.env created. Set your MySQL database, username and password, then run php artisan ride:install again.');

            return self::SUCCESS;
        }
        if (! config('app.key')) {
            if ($this->call('key:generate', ['--force' => true]) !== 0) {
                return self::FAILURE;
            }
        }
        try {
            DB::connection()->getPdo();
        } catch (\Throwable $e) {
            $this->error('Cannot connect to the database. Start MySQL in Laragon, create the database, and check DB_* in .env.');

            return self::FAILURE;
        }
        if ($this->call('migrate', ['--force' => true]) !== 0) {
            return self::FAILURE;
        }
        if ($this->call('db:seed', ['--force' => true]) !== 0) {
            return self::FAILURE;
        }
        if (! $this->option('skip-admin') && ! User::where('role', 'admin')->where('active', true)->exists()) {
            if ($this->call('ride:admin') !== 0) {
                return self::FAILURE;
            }
        }
        $this->info('Installation complete. Website: '.config('app.url').'/en');
        $this->line('Staff login: '.config('app.url').'/staff/login');
        $this->line('Start notifications in another terminal: php artisan queue:work --tries=3 --sleep=3');
        $this->warn('Demo routes and prices are examples. Update your brand, fares, contact information and policies before launch.');

        return self::SUCCESS;
    }
}
