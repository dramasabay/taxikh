<?php

namespace App\Console\Commands;

use App\Models\Setting;
use App\Models\TelegramDelivery;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

class DiagnoseRide extends Command
{
    protected $signature = 'ride:diagnose {--write-log : Write a safe test entry to the configured application log}';

    protected $description = 'Check local setup, log paths and Telegram queue configuration without sending messages';

    public function handle(): int
    {
        $failed = false;
        $check = function (string $label, bool $ok) use (&$failed): void {
            $this->line(($ok ? '[OK] ' : '[FIX] ').$label);
            $failed = $failed || ! $ok;
        };
        $this->info('TAXIKH v2.0 diagnostics');
        $this->line('Project: '.base_path());
        $this->line('PHP: '.PHP_VERSION.' | '.PHP_BINARY);
        $this->line('PHP ini: '.(php_ini_loaded_file() ?: '(none)'));
        $this->line('Session: '.config('session.driver').' | Queue: '.config('queue.default'));
        $this->line('Log directory: '.storage_path('logs'));
        $channel = config('logging.default');
        $this->line('Configured log channel: '.$channel);
        $channels = config('logging.channels.'.$channel.'.driver') === 'stack' ? config('logging.channels.'.$channel.'.channels', []) : [$channel];
        foreach ($channels as $name) {
            if ($path = config('logging.channels.'.$name.'.path')) {
                $this->line('Application log: '.$path.' (daily channels append the date)');
            }
        }
        $check('PHP 8.3 or later', version_compare(PHP_VERSION, '8.3.0', '>='));
        foreach (['pdo', 'mbstring', 'openssl', 'fileinfo', 'curl', 'dom', 'zip'] as $extension) {
            $check('PHP extension: '.$extension, extension_loaded($extension));
        }
        foreach (['logs', 'framework/sessions', 'framework/views', 'framework/cache/data', 'app/public'] as $directory) {
            $check('Writable storage/'.$directory, is_writable(storage_path($directory)));
        }
        $check('Writable bootstrap/cache', is_writable(base_path('bootstrap/cache')));
        try {
            $check('Application key can encrypt and decrypt', Crypt::decryptString(Crypt::encryptString('diagnostic')) === 'diagnostic');
        } catch (Throwable) {
            $check('Application key is valid; keep the existing APP_KEY when updating', false);
        }
        try {
            DB::connection()->getPdo();
            $check('Database connection', true);
            $tablesReady = true;
            foreach (['migrations', 'users', 'settings', 'inquiries', 'alerts', 'bookings', 'telegram_deliveries', 'jobs', 'failed_jobs'] as $table) {
                $exists = Schema::hasTable($table);
                $check('Database table: '.$table, $exists);
                $tablesReady = $tablesReady && $exists;
            }
            if ($tablesReady) {
                $installed = DB::table('migrations')->pluck('migration')->all();
                $pending = array_diff(array_map(fn (string $path): string => pathinfo($path, PATHINFO_FILENAME), glob(database_path('migrations/*.php'))), $installed);
                $check('All migrations applied; run UPDATE-LARAGON.bat if missing', $pending === []);
                $this->line('Queued jobs: '.DB::table('jobs')->count().' | Failed queue jobs: '.DB::table('failed_jobs')->count());
                $this->line('Telegram deliveries: '.TelegramDelivery::whereIn('status', ['pending', 'sending'])->count().' waiting, '.TelegramDelivery::where('status', 'failed')->count().' failed');
                if (Setting::get('telegram_enabled', '0') === '1') {
                    $check('Telegram group ID saved', (bool) Setting::get('telegram_group_id'));
                    try {
                        $check('Telegram token saved and decryptable', (bool) Crypt::decryptString(Setting::get('telegram_bot_token', '')));
                    } catch (Throwable) {
                        $check('Telegram token saved and decryptable; re-enter it if the application key changed', false);
                    }
                    $this->line('Keep START-NOTIFICATIONS.bat running. Live delivery status is in Admin > Notifications.');
                } else {
                    $this->line('Telegram is disabled. Enable it in Admin > Settings when ready.');
                }
            }
        } catch (Throwable) {
            $check('Database checks completed; check MySQL and DB settings in .env, then run UPDATE-LARAGON.bat', false);
        }
        if ($this->option('write-log')) {
            try {
                Log::warning('Mekong Ride diagnostic log check.', ['event' => 'manual_diagnostic', 'checks_passed' => ! $failed]);
                $this->info('A diagnostic entry was sent to the configured log channel. No credentials or customer details were included.');
            } catch (Throwable) {
                $check('Log write succeeded; check log channel and folder permissions', false);
            }
        }
        $this->line('Validation errors and notification JSON are not server exceptions, so they do not create error log entries.');
        $this->line('No Telegram messages were sent. This check does not prove that a queue worker is running.');

        return $failed ? self::FAILURE : self::SUCCESS;
    }
}
