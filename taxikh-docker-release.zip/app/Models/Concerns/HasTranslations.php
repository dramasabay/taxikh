<?php

namespace App\Models\Concerns;

trait HasTranslations
{
    public function text(string $field, ?string $locale = null): string
    {
        $value = $this->getAttribute($field);

        return is_array($value) ? (string) (($value[$locale ?? app()->getLocale()] ?? '') ?: ($value['en'] ?? '')) : (string) $value;
    }

    public function scopePublished($query)
    {
        return $query->where('active', true)->orderBy('sort_order')->orderBy('id');
    }
}
