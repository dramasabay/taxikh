<?php

namespace App\Models;

use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Model;

class Vehicle extends Model
{
    use HasTranslations;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['title' => 'array', 'description' => 'array', 'features' => 'array', 'active' => 'boolean'];
    }

    public function routes()
    {
        return $this->belongsToMany(TravelRoute::class, 'route_vehicle')->withPivot('price_cents');
    }
}
