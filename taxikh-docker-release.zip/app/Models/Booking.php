<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    public const STATUSES = ['pending', 'confirmed', 'assigned', 'on_the_way', 'in_progress', 'completed', 'cancelled'];

    protected $guarded = [];

    protected $hidden = ['public_token', 'public_token_hash', 'request_key', 'request_fingerprint', 'staff_notes',
        'dispatch_reason', 'completion_lat', 'completion_lng', 'completion_accuracy_m', 'completion_captured_at', 'completion_note'];

    protected function casts(): array
    {
        return ['public_token' => 'encrypted', 'price_snapshot' => 'array', 'departure_at' => 'datetime', 'estimated_end_at' => 'datetime', 'paid_at' => 'datetime',
            'dispatch_version' => 'integer', 'dispatch_review' => 'boolean', 'dispatch_requested_at' => 'datetime',
            'driver_accepted_at' => 'datetime', 'on_the_way_at' => 'datetime', 'picked_up_at' => 'datetime',
            'completed_at' => 'datetime', 'completion_captured_at' => 'datetime'];
    }

    public function route()
    {
        return $this->belongsTo(TravelRoute::class, 'travel_route_id');
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class);
    }

    public function driver()
    {
        return $this->belongsTo(User::class, 'driver_id');
    }

    public function completedBy()
    {
        return $this->belongsTo(User::class, 'completed_by');
    }

    public function cashCollectedBy()
    {
        return $this->belongsTo(User::class, 'cash_collected_by');
    }

    public function completionMapUrl(): ?string
    {
        if ($this->completion_lat === null || $this->completion_lng === null) {
            return null;
        }

        return 'https://www.google.com/maps/search/?'.http_build_query(['api' => 1, 'query' => $this->completion_lat.','.$this->completion_lng]);
    }

    public function completionDistanceMeters(): ?int
    {
        if ($this->completion_lat === null || $this->completion_lng === null || $this->dropoff_lat === null || $this->dropoff_lng === null) {
            return null;
        }
        $latitudeDifference = deg2rad((float) $this->dropoff_lat - (float) $this->completion_lat);
        $longitudeDifference = deg2rad((float) $this->dropoff_lng - (float) $this->completion_lng);
        $haversine = sin($latitudeDifference / 2) ** 2 + cos(deg2rad((float) $this->completion_lat)) * cos(deg2rad((float) $this->dropoff_lat)) * sin($longitudeDifference / 2) ** 2;

        return (int) round(6371000 * 2 * asin(sqrt(min(1, max(0, $haversine)))));
    }

    public function events()
    {
        return $this->hasMany(BookingEvent::class)->latest();
    }

    public function deliveries()
    {
        return $this->hasMany(TelegramDelivery::class);
    }

    public function localDeparture()
    {
        return $this->departure_at->copy()->timezone($this->timezone);
    }

    public function mapUrl(string $point): string
    {
        if (! in_array($point, ['pickup', 'dropoff'], true)) {
            throw new \InvalidArgumentException('Unknown booking location.');
        }
        $query = $this->{$point.'_lat'} !== null && $this->{$point.'_lng'} !== null
            ? $this->{$point.'_lat'}.','.$this->{$point.'_lng'} : $this->{$point};
        $params = ['api' => 1, 'query' => $query];
        if ($this->{$point.'_place_id'}) {
            $params['query_place_id'] = $this->{$point.'_place_id'};
        }

        return 'https://www.google.com/maps/search/?'.http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }

    public function contactChatUrl(): ?string
    {
        $phoneDigits = preg_replace('/[^+0-9]/', '', $this->phone);
        $cleanPhone = ltrim($phoneDigits, '+');
        if ($this->contact_method === 'telegram') {
            $handle = trim($this->contact_handle ?: $this->phone);
            $handle = ltrim($handle, '@');
            return 'https://t.me/'.(preg_match('/^[0-9+]+$/', $handle) ? ltrim($handle, '+') : $handle);
        }
        if ($this->contact_method === 'whatsapp') {
            $number = trim($this->contact_handle ?: $this->phone);
            $cleanNumber = ltrim(preg_replace('/[^+0-9]/', '', $number), '+');
            return 'https://wa.me/'.($cleanNumber ?: $cleanPhone);
        }
        return 'tel:'.$phoneDigits;
    }
}
