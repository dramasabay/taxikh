<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TelegramDelivery extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return ['sent_at' => 'datetime', 'context' => 'array'];
    }

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function targetUser()
    {
        return $this->belongsTo(User::class, 'target_user_id');
    }
}
