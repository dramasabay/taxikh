<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = ['name', 'email', 'password', 'role', 'phone', 'telegram_chat_id', 'active'];

    protected $hidden = ['password', 'remember_token', 'telegram_chat_id'];

    protected function casts(): array
    {
        return ['email_verified_at' => 'datetime', 'password' => 'hashed', 'active' => 'boolean'];
    }

    public function alerts()
    {
        return $this->hasMany(Alert::class);
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class, 'driver_id');
    }
}
