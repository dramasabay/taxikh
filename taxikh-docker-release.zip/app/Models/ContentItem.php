<?php

namespace App\Models;

use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Model;

class ContentItem extends Model
{
    use HasTranslations;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['title' => 'array', 'body' => 'array', 'subtitle' => 'array', 'active' => 'boolean'];
    }
}
