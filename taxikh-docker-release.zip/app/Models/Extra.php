<?php

namespace App\Models;

use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Model;

class Extra extends Model
{
    use HasTranslations;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['title' => 'array', 'description' => 'array', 'destination' => 'array', 'active' => 'boolean'];
    }
}
