<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $primaryKey = 'key';

    public $incrementing = false;

    protected $keyType = 'string';

    protected $guarded = [];

    public static function get(string $key, $default = null): mixed
    {
        // Queue workers live across requests, so read updated credentials for each job.
        if (app()->runningInConsole()) {
            return static::whereKey($key)->value('value') ?? $default;
        }
        // Request-local memoization is safe for the standard HTTP lifecycle.
        $values = app()->bound('ride.settings') ? app('ride.settings') : tap(static::pluck('value', 'key')->all(), fn ($v) => app()->instance('ride.settings', $v));

        return $values[$key] ?? $default;
    }

    public static function put(string $key, mixed $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : (string) $value]);
        app()->forgetInstance('ride.settings');
    }
}
