<?php

namespace App\Models;

use App\Models\Concerns\HasTranslations;
use Illuminate\Database\Eloquent\Model;

class TravelRoute extends Model
{
    use HasTranslations;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['title' => 'array', 'origin' => 'array', 'destination' => 'array', 'description' => 'array', 'included' => 'array', 'additional_info' => 'array', 'seo_description' => 'array', 'gallery' => 'array', 'active' => 'boolean', 'featured' => 'boolean'];
    }

    public function vehicles()
    {
        return $this->belongsToMany(Vehicle::class, 'route_vehicle')->withPivot('price_cents')->orderBy('price_cents');
    }

    public function startingPrice(): ?int
    {
        return $this->vehicles->where('active', true)->min('pivot.price_cents');
    }
}
