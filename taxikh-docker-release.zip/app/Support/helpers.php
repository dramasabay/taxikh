<?php

use App\Models\Setting;

function setting(string $key, mixed $default = ''): mixed
{
    return Setting::get($key, $default);
}
function money(int|float|null $cents, bool $dual = true): string
{
    $usd = '$'.number_format(($cents ?? 0) / 100, 2);
    if (! $dual || setting('currency_mode', 'dual') === 'usd_only') {
        return $usd;
    }
    $riel = money_riel($cents);

    return $usd.' ('.$riel.')';
}

function money_usd(int|float|null $cents): string
{
    return '$'.number_format(($cents ?? 0) / 100, 2);
}

function money_riel(int|float|null $cents): string
{
    $rate = (float) setting('riel_exchange_rate', '4100');
    if ($rate <= 0) {
        $rate = 4100;
    }
    $rielAmount = round((($cents ?? 0) / 100) * $rate, -2);

    return number_format($rielAmount).' ៛';
}
function media_url(?string $path): string
{
    return $path ? (str_starts_with($path, 'demo/') ? asset($path) : url('/media/'.$path)) : asset('demo/cambodia.svg');
}
function local_link(?string $link): string
{
    $link = trim($link ?? '');
    if (preg_match('~^https://~i', $link)) {
        return $link;
    }
    if (str_starts_with($link, '/') && ! str_starts_with($link, '//')) {
        return url('/'.app()->getLocale().$link);
    }

    return route('home', ['locale' => app()->getLocale()]);
}
function localized_value(mixed $value): string
{
    return is_array($value) ? ($value[app()->getLocale()] ?? $value['en'] ?? '') : (string) $value;
}

function ride_asset(string $path): string
{
    return asset($path).'?v='.filemtime(public_path($path));
}

function accent_text_color(): string
{
    $hex = ltrim(setting('accent_color', '#ffd801'), '#');
    $channels = array_map(fn ($offset) => hexdec(substr($hex, $offset, 2)) / 255, [0, 2, 4]);
    $linear = array_map(fn ($channel) => $channel <= 0.04045 ? $channel / 12.92 : (($channel + 0.055) / 1.055) ** 2.4, $channels);
    $luminance = 0.2126 * $linear[0] + 0.7152 * $linear[1] + 0.0722 * $linear[2];

    return $luminance > 0.179 ? '#161616' : '#ffffff';
}

function trip_search_context(): array
{
    return request()->only(['departure_date', 'departure_time', 'from', 'to', 'from_lat', 'from_lng', 'from_place_id', 'to_lat', 'to_lng', 'to_place_id']);
}

function google_reviews_link(): string
{
    if (setting('google_reviews_url')) {
        return setting('google_reviews_url');
    }
    if (! setting('google_place_id')) {
        return '';
    }

    return 'https://www.google.com/maps/search/?'.http_build_query(['api' => 1, 'query' => setting('brand_name'), 'query_place_id' => setting('google_place_id')], '', '&', PHP_QUERY_RFC3986);
}

function seo_base_url(): string
{
    return rtrim(setting('seo_indexable', '0') === '1' ? setting('seo_site_url', config('app.url')) : config('app.url'), '/');
}
