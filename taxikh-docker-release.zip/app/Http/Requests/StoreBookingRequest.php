<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'request_key' => ['required', 'uuid'], 'route_id' => ['required', 'integer'], 'vehicle_id' => ['required', 'integer'],
            'locale' => ['required', Rule::in(['en', 'km', 'zh'])],
            'customer_name' => ['required', 'string', 'min:2', 'max:100'],
            'phone' => ['required', 'string', 'regex:/^(?=(?:\D*\d){7,15}\D*$)\+?[0-9\s().-]{7,30}$/'],
            'people' => ['required', 'integer', 'min:1', 'max:60'],
            'pickup' => ['required', 'string', 'min:3', 'max:300'], 'dropoff' => ['required', 'string', 'min:3', 'max:300'],
            'pickup_lat' => ['nullable', 'required_with:pickup_lng', 'numeric', 'between:-90,90'],
            'pickup_lng' => ['nullable', 'required_with:pickup_lat', 'numeric', 'between:-180,180'],
            'dropoff_lat' => ['nullable', 'required_with:dropoff_lng', 'numeric', 'between:-90,90'],
            'dropoff_lng' => ['nullable', 'required_with:dropoff_lat', 'numeric', 'between:-180,180'],
            'pickup_place_id' => ['nullable', 'string', 'max:255', 'regex:/^[A-Za-z0-9_-]+$/'],
            'dropoff_place_id' => ['nullable', 'string', 'max:255', 'regex:/^[A-Za-z0-9_-]+$/'],
            'departure_date' => ['required', 'date_format:Y-m-d'], 'departure_time' => ['required', 'date_format:H:i'],
            'contact_method' => ['nullable', 'string', Rule::in(['whatsapp', 'telegram', 'phone'])],
            'contact_handle' => ['nullable', 'string', 'max:100'],
            'extras' => ['sometimes', 'array', 'max:20'], 'extras.*' => ['integer', 'distinct'],
            'notes' => ['nullable', 'string', 'max:2000'], 'website' => ['nullable', 'string', 'max:0'],
        ];
    }

    public function attributes(): array
    {
        return collect(['customer_name', 'phone', 'people', 'pickup', 'dropoff', 'departure_date', 'departure_time', 'vehicle_id'])->mapWithKeys(fn ($k) => [$k => __('ui.'.$k)])->all();
    }

    protected function prepareForValidation(): void
    {
        $data = [];
        foreach (['customer_name', 'phone', 'pickup', 'dropoff', 'contact_handle'] as $key) {
            if (is_string($this->input($key))) {
                $data[$key] = trim($this->input($key));
            }
        }
        if (! $this->filled('contact_method')) {
            $data['contact_method'] = 'whatsapp';
        }
        $this->merge($data);
    }
}
