<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DriverActionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->role === 'driver';
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, array<int, string>>
     */
    public function rules(): array
    {
        return [
            'action' => ['required', 'in:accept,on_the_way,pickup,complete,return,collect_cash'],
            'dispatch_version' => ['required', 'integer', 'min:0'],
            'reason' => ['required_if:action,return', 'nullable', 'string', 'min:1', 'max:1000'],
            'completion_note' => ['exclude_unless:action,complete', 'nullable', 'string', 'max:1000'],
            'actual_duration_minutes' => ['exclude_unless:action,complete', 'nullable', 'integer', 'min:1', 'max:2880'],
            'cash_received' => ['nullable', 'boolean'],
            'completion_lat' => ['exclude_unless:action,complete', 'nullable', 'required_with:completion_lng', 'numeric', 'between:-90,90'],
            'completion_lng' => ['exclude_unless:action,complete', 'nullable', 'required_with:completion_lat', 'numeric', 'between:-180,180'],
            'completion_accuracy_m' => ['exclude_unless:action,complete', 'nullable', 'required_with:completion_lat', 'numeric', 'between:0,100000'],
            'completion_captured_at' => ['exclude_unless:action,complete', 'nullable', 'required_with:completion_lat', 'integer', 'min:1'],
        ];
    }

    public function attributes(): array
    {
        return ['reason' => __('ui.return_reason'), 'completion_note' => __('ui.completion_note'),
            'completion_lat' => __('ui.completion_location'), 'completion_lng' => __('ui.completion_location'),
            'completion_accuracy_m' => __('ui.location_accuracy'), 'completion_captured_at' => __('ui.completion_location')];
    }

    public function messages(): array
    {
        return ['reason.required_if' => __('ui.return_reason_required'), 'dispatch_version.required' => __('ui.trip_changed')];
    }

    protected function getRedirectUrl(): string
    {
        return route('driver.booking', $this->route('booking'));
    }
}
