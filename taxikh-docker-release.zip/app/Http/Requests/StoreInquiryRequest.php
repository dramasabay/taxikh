<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreInquiryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, array<int, string>>
     */
    public function rules(): array
    {
        return [
            'type' => ['required', 'in:contact,agency,driver,influencer'],
            'name' => ['required', 'string', 'min:1', 'max:100'],
            'phone' => ['required', 'string', 'max:30', 'regex:/^(?=(?:\D*\d){7,15}\D*$)\+?[0-9 ().-]+$/D'],
            'email' => ['nullable', 'email', 'max:150'],
            'message' => ['required', 'string', 'min:1', 'max:4000'],
            'website' => ['nullable', 'string', 'max:0'],
        ];
    }

    public function attributes(): array
    {
        return collect(['type', 'name', 'phone', 'email', 'message'])->mapWithKeys(fn (string $key) => [$key => __('ui.'.$key)])->all();
    }

    public function messages(): array
    {
        return ['phone.regex' => __('validation.phone'), 'website.max' => __('validation.form_retry')];
    }

    protected function prepareForValidation(): void
    {
        if (is_string($this->input('phone'))) {
            $digits = array_combine(preg_split('//u', '០១២៣៤៥៦៧៨៩０１２３４５６７８９＋', -1, PREG_SPLIT_NO_EMPTY), str_split('01234567890123456789+'));
            $phone = strtr($this->input('phone'), $digits);
            $this->merge(['phone' => trim(preg_replace('/\s+/u', ' ', $phone))]);
        }
    }

    protected function getRedirectUrl(): string
    {
        return route(in_array($this->input('type'), ['agency', 'driver', 'influencer'], true) ? 'partners' : 'contact');
    }
}
