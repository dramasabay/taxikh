<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreInquiryRequest;
use App\Models\Alert;
use App\Models\ContentItem;
use App\Models\Extra;
use App\Models\Inquiry;
use App\Models\TravelRoute;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\CatalogueService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class PublicController extends Controller
{
    public function home(Request $r, CatalogueService $catalogue)
    {
        $data = $this->catalogueData($r, $catalogue);
        if ($r->ajax() || $r->wantsJson()) {
            return response()->json([
                'html' => view('components.catalogue', $data)->render(),
                'count' => $data['routes']->total(),
                'count_text' => trans_choice('taxikh.route_count', $data['routes']->total(), ['count' => $data['routes']->total()]),
            ]);
        }

        return view('public.home', $data);
    }

    public function routes(Request $r, CatalogueService $catalogue)
    {
        $data = $this->catalogueData($r, $catalogue);
        if ($r->ajax() || $r->wantsJson()) {
            return response()->json([
                'html' => view('components.catalogue', $data)->render(),
                'count' => $data['routes']->total(),
                'count_text' => trans_choice('taxikh.route_count', $data['routes']->total(), ['count' => $data['routes']->total()]),
            ]);
        }

        return view('public.routes', $data);
    }

    private function catalogueData(Request $r, CatalogueService $catalogue): array
    {
        $this->validateSearch($r);
        $r->validate(['q' => 'nullable|string|max:100', 'type' => 'nullable|in:transfer,airport,tour,hourly', 'sort' => 'nullable|in:recommended,price_asc,price_desc,duration,name', 'layout' => 'nullable|in:grid,list', 'page' => 'nullable|integer|min:1|max:100000']);
        $routes = $catalogue->query($r)->paginate($catalogue->pageSize())->withQueryString()->fragment('routes-catalogue');
        $cities = $catalogue->catalogue();

        $availableDestinations = $cities->flatMap(function ($t) {
            return [
                $t->text('destination'),
                $t->text('origin'),
                $t->text('title'),
            ];
        })->filter()->unique()->values()->all();

        return [
            'routes' => $routes,
            'cityOrigins' => $catalogue->cities($cities, 'origin'),
            'cityDestinations' => $catalogue->cities($cities, 'destination'),
            'cityPairs' => $cities->map(fn ($t) => ['from' => $t->text('origin', 'en'), 'to' => $t->text('destination', 'en'), 'type' => $t->type])->values(),
            'availableDestinations' => $availableDestinations,
        ];
    }

    public function startBooking(Request $r, CatalogueService $catalogue)
    {
        $this->validateSearch($r);
        $r->validate(['from' => 'required|string|max:150', 'to' => 'required|string|max:150', 'type' => 'nullable|in:transfer,airport,tour,hourly']);
        $routes = $catalogue->query(new Request($r->only(['from', 'to', 'type'])))->get();
        if ($routes->isEmpty()) {
            throw ValidationException::withMessages(['to' => __('taxikh.choose_route_city')])->redirectTo(route('routes'));
        }
        if ($routes->count() === 1) {
            return redirect()->route('route.detail', ['slug' => $routes->first()->slug, ...trip_search_context()]);
        }

        return redirect()->route('routes', $r->only(['from', 'to', 'type', 'departure_date', 'departure_time']));
    }

    public function detail(string $locale, string $slug)
    {
        $this->validateSearch(request());
        $trip = TravelRoute::published()->with(['vehicles' => fn ($q) => $q->where('vehicles.active', true)])->where('slug', $slug)->firstOrFail();
        $extras = Extra::published()->where(fn ($q) => $q->whereNull('travel_route_id')->orWhere('travel_route_id', $trip->id))->get();

        return view('public.detail', compact('trip', 'extras'));
    }

    private function validateSearch(Request $request): void
    {
        $rules = ['departure_date' => 'nullable|date_format:Y-m-d', 'departure_time' => 'nullable|date_format:H:i'];
        foreach (['from', 'to'] as $point) {
            $rules[$point] = 'nullable|string|max:300';
            $rules[$point.'_lat'] = 'nullable|required_with:'.$point.'_lng|numeric|between:-90,90';
            $rules[$point.'_lng'] = 'nullable|required_with:'.$point.'_lat|numeric|between:-180,180';
            $rules[$point.'_place_id'] = ['nullable', 'string', 'max:255', 'regex:/^[A-Za-z0-9_-]+$/'];
        }
        $request->validate($rules);
    }

    public function fleet()
    {
        $vehicles = Vehicle::published()->get();

        return view('public.fleet', compact('vehicles'));
    }

    public function guides()
    {
        $items = ContentItem::published()->where('kind', 'guide')->paginate(9);

        return view('public.guides', compact('items'));
    }

    public function article(string $locale, string $slug)
    {
        $item = ContentItem::published()->where('kind', 'guide')->where('slug', $slug)->firstOrFail();

        return view('public.article', compact('item'));
    }

    public function page(string $locale, string $slug)
    {
        $item = ContentItem::published()->where('kind', 'page')->where('slug', $slug)->firstOrFail();

        return view('public.article', compact('item'));
    }

    public function faq()
    {
        return view('public.faq');
    }

    public function contact()
    {
        return view('public.contact', ['partner' => false]);
    }

    public function partners()
    {
        return view('public.contact', ['partner' => true]);
    }

    public function inquiry(StoreInquiryRequest $r)
    {
        $data = $r->safe()->except('website');
        DB::transaction(function () use ($data): void {
            $inquiry = Inquiry::create($data);
            foreach (User::where('active', true)->whereIn('role', ['admin', 'dispatcher'])->get() as $user) {
                Alert::create(['user_id' => $user->id, 'kind' => 'new_inquiry', 'message' => '#'.$inquiry->id.' '.$inquiry->type]);
            }
        });
        if ($r->expectsJson()) {
            return response()->json(['message' => __('ui.inquiry_received')]);
        }

        return redirect()->route($data['type'] === 'contact' ? 'contact' : 'partners')->with('success', __('ui.inquiry_received'));
    }

    public function media(string $path)
    {
        abort_unless(preg_match('~^uploads/[0-9]{4}/[0-9]{2}/[A-Za-z0-9]+\.(jpg|jpeg|png|webp|pdf)$~', $path), 404);
        abort_unless(Storage::disk('public')->exists($path), 404);
        $response = response()->file(Storage::disk('public')->path($path), ['X-Content-Type-Options' => 'nosniff']);
        if (str_ends_with($path, '.pdf')) {
            $response->headers->set('Content-Disposition', 'attachment; filename="trip-information.pdf"');
        }

        return $response;
    }

    public function robots()
    {
        $body = setting('seo_indexable', '0') === '1'
            ? "User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /driver\nDisallow: /staff\nDisallow: /api\nDisallow: /*/reservation/\nSitemap: ".seo_base_url()."/sitemap.xml\n"
            : "User-agent: *\nDisallow: /\n";

        return response($body, 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
    }

    public function sitemap()
    {
        $paths = ['', '/routes', '/fleet', '/guides', '/faq', '/contact', '/partners'];
        foreach (TravelRoute::published()->pluck('slug') as $slug) {
            $paths[] = '/routes/'.$slug;
        }
        foreach (ContentItem::published()->whereIn('kind', ['guide', 'page'])->get() as $item) {
            $paths[] = ($item->kind === 'guide' ? '/guides/' : '/page/').$item->slug;
        }
        $xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        foreach (['en', 'km', 'zh'] as $locale) {
            foreach ($paths as $path) {
                $xml .= '<url><loc>'.e(seo_base_url().'/'.$locale.$path).'</loc></url>';
            }
        }

        return response($xml.'</urlset>', 200, ['Content-Type' => 'application/xml; charset=UTF-8']);
    }
}
