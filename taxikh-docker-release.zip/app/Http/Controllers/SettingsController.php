<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Services\EmbedService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Validation\ValidationException;

class SettingsController extends Controller
{
    public function index()
    {
        return view('admin.settings');
    }

    public function save(Request $r)
    {
        $rules = [
            'brand_name' => 'required|string|max:70', 'phone' => 'nullable|string|max:40', 'email' => 'nullable|email|max:150',
            'whatsapp' => ['nullable', 'regex:/^[0-9]{7,20}$/'], 'telegram_public' => ['nullable', 'regex:/^[A-Za-z0-9_]{5,32}$/'],
            'accent_color' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'], 'default_language' => 'required|in:en,km,zh',
            'booking_enabled' => 'nullable|boolean', 'min_notice_hours' => 'required|integer|min:0|max:168',
            'home_sections' => 'sometimes|nullable|string|max:150', 'sections_present' => 'nullable|boolean', 'sections' => 'nullable|array|max:8', 'sections.*' => 'string|distinct|in:hero,search,routes,benefits,fleet,guides,faq,reviews', 'telegram_enabled' => 'nullable|boolean',
            'telegram_bot_token' => ['nullable', 'string', 'max:200', 'regex:/^[0-9]+:[A-Za-z0-9_-]+$/'],
            'telegram_group_id' => ['nullable', 'regex:/^-?[0-9]{4,30}$/'], 'clear_telegram_token' => 'nullable|boolean',
            'logo' => 'nullable|file|mimes:jpg,jpeg,png,webp|max:2048',
            'default_theme' => 'sometimes|required|in:system,light,dark',
            'header_max_width' => 'sometimes|required|in:standard,wide,extra,full',
            'content_max_width' => 'sometimes|required|in:standard,wide,extra,full',
            'google_maps_enabled' => 'sometimes|boolean', 'google_reviews_enabled' => 'sometimes|boolean',
            'google_maps_api_key' => ['nullable', 'string', 'max:200', 'regex:/^[A-Za-z0-9_-]+$/'],
            'google_place_id' => ['nullable', 'string', 'max:255', 'regex:/^[A-Za-z0-9_-]+$/'],
            'google_reviews_url' => ['nullable', 'url:https', 'max:500', function ($attribute, $value, $fail) {
                $host = strtolower((string) parse_url($value, PHP_URL_HOST));
                if (! in_array($host, ['google.com', 'www.google.com', 'maps.google.com', 'maps.app.goo.gl', 'g.page', 'search.google.com'], true)) {
                    $fail(__('ui.google_url_error'));
                }
            }],
            'clear_google_maps_key' => 'nullable|boolean',
            'routes_columns' => 'sometimes|required|integer|between:2,5', 'routes_rows' => 'sometimes|required|integer|between:1,6',
            'routes_list_columns' => 'sometimes|required|integer|between:1,2',
            'default_driver_commission' => 'sometimes|required|numeric|between:0,100',
            'riel_exchange_rate' => 'sometimes|required|integer|between:1000,10000',
            'currency_mode' => 'sometimes|required|in:dual,usd_only',
            'routes_layout' => 'sometimes|required|in:grid,list', 'routes_sort' => 'sometimes|required|in:recommended,price_asc,price_desc,duration,name',
            'google_embed' => 'nullable|string|max:20000', 'tripadvisor_embed' => 'nullable|string|max:20000',
            'tripadvisor_url' => ['nullable', 'url:https', 'max:1000', function ($attribute, $value, $fail) {
                if (! in_array(strtolower((string) parse_url($value, PHP_URL_HOST)), ['www.tripadvisor.com', 'tripadvisor.com'], true)) {
                    $fail(__('taxikh.embed_invalid'));
                }
            }],
            'review_embed_height' => 'sometimes|required|integer|between:200,900',
            'seo_indexable' => 'sometimes|boolean', 'seo_site_url' => ['nullable', 'url:https', 'max:200', 'regex:~^https://[A-Za-z0-9.-]+/?$~'],
        ];
        foreach (['en', 'km', 'zh'] as $l) {
            foreach (['tagline', 'address', 'footer_note', 'seo_title', 'seo_description'] as $k) {
                $rules[$k.'_'.$l] = 'nullable|string|max:1000';
            }
        }
        $d = $r->validate($rules);
        $sections = $r->boolean('sections_present') ? ($r->input('sections') ?? []) : array_values(array_filter(array_map('trim', explode(',', $d['home_sections'] ?? Setting::get('home_sections', 'hero,search,routes')))));
        unset($d['sections_present'],$d['sections']);
        $embedService = app(EmbedService::class);
        foreach (['google', 'tripadvisor'] as $provider) {
            if ($r->exists($provider.'_embed')) {
                $d[$provider.'_embed'] = json_encode($embedService->parse($r->input($provider.'_embed'), $provider, $provider.'_embed'), JSON_UNESCAPED_SLASHES);
            }
        }
        if (count(array_unique($sections)) !== count($sections) || array_diff($sections, ['hero', 'search', 'routes', 'benefits', 'fleet', 'guides', 'faq', 'reviews'])) {
            throw ValidationException::withMessages(['home_sections' => __('ui.section_order_help')]);
        }
        unset($d['logo'],$d['telegram_bot_token'],$d['clear_telegram_token'], $d['google_maps_api_key'], $d['clear_google_maps_key']);
        $googleKey = $r->filled('google_maps_api_key') ? $r->string('google_maps_api_key')->toString() : ($r->boolean('clear_google_maps_key') ? '' : Setting::get('google_maps_api_key', ''));
        foreach (['google_maps_enabled'] as $field) {
            $enabled = array_key_exists($field, $d) ? $r->boolean($field) : Setting::get($field, '0') === '1';
            if ($enabled && ! $googleKey) {
                throw ValidationException::withMessages(['google_maps_api_key' => __('ui.google_key_required')]);
            }
            if (array_key_exists($field, $d)) {
                $d[$field] = $enabled ? '1' : '0';
            }
        }
        $d['google_reviews_enabled'] = '0'; // Reviews now use admin supplied embeds, without Places API requests.
        foreach (['booking_enabled', 'telegram_enabled'] as $k) {
            $d[$k] = $r->boolean($k) ? '1' : '0';
        }
        $d['home_sections'] = implode(',', $sections);
        foreach ($d as $k => $v) {
            Setting::put($k, $v ?? '');
        }
        if ($r->filled('google_maps_api_key') || $r->boolean('clear_google_maps_key')) {
            Setting::put('google_maps_api_key', $googleKey);
        }
        if ($r->boolean('clear_telegram_token')) {
            Setting::put('telegram_bot_token', '');
        }
        if ($r->filled('telegram_bot_token')) {
            Setting::put('telegram_bot_token', Crypt::encryptString($r->telegram_bot_token));
        }
        if ($r->hasFile('logo')) {
            Setting::put('logo_path', $r->file('logo')->store('uploads/'.now()->format('Y/m'), 'public'));
        }

        return redirect()->route('admin.settings')->with('success', __('ui.saved'));
    }
}
