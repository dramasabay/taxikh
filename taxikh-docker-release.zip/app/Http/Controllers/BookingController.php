<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBookingRequest;
use App\Models\Booking;
use App\Models\Extra;
use App\Models\TravelRoute;
use App\Services\BookingService;
use App\Services\PricingService;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function quote(Request $r, PricingService $pricing)
    {
        $d = $r->validate(['route_id' => 'required|integer', 'vehicle_id' => 'required|integer', 'people' => 'required|integer|min:1|max:60', 'extras' => 'sometimes|array|max:20', 'extras.*' => 'integer|distinct']);

        return response()->json($pricing->quote($d['route_id'], $d['vehicle_id'], $d['extras'] ?? [], $d['people']));
    }

    public function store(StoreBookingRequest $r, BookingService $service)
    {
        $booking = $service->create($r->validated());
        $url = route('booking.show', ['locale' => $booking->locale, 'token' => $booking->public_token]);
        if ($r->expectsJson()) {
            return response()->json(['reference' => $booking->reference, 'status' => $booking->status, 'total_cents' => $booking->total_cents, 'currency' => $booking->currency, 'confirmation_url' => $url], 201);
        }

        return redirect($url);
    }

    public function show(string $locale, string $token)
    {
        abort_unless(strlen($token) === 48, 404);
        $booking = Booking::with('driver')->where('public_token_hash', hash('sha256', $token))->firstOrFail();

        return view('public.confirmation', compact('booking'));
    }

    public function catalog()
    {
        return response()->json(['data' => TravelRoute::published()->with(['vehicles' => fn ($q) => $q->where('vehicles.active', true)])->get()->map(fn ($r) => [
            'id' => $r->id, 'slug' => $r->slug, 'type' => $r->type, 'title' => $r->title, 'origin' => $r->origin, 'destination' => $r->destination, 'description' => $r->description, 'image' => media_url($r->image_path), 'duration_minutes' => $r->duration_minutes, 'distance_km' => $r->distance_km, 'map_embed_url' => $r->map_embed_url,
            'vehicles' => $r->vehicles->map(fn ($v) => ['id' => $v->id, 'title' => $v->title, 'category' => $v->category, 'features' => $v->features, 'passengers' => $v->passengers, 'luggage' => $v->luggage, 'price_cents' => (int) $v->pivot->price_cents, 'image' => media_url($v->image_path)]),
        ]), 'extras' => Extra::published()->get(['id', 'title', 'description', 'destination', 'travel_route_id', 'image_path', 'price_cents']), 'currency' => 'USD', 'timezone' => 'Asia/Phnom_Penh']);
    }
}
