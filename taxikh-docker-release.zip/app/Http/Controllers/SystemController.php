<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Services\BackupService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class SystemController extends Controller
{
    public function index(BackupService $backups)
    {
        $files = collect(glob($backups->directory().'/taxikh-backup-*.zip'))->sortDesc()->take(30)->map(fn ($path) => ['name' => basename($path), 'bytes' => filesize($path), 'time' => filemtime($path)]);
        $counts = collect(BackupService::TABLES)->mapWithKeys(fn ($table) => [$table => DB::table($table)->count()]);

        return view('admin.system', compact('files', 'counts'));
    }

    public function backup(Request $r, BackupService $backups)
    {
        $r->validate(['current_password' => 'required|current_password']);
        $name = $backups->exclusive(fn () => $backups->create());

        return redirect()->route('admin.system')->with('success', __('taxikh.backup_created', ['file' => $name]));
    }

    public function download(string $file, BackupService $backups)
    {
        abort_unless(preg_match('/^taxikh-backup-[0-9]{8}-[0-9]{6}-[a-z0-9]{12}\.zip$/', $file), 404);
        $path = $backups->directory().'/'.$file;
        abort_unless(is_file($path), 404);

        return response()->download($path, $file, ['Cache-Control' => 'no-store, private']);
    }

    private function ready(Request $r, string $confirmation): void
    {
        $r->validate(['current_password' => 'required|current_password', 'confirm' => 'required|in:'.$confirmation, 'worker_stopped' => 'accepted']);
        if (Setting::get('maintenance_enabled', '0') !== '1') {
            throw ValidationException::withMessages(['system' => __('taxikh.enable_maintenance_first')]);
        }
        if (DB::table('jobs')->whereNotNull('reserved_at')->where('reserved_at', '>', now()->subMinutes(5)->timestamp)->exists()
            || DB::table('telegram_deliveries')->where('status', 'sending')->where('updated_at', '>', now()->subMinutes(5))->exists()) {
            throw ValidationException::withMessages(['system' => __('taxikh.system_busy')]);
        }
    }

    public function restore(Request $r, BackupService $backups)
    {
        $this->ready($r, 'RESTORE');
        $r->validate(['backup' => 'required|file|mimes:zip|max:131072']);
        $backups->exclusive(fn () => $backups->restore($r->file('backup')->getRealPath(), $r->user()));
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return redirect()->route('login')->with('success', __('taxikh.restored'));
    }

    public function clear(Request $r, BackupService $backups)
    {
        $r->validate(['scope' => 'required|in:operations,reset']);
        $this->ready($r, $r->scope === 'reset' ? 'RESET CATALOGUE' : 'CLEAR BOOKINGS');
        $name = $backups->exclusive(fn () => $backups->clear($r->scope));

        return redirect()->route('admin.system')->with('success', __('taxikh.cleared', ['file' => $name]));
    }

    public function maintenance(Request $r)
    {
        $r->validate(['enabled' => 'required|boolean']);
        Setting::put('maintenance_enabled', $r->boolean('enabled') ? '1' : '0');

        return redirect()->route('admin.system')->with('success',__('ui.saved'));
    }
}
