<?php

namespace App\Http\Controllers;

use App\Services\StaffSessionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function form()
    {
        return view('auth.login');
    }

    public function login(Request $r)
    {
        $d = $r->validate(['email' => 'required|email|max:150', 'password' => 'required|string|max:200']);
        if (! Auth::attempt([...$d, 'active' => true])) {
            throw ValidationException::withMessages(['email' => __('ui.login_error')]);
        }
        $r->session()->regenerate();
        $r->session()->put('password_hash_web', Auth::guard('web')->hashPasswordForCookie($r->user()->getAuthPassword()));

        return redirect($r->user()->role === 'driver' ? '/driver' : '/admin');
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();

        return redirect()->route('login');
    }

    public function password(Request $r, StaffSessionService $sessions)
    {
        $r->validate(['current_password' => 'required|current_password', 'password' => 'required|string|min:12|max:200|confirmed']);
        $r->user()->forceFill(['password' => $r->password, 'remember_token' => Str::random(60)])->save();
        $sessions->revoke($r->user(), $r->session()->getId());
        $r->session()->regenerate();
        $r->session()->regenerateToken();

        return redirect()->route('staff.profile')->with('success', __('ui.saved'));
    }

    public function language(Request $r, string $locale)
    {
        abort_unless(in_array($locale, ['en', 'km', 'zh']), 404);
        $r->session()->put('locale', $locale);

        return redirect($r->user()?->role === 'driver' ? '/driver' : '/admin');
    }
}
