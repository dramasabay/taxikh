<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\BookingEvent;
use App\Models\ContentItem;
use App\Models\Extra;
use App\Models\TravelRoute;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\EmbedService;
use App\Services\StaffSessionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class ResourceController extends Controller
{
    public const MODELS = ['routes' => TravelRoute::class, 'vehicles' => Vehicle::class, 'extras' => Extra::class, 'content' => ContentItem::class, 'users' => User::class];

    private function model(string $resource): string
    {
        abort_unless(isset(self::MODELS[$resource]), 404);

        return self::MODELS[$resource];
    }

    public function index(Request $r, string $resource)
    {
        $model = $this->model($resource);
        $q = $model::query();
        if ($resource === 'content' && $r->filled('kind')) {
            $q->where('kind', (string) $r->string('kind')->limit(30));
        }
        $items = $q->orderBy($resource === 'users' ? 'name' : 'sort_order')->paginate(20)->withQueryString();

        return view('admin.resources', compact('items', 'resource'));
    }

    public function create(string $resource)
    {
        $model = $this->model($resource);
        $item = new $model;

        return $this->form($resource, $item);
    }

    public function edit(string $resource, int $id)
    {
        $model = $this->model($resource);

        return $this->form($resource, $model::findOrFail($id));
    }

    private function form($resource, $item)
    {
        $vehicles = Vehicle::orderBy('sort_order')->get();
        $fares = $resource === 'routes' && $item->exists ? $item->vehicles()->pluck('route_vehicle.price_cents', 'vehicles.id')->all() : [];

        $availableRoutes = TravelRoute::orderBy('sort_order')->get();

        return view('admin.resource-form', compact('resource', 'item', 'vehicles', 'fares', 'availableRoutes'));
    }

    public function store(Request $r, string $resource)
    {
        $model = $this->model($resource);

        return $this->save($r, $resource, new $model);
    }

    public function update(Request $r, string $resource, int $id)
    {
        $model = $this->model($resource);

        return $this->save($r, $resource, $model::findOrFail($id));
    }

    private function translations(array $fields): array
    {
        $rules = [];
        foreach ($fields as $f) {
            $rules[$f] = ($f === 'title' ? 'required' : 'nullable').'|array:en,km,zh';
            foreach (['en', 'km', 'zh'] as $l) {
                $rules[$f.'.'.$l] = ($f === 'title' && $l === 'en' ? 'required' : 'nullable').'|string|max:15000';
            }
        }

        return $rules;
    }

    private function save(Request $r, string $resource, $item)
    {
        $rules = ['active' => 'nullable|boolean', 'sort_order' => 'nullable|integer|min:0|max:9999', 'image' => 'nullable|file|mimes:jpg,jpeg,png,webp|max:8192'];
        $fields = match ($resource) {
            'routes' => ['title', 'origin', 'destination', 'description', 'included', 'additional_info', 'seo_description'],'vehicles' => ['title', 'description', 'features'], 'extras' => ['title', 'description', 'destination'],'content' => ['title', 'subtitle', 'body'],default => []
        };
        $rules = array_merge($rules, $this->translations($fields));
        if ($resource === 'routes') {
            $rules = array_merge($rules, [
                'map_embed' => 'nullable|string|max:20000',
                'slug' => ['required', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'max:160', Rule::unique('travel_routes')->ignore($item->id)], 'type' => 'required|in:transfer,airport,tour,hourly',
                'origin.en' => 'required|string|max:150', 'destination.en' => 'required|string|max:150',
                'distance_km' => 'required|integer|min:0|max:5000', 'duration_minutes' => 'required|integer|min:15|max:20160', 'featured' => 'nullable|boolean',
                'overtime_enabled' => 'nullable|boolean', 'overtime_interval_minutes' => 'nullable|integer|min:1|max:1440', 'overtime_rate' => ['nullable', 'regex:/^\d{1,6}(\.\d{1,2})?$/'],
                'fares' => 'required|array', 'fares.*' => ['nullable', 'regex:/^\d{1,6}(\.\d{1,2})?$/'], 'gallery' => 'nullable|array|max:12', 'gallery.*' => 'file|mimes:jpg,jpeg,png,webp|max:8192', 'attachment' => 'nullable|file|mimes:pdf|max:10240', 'clear_gallery' => 'nullable|boolean', 'clear_attachment' => 'nullable|boolean',
            ]);
        }
        if ($resource === 'vehicles') {
            $rules = array_merge($rules, ['category' => 'sometimes|required|in:basic,executive,large', 'passengers' => 'required|integer|min:1|max:60', 'luggage' => 'required|integer|min:0|max:100']);
        }
        if ($resource === 'extras') {
            $rules['travel_route_id'] = 'nullable|integer|exists:travel_routes,id';
            $rules['price'] = ['required', 'regex:/^\d{1,6}(\.\d{1,2})?$/'];
        }
        if ($resource === 'content') {
            $rules = array_merge($rules, [
                'kind' => 'required|in:slide,menu,footer,benefit,faq,guide,page',
                'slug' => ['nullable', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'max:160', Rule::unique('content_items')->ignore($item->id)],
                'link' => ['nullable', 'string', 'max:500', function ($attr, $v, $fail) {
                    if (! preg_match('~^(https://[^\s]+|/(?!/)[^\s]*)$~', $v)) {
                        $fail(__('ui.invalid_link'));
                    }
                }],
            ]);
        }
        if ($resource === 'users') {
            $rules = array_merge($rules, [
                'name' => 'required|string|min:2|max:100', 'email' => ['required', 'email', 'max:150', Rule::unique('users')->ignore($item->id)],
                'phone' => 'nullable|string|max:40', 'role' => 'required|in:admin,dispatcher,driver', 'telegram_chat_id' => ['nullable', 'regex:/^-?[0-9]{4,30}$/'],
                'password' => [$item->exists ? 'nullable' : 'required', 'string', 'min:12', 'max:200', 'confirmed'],
            ]);
        }
        $data = $r->validate($rules);
        unset($data['image'],$data['gallery'],$data['attachment'],$data['fares'],$data['clear_gallery'],$data['clear_attachment']);
        $data['active'] = $r->boolean('active');
        $data['sort_order'] = (int) $r->input('sort_order', 0);
        if ($resource === 'users') {
            unset($data['sort_order']);
            if (empty($data['password'])) {
                unset($data['password']);
            }
            if ($item->id === $r->user()->id && (! $data['active'] || $data['role'] !== 'admin')) {
                throw ValidationException::withMessages(['role' => __('ui.keep_admin')]);
            }
            if ($item->role === 'admin' && (! $data['active'] || $data['role'] !== 'admin') && User::where('role', 'admin')->where('active', true)->where('id', '!=', $item->id)->count() === 0) {
                throw ValidationException::withMessages(['role' => __('ui.keep_admin')]);
            }
        }
        if ($resource === 'content' && in_array($r->kind, ['guide', 'page']) && ! $r->filled('slug')) {
            throw ValidationException::withMessages(['slug' => __('ui.required_field')]);
        }
        $fareData = [];
        if ($resource === 'routes') {
            $data['featured'] = $r->boolean('featured');
            $data['overtime_enabled'] = $r->boolean('overtime_enabled');
            $data['overtime_interval_minutes'] = max(1, (int) $r->input('overtime_interval_minutes', 2));
            $data['overtime_rate_cents'] = (int) round(((float) $r->input('overtime_rate', 1.0)) * 100);
            unset($data['overtime_rate']);
            if ($r->exists('map_embed')) {
                $data['map_embed_url'] = app(EmbedService::class)->parse($r->input('map_embed'), 'google', 'map_embed')['url'] ?? null;
            }
            unset($data['map_embed']);
            foreach ($r->input('fares', []) as $id => $price) {
                if ($price !== null && $price !== '') {
                    if (! ctype_digit((string) $id) || ! Vehicle::whereKey($id)->exists()) {
                        throw ValidationException::withMessages(['fares' => __('ui.vehicle_unavailable')]);
                    }
                    $fareData[$id] = ['price_cents' => $this->cents($price)];
                }
            }
            if ($data['active'] && count($fareData) === 0) {
                throw ValidationException::withMessages(['fares' => __('ui.price_required')]);
            }
        }
        if ($resource === 'extras') {
            $data['price_cents'] = $this->cents($r->price);
            unset($data['price']);
        }
        if ($r->hasFile('image')) {
            $data['image_path'] = $r->file('image')->store('uploads/'.now()->format('Y/m'), 'public');
        }
        if ($resource === 'routes') {
            $gallery = $r->boolean('clear_gallery') ? [] : ($item->gallery ?? []);
            foreach ($r->file('gallery', []) as $file) {
                $gallery[] = $file->store('uploads/'.now()->format('Y/m'), 'public');
            }
            $data['gallery'] = array_slice($gallery, 0, 12);
            if ($r->boolean('clear_attachment')) {
                $data['attachment_path'] = null;
            }
            if ($r->hasFile('attachment')) {
                $data['attachment_path'] = $r->file('attachment')->store('uploads/'.now()->format('Y/m'), 'public');
            }
        }
        DB::transaction(function () use ($item, $data, $resource, $fareData) {
            $item->fill($data)->save();
            if ($resource === 'users' && isset($data['password'])) {
                $item->forceFill(['remember_token' => Str::random(60)])->save();
                app(StaffSessionService::class)->revoke($item, $item->id === auth()->id() ? request()->session()->getId() : null);
            }
            if ($resource === 'routes') {
                $item->vehicles()->sync($fareData);
            }
        });
        app()->forgetInstance('ride.content');

        return redirect()->route('admin.resource.edit', [$resource, $item->id])->with('success', __('ui.saved'));
    }

    private function cents(string $value): int
    {
        [$a,$b] = array_pad(explode('.', $value, 2), 2, '0');

        return (int) $a * 100 + (int) str_pad($b, 2, '0');
    }

    public function archive(Request $r, string $resource, int $id)
    {
        $model = $this->model($resource);
        $item = $model::findOrFail($id);
        if ($resource === 'users' && ($id === $r->user()->id || ($item->role === 'admin' && User::where('role', 'admin')->where('active', true)->count() <= 1))) {
            throw ValidationException::withMessages(['role' => __('ui.keep_admin')]);
        }
        $item->update(['active' => false]);
        app()->forgetInstance('ride.content');

        return redirect()->route('admin.resource.index', $resource)->with('success', __('ui.archived'));
    }

    public function destroy(Request $r, string $resource, int $id)
    {
        $model = $this->model($resource);
        $item = $model::findOrFail($id);
        $r->validate(['current_password' => 'required|current_password', 'confirm' => 'required|in:DELETE']);
        DB::transaction(function () use ($resource, $item, $r): void {
            $item->newQuery()->whereKey($item->id)->lockForUpdate()->firstOrFail();
            if ($resource === 'users') {
                if ($item->id === $r->user()->id || $item->role === 'admin' || Booking::where('driver_id', $item->id)->exists()
                    || Booking::where('completed_by', $item->id)->exists() || Booking::where('cash_collected_by', $item->id)->exists()
                    || BookingEvent::where('user_id', $item->id)->exists()) {
                    throw ValidationException::withMessages(['delete' => __('taxikh.delete_in_use')]);
                }
            }
            if (($resource === 'routes' && Booking::where('travel_route_id', $item->id)->exists())
                || ($resource === 'vehicles' && (Booking::where('vehicle_id', $item->id)->exists() || $item->routes()->exists()))) {
                throw ValidationException::withMessages(['delete' => __('taxikh.delete_in_use')]);
            }
            $item->delete();
        });
        app()->forgetInstance('ride.content');

        return redirect()->route('admin.resource.index', $resource)->with('success', __('taxikh.deleted'));
    }

    public function arrange(Request $r, string $resource)
    {
        abort_if($resource === 'users', 404);
        $model = $this->model($resource);
        $data = $r->validate(['items' => 'required|array|min:1|max:100', 'items.*.id' => 'required|integer|distinct',
            'items.*.active' => 'required|boolean', 'items.*.sort_order' => 'required|integer|min:0|max:9999']);
        DB::transaction(function () use ($data, $model): void {
            foreach ($data['items'] as $row) {
                $model::findOrFail($row['id'])->update(['active' => $row['active'], 'sort_order' => $row['sort_order']]);
            }
        });
        app()->forgetInstance('ride.content');

        return $r->expectsJson() ? response()->json(['message' => __('ui.saved')]) : redirect()->route('admin.resource.index', $resource)->with('success', __('ui.saved'));
    }
}
