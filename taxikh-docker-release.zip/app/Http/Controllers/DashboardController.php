<?php

namespace App\Http\Controllers;

use App\Http\Requests\DriverActionRequest;
use App\Jobs\SendTelegramDelivery;
use App\Models\Booking;
use App\Models\Inquiry;
use App\Models\TelegramDelivery;
use App\Models\User;
use App\Services\DispatchService;
use App\Services\DriverTripService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DashboardController extends Controller
{
    public function home(Request $r)
    {
        $driver = $r->user()->role === 'driver';
        $query = Booking::query()->when($driver, fn ($q) => $q->where('driver_id', $r->user()->id));
        $cash = Booking::where('payment_status', 'paid')->when($driver, fn ($q) => $q->where(fn ($q) => $q->where('cash_collected_by', $r->user()->id)->orWhere(fn ($q) => $q->whereNull('cash_collected_by')->where('driver_id', $r->user()->id))))->sum('total_cents');
        $stats = [
            'total' => (clone $query)->count(),
            'pending' => (clone $query)->where('status', $driver ? 'assigned' : 'pending')->count(),
            'upcoming' => (clone $query)->where('departure_at', '>=', now())->whereNotIn('status', ['completed', 'cancelled'])->count(),
            'completed' => (clone $query)->where('status', 'completed')->count(),
            'cash' => $cash,
        ];
        $selectedStatus = $r->input('status');
        $bookings = (clone $query)
            ->when($selectedStatus, fn ($q) => $q->where('status', $selectedStatus))
            ->with('driver')
            ->orderByDesc('created_at')
            ->limit(10)
            ->get();
        $reviewCount = $driver ? 0 : Booking::where('dispatch_review', true)->count();

        return view('admin.dashboard', compact('stats', 'bookings', 'driver', 'reviewCount', 'selectedStatus'));
    }

    private function filtered(Request $r)
    {
        $r->validate(['q' => 'nullable|string|max:100', 'status' => ['nullable', Rule::in(Booking::STATUSES)], 'date' => 'nullable|date_format:Y-m-d', 'dispatch_review' => 'nullable|boolean']);

        return Booking::query()->with('driver')->when($r->user()->role === 'driver', fn ($q) => $q->where('driver_id', $r->user()->id))
            ->when($r->filled('status'), fn ($q) => $q->where('status', $r->status))
            ->when($r->boolean('dispatch_review'), fn ($q) => $q->where('dispatch_review', true))
            ->when($r->filled('date'), fn ($q) => $q->whereBetween('departure_at', [Carbon::parse($r->date, 'Asia/Phnom_Penh')->startOfDay()->utc(), Carbon::parse($r->date, 'Asia/Phnom_Penh')->endOfDay()->utc()]))
            ->when($r->filled('q'), fn ($q) => $q->where(fn ($q) => $q->where('reference', 'like', '%'.$r->q.'%')->orWhere('customer_name', 'like', '%'.$r->q.'%')->orWhere('phone', 'like', '%'.$r->q.'%')));
    }

    public function bookings(Request $r)
    {
        $bookings = $this->filtered($r)->orderByDesc('created_at')->paginate(20)->withQueryString();

        return view('admin.bookings', compact('bookings'));
    }

    public function show(Request $r, int $booking)
    {
        $booking = Booking::with(['driver', 'completedBy', 'cashCollectedBy', 'events.user', 'deliveries'])->findOrFail($booking);
        abort_unless($r->user()->role !== 'driver' || $booking->driver_id === $r->user()->id, 403);
        $drivers = User::where('role', 'driver')->where('active', true)->orderBy('name')->get();

        return view('admin.booking', compact('booking', 'drivers'));
    }

    public function update(Request $r, int $booking, DispatchService $service)
    {
        $d = $r->validate(['status' => ['required', Rule::in(Booking::STATUSES)], 'driver_id' => 'nullable|integer', 'commission_rate' => 'nullable|numeric|between:0,100', 'actual_duration_minutes' => 'nullable|integer|min:1|max:2880', 'staff_notes' => 'nullable|string|max:4000', 'cash_received' => 'nullable|boolean', 'dispatch_version' => 'nullable|integer|min:0']);
        $service->update($booking, $r->user(), $d);

        return redirect()->route(($r->user()->role === 'driver' ? 'driver' : 'admin').'.booking', $booking)->with('success', __('ui.saved'));
    }

    public function driverAction(DriverActionRequest $request, int $booking, DriverTripService $service)
    {
        $updated = $service->act($booking, $request->user(), $request->validated());
        $redirect = $updated->driver_id === $request->user()->id ? route('driver.booking', $booking) : route('driver.bookings');
        $message = $request->input('action') === 'return' ? __('ui.return_sent') : __('ui.saved');
        if ($request->expectsJson()) {
            return response()->json(['message' => $message, 'status' => $updated->status, 'dispatch_review' => $updated->dispatch_review,
                'dispatch_version' => $updated->dispatch_version, 'redirect_url' => $redirect]);
        }

        return redirect($redirect)->with('success', $message);
    }

    public function resolveDispatch(Request $request, int $booking, DriverTripService $service)
    {
        $data = $request->validate(['dispatch_version' => 'required|integer|min:0', 'dispatch_note' => 'required|string|min:1|max:1000']);
        $service->resolveReview($booking, $request->user(), (int) $data['dispatch_version'], $data['dispatch_note']);

        return redirect()->route('admin.booking', $booking)->with('success', __('ui.saved'));
    }

    public function export(Request $r)
    {
        $q = $this->filtered($r)->latest();

        return response()->streamDownload(function () use ($q) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['Reference', 'Customer', 'Phone', 'People', 'Pickup', 'Dropoff', 'Departure Cambodia', 'Total USD', 'Payment', 'Status', 'Driver']);
            foreach ($q->cursor() as $b) {
                $row = [$b->reference, $b->customer_name, $b->phone, $b->people, $b->pickup, $b->dropoff, $b->localDeparture()->format('Y-m-d H:i'), number_format($b->total_cents / 100, 2, '.', ''), $b->payment_status, $b->status, $b->driver?->name];
                $row = array_map(fn ($v) => preg_match('/^[=+\-@\t\r]/', (string) $v) ? "'".$v : $v, $row);
                fputcsv($out, $row);
            }fclose($out);
        }, 'bookings-'.now()->format('Ymd').'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function alerts(Request $r)
    {
        if (! $r->expectsJson()) {
            return redirect()->route(($r->user()->role === 'driver' ? 'driver' : 'admin').'.home');
        }

        return response()->json(['unread' => $r->user()->alerts()->whereNull('read_at')->count(), 'items' => $r->user()->alerts()->with('booking:id,driver_id')->latest()->limit(20)->get()->map(fn ($a) => ['id' => $a->id, 'label' => __('ui.'.$a->kind).' · '.$a->message, 'read' => (bool) $a->read_at, 'url' => $a->booking && ($r->user()->role !== 'driver' || $a->booking->driver_id === $r->user()->id) ? url(($r->user()->role === 'driver' ? '/driver' : '/admin').'/bookings/'.$a->booking_id) : ($r->user()->role === 'driver' ? url('/driver') : url('/admin/inquiries'))])]);
    }

    public function readAlerts(Request $r)
    {
        $r->user()->alerts()->whereNull('read_at')->update(['read_at' => now()]);

        return response()->json(['ok' => true]);
    }

    public function notifications()
    {
        $deliveries = TelegramDelivery::with('booking')->latest()->paginate(25);

        return view('admin.notifications', compact('deliveries'));
    }

    public function retry(int $delivery)
    {
        $d = TelegramDelivery::findOrFail($delivery);
        abort_unless(in_array($d->status, ['failed', 'disabled', 'pending']), 422);
        $d->update(['status' => 'pending', 'attempts' => 0, 'last_error' => null]);
        SendTelegramDelivery::dispatch($d->id);

        return redirect()->route('admin.notifications')->with('success', __('ui.retry_queued'));
    }

    public function inquiries()
    {
        $inquiries = Inquiry::latest()->paginate(20);

        return view('admin.inquiries', compact('inquiries'));
    }

    public function inquiry(Request $r, int $inquiry)
    {
        $d = $r->validate(['status' => 'required|in:new,handled,archived']);
        Inquiry::findOrFail($inquiry)->update($d);

        return redirect()->route('admin.inquiries')->with('success', __('ui.saved'));
    }

    public function reports()
    {
        $months = collect(range(5, 0))->map(function ($i) {
            $start = now('Asia/Phnom_Penh')->startOfMonth()->subMonths($i);
            $end = $start->copy()->endOfMonth();
            $q = Booking::whereBetween('created_at', [$start->copy()->utc(), $end->copy()->utc()]);

            return [
                'label' => $start->format('M Y'),
                'count' => (clone $q)->count(),
                'booked' => (clone $q)->where('status', '!=', 'cancelled')->sum('total_cents'),
                'collected' => Booking::where('payment_status', 'paid')->whereBetween('paid_at', [$start->copy()->utc(), $end->copy()->utc()])->sum('total_cents'),
                'commission' => (clone $q)->where('status', '!=', 'cancelled')->sum('commission_cents'),
                'driver_payouts' => (clone $q)->where('status', '!=', 'cancelled')->sum('driver_payout_cents'),
                'overtime' => (clone $q)->where('status', '!=', 'cancelled')->sum('overtime_cents'),
            ];
        });

        return view('admin.reports', compact('months'));
    }
}
