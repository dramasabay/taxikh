<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;

class Locale
{
    public function handle(Request $request, Closure $next)
    {
        $locale = $request->route('locale') ?? ($request->hasSession() ? $request->session()->get('locale', 'en') : $request->input('locale', 'en'));
        app()->setLocale(in_array($locale, ['en', 'km', 'zh']) ? $locale : 'en');
        URL::defaults(['locale' => app()->getLocale()]);

        return $next($request);
    }
}
