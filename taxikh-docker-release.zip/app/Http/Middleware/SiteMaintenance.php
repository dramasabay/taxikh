<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class SiteMaintenance
{
    public function handle(Request $r, Closure $next)
    {
        if (! $r->is('admin', 'admin/*', 'driver', 'driver/*', 'staff/*', 'media/*', 'up') && setting('maintenance_enabled', '0') === '1') {
            $locale = $r->segment(1);
            app()->setLocale(in_array($locale, ['en', 'km', 'zh']) ? $locale : setting('default_language', 'en'));
            if ($r->expectsJson() || $r->is('api/*')) {
                return response()->json(['message' => __('taxikh.maintenance_message')], 503, ['Retry-After' => '3600']);
            }

            return response()->view('public.maintenance', [], 503, ['Retry-After' => '3600', 'X-Robots-Tag' => 'noindex']);
        }

        return $next($r);
    }
}
