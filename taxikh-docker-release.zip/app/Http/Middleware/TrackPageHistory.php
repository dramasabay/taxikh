<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Illuminate\Session\Middleware\StartSession;

class TrackPageHistory extends StartSession
{
    /**
     * Background JSON polls and uploaded images are not navigated pages.
     */
    protected function storeCurrentUrl(Request $request, $session): void
    {
        if ($request->expectsJson() || ! $request->acceptsHtml() || $request->is('staff/alerts', 'staff/language/*', 'media/*', 'api/*')) {
            return;
        }

        parent::storeCurrentUrl($request, $session);
    }
}
