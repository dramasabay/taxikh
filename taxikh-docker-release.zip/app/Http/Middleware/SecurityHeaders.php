<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class SecurityHeaders
{
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('X-Frame-Options', 'SAMEORIGIN');
        $response->headers->set('X-XSS-Protection', '0');
        $response->headers->set('Content-Security-Policy', implode('; ', [
            "default-src 'self'",
            "base-uri 'self'",
            "object-src 'none'",
            "frame-ancestors 'self'",
            "form-action 'self'",
            "script-src 'self' https://maps.googleapis.com https://maps.gstatic.com https://www.jscache.com https://jscache.com https://*.tripadvisor.com https://static.tacdn.com",
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://static.tacdn.com",
            "font-src 'self' https://fonts.gstatic.com https://static.tacdn.com",
            "img-src 'self' data: blob: https:",
            "connect-src 'self' https://*.googleapis.com https://*.gstatic.com https://*.google.com https://*.tripadvisor.com",
            "frame-src 'self' https://www.google.com https://google.com https://maps.google.com https://www.tripadvisor.com https://tripadvisor.com",
        ]));
        $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
        $response->headers->set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)');
        if ($request->isSecure()) {
            $response->headers->set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
        }
        if ($request->is('admin*', 'driver*', 'staff*', '*reservation*', 'booking*', 'api/v1/bookings*')) {
            $response->headers->set('Cache-Control', 'no-store, private');
            $response->headers->set('X-Robots-Tag', 'noindex, nofollow');
            $response->headers->set('Referrer-Policy', 'no-referrer');
        }

        return $response;
    }
}
