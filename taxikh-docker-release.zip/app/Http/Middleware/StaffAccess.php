<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class StaffAccess
{
    public function handle(Request $request, Closure $next, ...$roles)
    {
        if (! $request->user()) {
            return $request->expectsJson() ? response()->json(['message' => 'Unauthenticated.'], 401) : redirect()->route('login');
        }
        abort_unless($request->user()->active && in_array($request->user()->role, $roles), 403);

        return $next($request);
    }
}
