<?php

namespace App\Providers;

use App\Models\ContentItem;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        Paginator::defaultView('components.pagination');
        RateLimiter::for('system-tools', fn (Request $r) => Limit::perMinute(5)->by((string) $r->user()?->id));
        RateLimiter::for('booking', fn (Request $r) => Limit::perMinute(5)->by($r->ip()));
        RateLimiter::for('quote', fn (Request $r) => Limit::perMinute(90)->by($r->ip()));
        RateLimiter::for('login', function (Request $r) {
            $email = $r->input('email');
            $account = hash('sha256', is_string($email) ? mb_strtolower(trim($email)) : 'invalid');

            return [
                Limit::perMinute(20)->by('ip:'.$r->ip()),
                Limit::perMinute(5)->by('account:'.$account),
            ];
        });
        RateLimiter::for('password', fn (Request $r) => Limit::perMinute(5)->by((string) $r->user()?->id.'|'.$r->ip()));
        RateLimiter::for('inquiry', fn (Request $r) => Limit::perMinute(3)->by($r->ip()));
        View::composer(['layouts.public', 'public.*'], function ($view) {
            if (! app()->bound('ride.content')) {
                app()->instance('ride.content', ContentItem::published()->get()->groupBy('kind'));
            }
            $view->with('siteContent', app('ride.content'));
        });
    }
}
