<?php

namespace App\Services;

use App\Jobs\SendTelegramDelivery;
use App\Models\Alert;
use App\Models\Booking;
use App\Models\TelegramDelivery;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class AlertService
{
    public function booking(Booking $booking, string $event, bool $toDriver = false, array $context = []): void
    {
        $users = User::where('active', true)->whereIn('role', ['admin', 'dispatcher'])->get();
        foreach ($users as $user) {
            Alert::create(['user_id' => $user->id, 'booking_id' => $booking->id, 'kind' => $event, 'message' => $booking->reference]);
        }
        $this->delivery($booking, $event, 'group', null, $context);
        if ($toDriver && $booking->driver_id) {
            Alert::create(['user_id' => $booking->driver_id, 'booking_id' => $booking->id, 'kind' => $event, 'message' => $booking->reference]);
            $this->delivery($booking, $event, 'driver', $booking->driver_id, $context);
        }
    }

    private function delivery(Booking $booking, string $event, string $target, ?int $userId = null, array $context = []): void
    {
        $delivery = TelegramDelivery::create(['booking_id' => $booking->id, 'event' => $event, 'target' => $target, 'target_user_id' => $userId, 'context' => $context]);
        DB::afterCommit(function () use ($delivery) {
            try {
                SendTelegramDelivery::dispatch($delivery->id);
            } catch (\Throwable $e) {
                $delivery->update(['status' => 'failed', 'last_error' => 'Queue unavailable. Retry from notifications.']);
            }
        });
    }
}
