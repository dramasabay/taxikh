<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\BookingEvent;
use App\Models\Setting;
use Carbon\CarbonImmutable;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class BookingService
{
    public function __construct(private PricingService $pricing, private AlertService $alerts) {}

    public function create(array $data): Booking
    {
        $normalized = $data;
        unset($normalized['website']);
        $normalized['extras'] = array_values(array_unique(array_map('intval', $data['extras'] ?? [])));
        sort($normalized['extras']);
        ksort($normalized);
        $fingerprint = hash('sha256', json_encode($normalized));
        if ($existing = Booking::where('request_key', $data['request_key'])->first()) {
            return $this->replay($existing, $fingerprint);
        }
        if (Setting::get('booking_enabled', '1') !== '1') {
            throw ValidationException::withMessages(['booking' => __('ui.booking_paused')]);
        }
        $timezone = 'Asia/Phnom_Penh';
        $departure = CarbonImmutable::createFromFormat('!Y-m-d H:i', $data['departure_date'].' '.$data['departure_time'], $timezone);
        $min = (int) Setting::get('min_notice_hours', 2);
        if (! $departure || $departure->lessThan(now($timezone)->addHours($min)) || $departure->greaterThan(now($timezone)->addDays(365))) {
            throw ValidationException::withMessages(['departure_date' => __('ui.date_error', ['hours' => $min])]);
        }
        try {
            return DB::transaction(function () use ($data, $departure, $timezone, $fingerprint) {
                $quote = $this->pricing->quote((int) $data['route_id'], (int) $data['vehicle_id'], $data['extras'] ?? [], (int) $data['people']);
                $token = Str::random(48);
                $totalCents = $quote['total_cents'];
                $commRate = (float) Setting::get('default_driver_commission', '20.0');
                $commCents = (int) round($totalCents * ($commRate / 100));
                $driverPayoutCents = max(0, $totalCents - $commCents);

                $booking = Booking::create([
                    'reference' => 'MR-'.now()->format('ymd').'-'.strtoupper(Str::random(6)),
                    'request_key' => $data['request_key'], 'request_fingerprint' => $fingerprint,
                    'public_token' => $token, 'public_token_hash' => hash('sha256', $token),
                    'travel_route_id' => $quote['route_id'], 'vehicle_id' => $quote['vehicle_id'],
                    'locale' => $data['locale'], 'customer_name' => $data['customer_name'], 'phone' => $data['phone'],
                    'contact_method' => $data['contact_method'] ?? 'whatsapp',
                    'contact_handle' => $data['contact_handle'] ?? null,
                    'people' => $data['people'], 'pickup' => $data['pickup'], 'dropoff' => $data['dropoff'],
                    'pickup_lat' => $data['pickup_lat'] ?? null, 'pickup_lng' => $data['pickup_lng'] ?? null,
                    'pickup_place_id' => $data['pickup_place_id'] ?? null,
                    'dropoff_lat' => $data['dropoff_lat'] ?? null, 'dropoff_lng' => $data['dropoff_lng'] ?? null,
                    'dropoff_place_id' => $data['dropoff_place_id'] ?? null,
                    'departure_at' => $departure->utc(), 'estimated_end_at' => $departure->addMinutes($quote['duration_minutes'] + 60)->utc(),
                    'timezone' => $timezone, 'notes' => $data['notes'] ?? null, 'price_snapshot' => $quote,
                    'total_cents' => $totalCents, 'currency' => 'USD', 'payment_method' => 'cash_on_arrival',
                    'commission_rate' => $commRate, 'commission_cents' => $commCents,
                    'driver_payout_cents' => $driverPayoutCents, 'driver_agreed_commission' => false,
                    'payment_status' => 'unpaid', 'status' => 'pending',
                ]);
                BookingEvent::create(['booking_id' => $booking->id, 'action' => 'created']);
                $this->alerts->booking($booking, 'new_booking');

                return $booking;
            }, 3);
        } catch (UniqueConstraintViolationException $e) {
            $existing = Booking::where('request_key', $data['request_key'])->first();
            if (! $existing) {
                throw $e;
            }

            return $this->replay($existing, $fingerprint);
        }
    }

    private function replay(Booking $existing, string $fingerprint): Booking
    {
        abort_unless(hash_equals($existing->request_fingerprint, $fingerprint), 409, __('ui.duplicate_conflict'));

        return $existing;
    }
}
