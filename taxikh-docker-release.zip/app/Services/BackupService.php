<?php

namespace App\Services;

use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use ZipArchive;

class BackupService
{
    public const TABLES = ['users', 'settings', 'vehicles', 'travel_routes', 'extras', 'content_items', 'route_vehicle', 'bookings', 'booking_events', 'inquiries', 'alerts', 'telegram_deliveries'];

    public const OPERATIONAL = ['telegram_deliveries', 'alerts', 'inquiries', 'booking_events', 'bookings'];

    private const MAX_BYTES = 209715200;

    public function directory(): string
    {
        $path = storage_path('app/private/backups');
        if (! is_dir($path) && ! mkdir($path, 0700, true) && ! is_dir($path)) {
            throw new \RuntimeException('Cannot create backup directory.');
        }

        return $path;
    }

    public function exclusive(callable $callback): mixed
    {
        $handle = fopen($this->directory().'/system.lock', 'c');
        if (! $handle) {
            throw new \RuntimeException('Cannot open system lock.');
        }
        if (! flock($handle, LOCK_EX | LOCK_NB)) {
            fclose($handle);
            throw ValidationException::withMessages(['system' => __('taxikh.system_busy')]);
        }
        try {
            return $callback();
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    public function create(): string
    {
        $name = 'taxikh-backup-'.now()->format('Ymd-His').'-'.Str::lower(Str::random(12)).'.zip';
        $path = $this->directory().'/'.$name;
        $zip = new ZipArchive;
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::EXCL) !== true) {
            throw new \RuntimeException('Cannot write backup.');
        }
        $closed = false;
        try {
            $manifest = DB::transaction(function (): array {
                $tables = [];
                $schema = [];
                foreach (self::TABLES as $table) {
                    $tables[$table] = DB::table($table)->get()->map(fn ($row) => (array) $row)->all();
                    $schema[$table] = Schema::getColumnListing($table);
                }

                return ['format' => 'TAXIKH-1', 'created_at' => now()->toIso8601String(), 'tables' => $tables, 'schema' => $schema,
                    'migrations' => DB::table('migrations')->orderBy('migration')->pluck('migration')->all(), 'media' => []];
            });
            $size = 0;
            foreach (Storage::disk('public')->allFiles('uploads') as $file) {
                if (! $this->validMediaPath($file)) {
                    continue;
                }
                $full = Storage::disk('public')->path($file);
                if (is_link($full)) {
                    throw ValidationException::withMessages(['backup' => __('taxikh.backup_invalid')]);
                }
                $size += filesize($full);
                if ($size > self::MAX_BYTES) {
                    throw ValidationException::withMessages(['backup' => __('taxikh.backup_size')]);
                }
                $manifest['media'][$file] = hash_file('sha256', $full);
                if (! $zip->addFile($full, 'media/'.$file)) {
                    throw new \RuntimeException('Cannot read backup media.');
                }
            }
            $json = json_encode($manifest, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
            if (strlen($json) > 40000000) {
                throw ValidationException::withMessages(['backup' => __('taxikh.backup_size')]);
            }
            // Authentication + encryption prevents altered SQL/data or exposed passwords in the manifest.
            if (! $zip->addFromString('database.enc', Crypt::encryptString($json))) {
                throw new \RuntimeException('Cannot write backup manifest.');
            }
            if (! $zip->close()) {
                throw new \RuntimeException('Cannot finish backup.');
            }
            $closed = true;
            if (filesize($path) > 134217728) {
                throw ValidationException::withMessages(['backup' => __('taxikh.backup_size')]);
            }
            chmod($path, 0600);

            return $name;
        } catch (\Throwable $e) {
            if (! $closed) {
                try {
                    $zip->close();
                } catch (\Throwable) {
                }
            }
            if (is_file($path)) {
                unlink($path);
            }
            throw $e;
        }
    }

    private function validMediaPath(string $path): bool
    {
        return (bool) preg_match('~^uploads/[0-9]{4}/[0-9]{2}/[A-Za-z0-9]+\.(jpg|jpeg|png|webp|pdf)$~', $path);
    }

    private function inspect(ZipArchive $zip, User $admin): array
    {
        $bad = fn () => ValidationException::withMessages(['backup' => __('taxikh.backup_invalid')]);
        if ($zip->numFiles > 20001) {
            throw $bad();
        }
        $total = 0;
        $names = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = $stat['name'];
            $total += $stat['size'];
            if (isset($names[$name]) || ($name !== 'database.enc' && (! str_starts_with($name, 'media/') || ! $this->validMediaPath(substr($name, 6))))) {
                throw $bad();
            }
            $names[$name] = true;
        }
        if ($total > self::MAX_BYTES + 60000000 || ($zip->statName('database.enc')['size'] ?? PHP_INT_MAX) > 60000000) {
            throw $bad();
        }
        try {
            $manifest = json_decode(Crypt::decryptString($zip->getFromName('database.enc')), true, 512, JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            throw $bad();
        }
        if (($manifest['format'] ?? '') !== 'TAXIKH-1' || array_keys($manifest['tables'] ?? []) !== self::TABLES
            || ($manifest['migrations'] ?? []) !== DB::table('migrations')->orderBy('migration')->pluck('migration')->all()) {
            throw $bad();
        }
        foreach (self::TABLES as $table) {
            $columns = Schema::getColumnListing($table);
            if (($manifest['schema'][$table] ?? []) !== $columns || ! is_array($manifest['tables'][$table])) {
                throw $bad();
            }
            foreach ($manifest['tables'][$table] as $row) {
                if (! is_array($row) || array_diff(array_keys($row), $columns) || count($row) !== count($columns)) {
                    throw $bad();
                }
            }
        }
        $owner = collect($manifest['tables']['users'])->first(fn ($u) => (int) $u['id'] === $admin->id && $u['email'] === $admin->email && $u['role'] === 'admin' && $u['active']);
        if (! $owner) {
            throw ValidationException::withMessages(['backup' => __('taxikh.backup_admin_missing')]);
        }
        if (! is_array($manifest['media'] ?? null) || count($manifest['media']) + 1 !== count($names)) {
            throw $bad();
        }
        foreach ($manifest['media'] as $path => $hash) {
            if (! $this->validMediaPath($path) || ! isset($names['media/'.$path])) {
                throw $bad();
            }
            $stream = $zip->getStream('media/'.$path);
            if (! $stream) {
                throw $bad();
            }
            $ctx = hash_init('sha256');
            hash_update_stream($ctx, $stream);
            fclose($stream);
            if (! is_string($hash) || ! hash_equals($hash, hash_final($ctx))) {
                throw $bad();
            }
            $full = Storage::disk('public')->path($path);
            // Upload names are immutable. Refuse conflicting files instead of overwriting them.
            if (is_link($full) || (is_file($full) && ! hash_equals($hash, hash_file('sha256', $full)))) {
                throw ValidationException::withMessages(['backup' => __('taxikh.backup_media_conflict')]);
            }
        }

        return $manifest;
    }

    public function restore(string $path, User $admin): string
    {
        $zip = new ZipArchive;
        if ($zip->open($path) !== true) {
            throw ValidationException::withMessages(['backup' => __('taxikh.backup_invalid')]);
        }
        $added = [];
        try {
            $manifest = $this->inspect($zip, $admin);
            $safety = $this->create();
            foreach ($manifest['media'] as $path => $hash) {
                if (Storage::disk('public')->exists($path)) {
                    continue;
                }
                $stream = $zip->getStream('media/'.$path);
                try {
                    if (! Storage::disk('public')->put($path, $stream)) {
                        Storage::disk('public')->delete($path);
                        throw new \RuntimeException('Cannot restore media.');
                    }
                } finally {
                    if (is_resource($stream)) {
                        fclose($stream);
                    }
                }
                $added[] = $path;
            }
            DB::transaction(function () use ($manifest): void {
                foreach (array_reverse(self::TABLES) as $table) {
                    DB::table($table)->delete();
                }
                foreach (self::TABLES as $table) {
                    foreach (array_chunk($manifest['tables'][$table], 100) as $rows) {
                        DB::table($table)->insert($rows);
                    }
                }
                // Session and job payloads are deliberately never restored or executed.
                foreach (['sessions', 'password_reset_tokens', 'jobs', 'failed_jobs'] as $table) {
                    DB::table($table)->delete();
                }
                DB::table('telegram_deliveries')->whereIn('status', ['pending', 'sending', 'failed'])->update(['status' => 'cancelled', 'last_error' => 'Paused by backup restore; review before retry.']);
                Setting::put('maintenance_enabled', '1');
            });
            app()->forgetInstance('ride.content');
            app()->forgetInstance('ride.settings');

            return $safety;
        } catch (\Throwable $e) {
            foreach ($added as $path) {
                Storage::disk('public')->delete($path);
            }
            if ($e instanceof QueryException) {
                throw ValidationException::withMessages(['backup' => __('taxikh.backup_invalid')]);
            }
            throw $e;
        } finally {
            $zip->close();
        }
    }

    public function clear(string $scope): string
    {
        $safety = $this->create();
        DB::transaction(function () use ($scope): void {
            foreach (self::OPERATIONAL as $table) {
                DB::table($table)->delete();
            }
            foreach (['jobs', 'failed_jobs'] as $table) {
                DB::table($table)->delete();
            }
            if ($scope === 'reset') {
                Setting::put('catalogue_initialized', '1');
            }
            if ($scope === 'reset') {
                foreach (['route_vehicle', 'extras', 'travel_routes', 'vehicles', 'content_items'] as $table) {
                    DB::table($table)->delete();
                }
            }
        });
        app()->forgetInstance('ride.content');

        return $safety;
    }
}
