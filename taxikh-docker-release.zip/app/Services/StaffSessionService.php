<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\DB;

class StaffSessionService
{
    /** Remove existing database sessions, including sessions created before auth.session was enabled. */
    public function revoke(User $user, ?string $keepSession = null): void
    {
        if (config('session.driver') !== 'database') {
            return;
        }

        DB::connection(config('session.connection'))
            ->table(config('session.table', 'sessions'))
            ->where('user_id', $user->id)
            ->when($keepSession !== null, fn ($query) => $query->where('id', '!=', $keepSession))
            ->delete();
    }
}
