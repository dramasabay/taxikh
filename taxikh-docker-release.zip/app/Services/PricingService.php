<?php

namespace App\Services;

use App\Models\Extra;
use App\Models\TravelRoute;
use Illuminate\Validation\ValidationException;

class PricingService
{
    public function quote(int $routeId, int $vehicleId, array $extraIds = [], int $people = 1): array
    {
        $route = TravelRoute::where('active', true)->find($routeId);
        if (! $route) {
            throw ValidationException::withMessages(['route_id' => __('ui.route_unavailable')]);
        }
        $vehicle = $route->vehicles()->where('vehicles.active', true)->where('vehicles.id', $vehicleId)->first();
        if (! $vehicle) {
            throw ValidationException::withMessages(['vehicle_id' => __('ui.vehicle_unavailable')]);
        }
        if ($people > $vehicle->passengers || $people < 1) {
            throw ValidationException::withMessages(['people' => __('ui.capacity_error', ['count' => $vehicle->passengers])]);
        }
        $ids = array_values(array_unique(array_map('intval', $extraIds)));
        $extras = Extra::where('active', true)->where(fn ($q) => $q->whereNull('travel_route_id')->orWhere('travel_route_id', $routeId))->whereIn('id', $ids)->get();
        if ($extras->count() !== count($ids)) {
            throw ValidationException::withMessages(['extras' => __('ui.extra_unavailable')]);
        }

        $totalCents = (int) $vehicle->pivot->price_cents + (int) $extras->sum('price_cents');
        $baseCents = (int) $vehicle->pivot->price_cents;
        $extrasCents = (int) $extras->sum('price_cents');

        return [
            'route_id' => $route->id, 'vehicle_id' => $vehicle->id, 'route_title' => $route->title, 'vehicle_title' => $vehicle->title,
            'base_cents' => $baseCents, 'total_cents' => $totalCents, 'extras_cents' => $extrasCents,
            'formatted_total' => money($totalCents), 'formatted_base' => money($baseCents), 'formatted_extras' => money($extrasCents),
            'total_riel' => money_riel($totalCents),
            'extras' => $extras->map(fn ($e) => ['id' => $e->id, 'title' => $e->title, 'price_cents' => $e->price_cents, 'destination' => $e->destination])->all(),
            'currency' => 'USD', 'duration_minutes' => $route->duration_minutes, 'capacity' => $vehicle->passengers,
        ];
    }
}
