<?php

namespace App\Services;

use DOMDocument;
use Illuminate\Validation\ValidationException;

class EmbedService
{
    /** Keep only a provider URL; pasted attributes and inline code never enter our page. */
    public function parse(?string $input, string $provider, string $field): array
    {
        $input = trim($input ?? '');
        if ($input === '') {
            return [];
        }
        $url = $input;
        $kind = 'iframe';
        if (str_contains($input, '<')) {
            $doc = new DOMDocument;
            $previous = libxml_use_internal_errors(true);
            try {
                $doc->loadHTML('<?xml encoding="utf-8" ?>'.$input, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
                $frame = $doc->getElementsByTagName('iframe')->item(0);
                $script = $doc->getElementsByTagName('script')->item(0);
                if ($frame) {
                    $url = $frame->getAttribute('src');
                } elseif ($provider === 'tripadvisor' && $script) {
                    $url = $script->getAttribute('src');
                    $kind = 'widget';
                } else {
                    $url = '';
                }
            } finally {
                libxml_clear_errors();
                libxml_use_internal_errors($previous);
            }
        }
        $url = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $parts = parse_url($url);
        $host = strtolower($parts['host'] ?? '');
        $path = $parts['path'] ?? '';
        parse_str($parts['query'] ?? '', $query);
        $valid = is_array($parts) && ($parts['scheme'] ?? '') === 'https' && ! isset($parts['user']) && ! isset($parts['pass']) && ! isset($parts['port']) && ! preg_match('/[\x00-\x20]/', $url);
        if ($provider === 'google') {
            $valid = $valid && in_array($host, ['www.google.com', 'google.com', 'maps.google.com'], true)
                && (($path === '/maps/embed' && ! empty($query['pb']) && is_string($query['pb'])) || ($path === '/maps/d/embed' && ! empty($query['mid']) && is_string($query['mid']))) && ! isset($query['key']);
        } elseif ($kind === 'widget') {
            $valid = $valid && in_array($host, ['www.jscache.com', 'jscache.com'], true) && $path === '/wejs'
                && isset($query['wtype'],$query['uniq'],$query['locationId']) && is_string($query['wtype']) && preg_match('/^[a-zA-Z0-9_]{1,60}$/', $query['wtype'])
                && is_string($query['uniq']) && ctype_digit($query['uniq']) && is_string($query['locationId']) && ctype_digit($query['locationId']);
        } else {
            $valid = $valid && in_array($host, ['www.tripadvisor.com', 'tripadvisor.com'], true) && str_starts_with($path, '/WidgetEmbed');
        }
        if (! $valid) {
            throw ValidationException::withMessages([$field => __('taxikh.embed_invalid')]);
        }

        return ['kind' => $kind, 'url' => $url];
    }

    public function widgetDocument(array $embed): string
    {
        parse_str(parse_url($embed['url'], PHP_URL_QUERY) ?? '', $query);
        $id = 'TA_'.$query['wtype'].$query['uniq'];

        return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:white"><div id="'.e($id).'" class="TA_'.e($query['wtype']).'"><a href="https://www.tripadvisor.com/" target="_blank">Tripadvisor</a></div><script async src="'.e($embed['url']).'"></script></body></html>';
    }
}
