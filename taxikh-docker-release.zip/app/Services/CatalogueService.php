<?php

namespace App\Services;

use App\Models\TravelRoute;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class CatalogueService
{
    public function catalogue(): Collection
    {
        return TravelRoute::published()->whereHas('vehicles', fn ($q) => $q->where('vehicles.active', true))->get(['id', 'slug', 'origin', 'destination', 'type']);
    }

    public function cities(Collection $catalogue, string $field): Collection
    {
        return $catalogue->map(fn ($trip) => ['value' => $trip->text($field, 'en'), 'label' => $trip->text($field), 'aliases' => array_values($trip->$field)])->unique('value')->sortBy('label')->values();
    }

    public function query(Request $request): Builder
    {
        $query = TravelRoute::published()->with(['vehicles' => fn ($q) => $q->where('vehicles.active', true)])->whereHas('vehicles', fn ($q) => $q->where('vehicles.active', true));
        foreach (['from' => 'origin', 'to' => 'destination'] as $key => $column) {
            if ($request->filled($key)) {
                $query->where(function ($q) use ($request, $key, $column): void {
                    foreach (['en', 'km', 'zh'] as $locale) {
                        $q->orWhere($column.'->'.$locale, $request->input($key));
                    }
                });
            }
        }
        if ($request->filled('type')) {
            $query->where('type', $request->input('type'));
        }
        if ($request->filled('q')) {
            $term = '%'.$request->input('q').'%';
            $query->where(function ($q) use ($term): void {
                foreach (['title', 'origin', 'destination'] as $col) {
                    foreach (['en', 'km', 'zh'] as $loc) {
                        $q->orWhere($col.'->'.$loc, 'like', $term);
                    }
                }
            });
        }
        $sort = $request->input('sort', setting('routes_sort', 'recommended'));
        $query->reorder();
        if (in_array($sort, ['price_asc', 'price_desc'], true)) {
            $query->addSelect(['travel_routes.*'])->selectSub(function ($q): void {
                $q->from('route_vehicle')->join('vehicles', 'vehicles.id', '=', 'route_vehicle.vehicle_id')->selectRaw('MIN(route_vehicle.price_cents)')->whereColumn('route_vehicle.travel_route_id', 'travel_routes.id')->where('vehicles.active', true);
            }, 'starting_price')->orderBy('starting_price', $sort === 'price_asc' ? 'asc' : 'desc');
        } elseif ($sort === 'duration') {
            $query->orderBy('duration_minutes');
        } elseif ($sort === 'name') {
            $query->orderBy('title->'.app()->getLocale());
        } else {
            $query->orderByDesc('featured')->orderBy('sort_order');
        }

        return $query->orderBy('id');
    }

    public function pageSize(): int
    {
        return max(2, min(5, (int) setting('routes_columns', 3))) * max(1,min(6,(int) setting('routes_rows',3)));
    }
}
