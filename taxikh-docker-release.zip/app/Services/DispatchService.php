<?php

namespace App\Services;

use App\Models\Alert;
use App\Models\Booking;
use App\Models\BookingEvent;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DispatchService
{
    public function __construct(private AlertService $alerts) {}

    public function update(int $id, User $actor, array $data): Booking
    {
        return DB::transaction(function () use ($id, $actor, $data) {
            $b = Booking::lockForUpdate()->findOrFail($id);
            abort_unless(in_array($actor->role, ['admin', 'dispatcher', 'driver'], true) && $actor->active, 403);
            $isDriver = $actor->role === 'driver';
            abort_unless(! $isDriver || $b->driver_id === $actor->id, 403);
            if (($isDriver && ! isset($data['dispatch_version'])) || (isset($data['dispatch_version']) && (int) $data['dispatch_version'] !== $b->dispatch_version)) {
                throw ValidationException::withMessages(['status' => __('ui.trip_changed')]);
            }
            $next = $data['status'];
            $allowed = [
                'pending' => ['confirmed', 'assigned', 'cancelled'],
                'confirmed' => ['pending', 'assigned', 'on_the_way', 'in_progress', 'completed', 'cancelled'],
                'assigned' => ['confirmed', 'on_the_way', 'in_progress', 'completed', 'cancelled'],
                'on_the_way' => ['assigned', 'in_progress', 'completed', 'cancelled'],
                'in_progress' => ['on_the_way', 'completed', 'cancelled'],
                'completed' => ['in_progress', 'confirmed'],
                'cancelled' => ['pending', 'confirmed'],
            ];
            $driverAllowed = ['assigned' => ['on_the_way'], 'on_the_way' => ['in_progress'], 'in_progress' => ['completed']];
            if ($next !== $b->status && ! in_array($next, ($isDriver ? $driverAllowed : $allowed)[$b->status] ?? [])) {
                throw ValidationException::withMessages(['status' => __('ui.invalid_transition')]);
            }
            $oldDriver = $b->driver_id;
            $driverId = $isDriver ? $b->driver_id : (array_key_exists('driver_id', $data) ? $data['driver_id'] : $b->driver_id);
            $driverId = $driverId ? (int) $driverId : null;
            if (in_array($b->status, ['completed', 'cancelled']) && (int) $driverId !== (int) $b->driver_id) {
                throw ValidationException::withMessages(['driver_id' => __('ui.invalid_transition')]);
            }
            if ($next === 'assigned' && ! $driverId) {
                throw ValidationException::withMessages(['driver_id' => __('ui.select_driver')]);
            }
            if (in_array($next, ['on_the_way', 'in_progress', 'completed']) && ! $driverId) {
                throw ValidationException::withMessages(['driver_id' => __('ui.select_driver')]);
            }
            if ($driverId) {
                $driver = User::where('role', 'driver')->where('active', true)->lockForUpdate()->find($driverId);
                if (! $driver) {
                    throw ValidationException::withMessages(['driver_id' => __('ui.select_driver')]);
                }
                if (! in_array($next, ['completed', 'cancelled']) && Booking::where('driver_id', $driverId)->where('id', '!=', $b->id)->whereNotIn('status', ['completed', 'cancelled'])->where('departure_at', '<', $b->estimated_end_at)->where('estimated_end_at', '>', $b->departure_at)->exists()) {
                    throw ValidationException::withMessages(['driver_id' => __('ui.driver_busy')]);
                }
            }
            $oldStatus = $b->status;
            $oldPaid = $b->payment_status;
            $updates = ['status' => $next, 'driver_id' => $driverId];
            if (! $isDriver && array_key_exists('staff_notes', $data)) {
                $updates['staff_notes'] = $data['staff_notes'];
            }
            if (! $isDriver && array_key_exists('commission_rate', $data) && $data['commission_rate'] !== null) {
                $rate = max(0, min(100, (float) $data['commission_rate']));
                $updates['commission_rate'] = $rate;
                $updates['commission_cents'] = (int) round($b->total_cents * ($rate / 100));
                $updates['driver_payout_cents'] = max(0, $b->total_cents - $updates['commission_cents']);
            }
            if ($oldDriver !== $driverId) {
                $updates += ['dispatch_version' => $b->dispatch_version + 1, 'driver_accepted_at' => null, 'driver_agreed_commission' => false, 'dispatch_review' => false];
                if ($next === 'assigned') {
                    $updates['on_the_way_at'] = null;
                }
            } elseif ($b->dispatch_review && in_array($next, ['completed', 'cancelled'], true)) {
                $updates += ['dispatch_version' => $b->dispatch_version + 1, 'dispatch_review' => false];
            }
            if ($isDriver && ! $b->driver_accepted_at && in_array($next, ['on_the_way', 'in_progress'], true)) {
                $updates['driver_accepted_at'] = now();
                $updates['driver_agreed_commission'] = true;
            }
            if ($next === 'on_the_way' && ! $b->on_the_way_at) {
                $updates['on_the_way_at'] = now();
            }
            if ($next === 'in_progress' && ! $b->picked_up_at) {
                $updates['picked_up_at'] = now();
            }
            if ($next === 'completed' && $oldStatus !== 'completed') {
                $updates += [
                    'completed_at' => now(),
                    'completed_by' => $actor->id,
                    'completion_note' => $data['completion_note'] ?? null,
                    'estimated_end_at' => now(),
                    'driver_accepted_at' => $b->driver_accepted_at ?? now(),
                    'driver_agreed_commission' => true,
                    'on_the_way_at' => $b->on_the_way_at ?? now(),
                    'picked_up_at' => $b->picked_up_at ?? now(),
                ];
                // A completed trip may be reopened by staff. Recalculate from its
                // original fare so completing it again cannot compound overtime.
                $baseTotal = max(0, $b->total_cents - (int) $b->overtime_cents);
                $updates['overtime_minutes'] = 0;
                $updates['overtime_cents'] = 0;
                $updates['total_cents'] = $baseTotal;
                $actualDuration = $data['actual_duration_minutes'] ?? $b->actual_duration_minutes;
                if ($actualDuration !== null && (int) $actualDuration > 0) {
                    $actual = (int) $actualDuration;
                    $updates['actual_duration_minutes'] = $actual;
                    if ($b->route && $b->route->overtime_enabled) {
                        $scheduled = (int) $b->route->duration_minutes;
                        if ($actual > $scheduled) {
                            $extraMinutes = $actual - $scheduled;
                            $interval = max(1, (int) $b->route->overtime_interval_minutes);
                            $rate = (int) $b->route->overtime_rate_cents;
                            $intervals = (int) ceil($extraMinutes / $interval);
                            $overtimeCents = $intervals * $rate;
                            $updates['overtime_minutes'] = $extraMinutes;
                            $updates['overtime_cents'] = $overtimeCents;
                            $newTotal = $baseTotal + $overtimeCents;
                            $updates['total_cents'] = $newTotal;
                        }
                    }
                }
                $cRate = (float) ($updates['commission_rate'] ?? $b->commission_rate ?? 20.0);
                $updates['commission_cents'] = (int) round($updates['total_cents'] * ($cRate / 100));
                $updates['driver_payout_cents'] = max(0, $updates['total_cents'] - $updates['commission_cents']);
                foreach (['completion_lat', 'completion_lng', 'completion_accuracy_m'] as $field) {
                    $updates[$field] = $data[$field] ?? null;
                }
                $updates['completion_captured_at'] = isset($data['completion_captured_at']) ? CarbonImmutable::createFromTimestampUTC((int) $data['completion_captured_at']) : null;
            }
            // Collection is a separate record from trip completion, and cannot be claimed before pickup.
            if (($data['cash_received'] ?? false) && ! in_array($next, ['in_progress', 'completed'])) {
                throw ValidationException::withMessages(['cash_received' => __('ui.cash_too_early')]);
            }
            if ($data['cash_received'] ?? false) {
                $updates['payment_status'] = 'paid';
                $updates['paid_at'] = $b->paid_at ?? now();
                if ($oldPaid !== 'paid') {
                    $updates['cash_collected_by'] = $actor->id;
                }
            }
            $b->fill($updates);
            if (! $b->isDirty()) {
                return $b;
            }
            $b->save();
            $event = $oldDriver !== $driverId ? 'driver_assigned' : ($oldStatus !== $next ? match ($next) {
                'completed' => 'trip_completed', 'on_the_way' => 'driver_on_the_way', 'in_progress' => 'passenger_picked_up', default => 'booking_updated',
            } : 'booking_updated');
            $details = ['from' => $oldStatus, 'to' => $next, 'driver_from' => $oldDriver, 'driver_to' => $driverId, 'payment_from' => $oldPaid, 'payment_to' => $b->payment_status];
            $context = ['actor' => $actor->name, 'status' => $next, 'payment' => $b->payment_status];
            if ($event === 'trip_completed') {
                $context += ['completed_at' => $b->completed_at->timezone('Asia/Phnom_Penh')->format('d M Y H:i').' (Cambodia)',
                    'completion_note' => $b->completion_note, 'location_url' => $b->completionMapUrl(), 'accuracy_m' => $b->completion_accuracy_m];
                $details += $context;
            }
            BookingEvent::create(['booking_id' => $b->id, 'user_id' => $actor->id, 'action' => $event === 'trip_completed' ? $event : 'updated', 'details' => $details]);
            if ($oldDriver && $oldDriver != $driverId) {
                Alert::create(['user_id' => $oldDriver, 'kind' => 'assignment_removed', 'message' => $b->reference]);
            }
            if ($oldStatus !== $next || $oldDriver != $driverId || $oldPaid !== $b->payment_status) {
                $this->alerts->booking($b, $event, true, $context);
            }

            return $b;
        }, 3);
    }
}
