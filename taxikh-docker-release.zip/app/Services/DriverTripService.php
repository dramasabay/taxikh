<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\BookingEvent;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DriverTripService
{
    public function __construct(private DispatchService $dispatch, private AlertService $alerts) {}

    public function act(int $id, User $driver, array $data): Booking
    {
        abort_unless($driver->role === 'driver' && $driver->active, 403);

        return DB::transaction(function () use ($id, $driver, $data): Booking {
            $booking = Booking::lockForUpdate()->findOrFail($id);
            abort_unless($booking->driver_id === $driver->id, 403);
            $this->checkVersion($booking, (int) $data['dispatch_version']);
            $action = $data['action'];
            if ($action === 'accept') {
                $this->requireStatus($booking, ['assigned', 'on_the_way', 'in_progress']);
                if (! $booking->driver_accepted_at || ! $booking->driver_agreed_commission) {
                    $booking->update([
                        'driver_accepted_at' => $booking->driver_accepted_at ?? now(),
                        'driver_agreed_commission' => true,
                    ]);
                    $this->record($booking, $driver, 'driver_accepted', [
                        'commission_rate' => $booking->commission_rate,
                        'commission_cents' => $booking->commission_cents,
                        'driver_payout_cents' => $booking->driver_payout_cents,
                    ]);
                }

                return $booking;
            }
            if ($action === 'return') {
                $this->requireStatus($booking, ['assigned', 'on_the_way', 'in_progress']);
                if ($booking->dispatch_review) {
                    return $booking;
                }
                $reason = trim((string) ($data['reason'] ?? ''));
                if ($reason === '' || mb_strlen($reason) > 1000) {
                    throw ValidationException::withMessages(['reason' => __('ui.return_reason_required')]);
                }
                $oldStatus = $booking->status;
                $release = $oldStatus !== 'in_progress';
                $updates = ['dispatch_review' => true, 'dispatch_reason' => $reason, 'dispatch_requested_at' => now(),
                    'dispatch_version' => $booking->dispatch_version + 1];
                if ($release) {
                    $updates += ['status' => 'confirmed', 'driver_id' => null, 'driver_accepted_at' => null, 'on_the_way_at' => null];
                }
                $booking->update($updates);
                $this->record($booking, $driver, $release ? 'driver_returned' : 'driver_help_requested',
                    ['reason' => $reason, 'from' => $oldStatus, 'to' => $booking->status]);

                return $booking;
            }
            $next = match ($action) {
                'on_the_way' => 'on_the_way', 'pickup' => 'in_progress', 'complete' => 'completed',
                'collect_cash' => $booking->status, default => null,
            };
            if ($action === 'collect_cash') {
                $this->requireStatus($booking, ['in_progress', 'completed']);

                return $this->dispatch->update($id, $driver, ['status' => $next, 'cash_received' => true, 'dispatch_version' => $booking->dispatch_version]);
            }
            if ($next === $booking->status) {
                return $booking;
            }
            $this->requireStatus($booking, match ($action) {
                'on_the_way' => ['assigned'], 'pickup' => ['on_the_way'], 'complete' => ['in_progress'], default => [],
            });
            if (! $booking->driver_accepted_at) {
                throw ValidationException::withMessages(['action' => __('ui.accept_first')]);
            }
            if ($action === 'complete' && ($data['completion_lat'] ?? null) !== null) {
                $captured = (int) ($data['completion_captured_at'] ?? 0);
                if ($captured < now()->timestamp - 300 || $captured > now()->timestamp + 60) {
                    throw ValidationException::withMessages(['completion_lat' => __('ui.location_stale')]);
                }
            }

            return $this->dispatch->update($id, $driver, [...$data, 'status' => $next]);
        }, 3);
    }

    public function resolveReview(int $id, User $actor, int $version, string $note): Booking
    {
        abort_unless(in_array($actor->role, ['admin', 'dispatcher'], true) && $actor->active, 403);

        return DB::transaction(function () use ($id, $actor, $version, $note): Booking {
            $booking = Booking::lockForUpdate()->findOrFail($id);
            $this->checkVersion($booking, $version);
            if (! $booking->dispatch_review) {
                return $booking;
            }
            if (! $booking->driver_id && ! in_array($booking->status, ['completed', 'cancelled'], true)) {
                throw ValidationException::withMessages(['driver_id' => __('ui.reassign_first')]);
            }
            $booking->update(['dispatch_review' => false, 'dispatch_version' => $booking->dispatch_version + 1]);
            $this->record($booking, $actor, 'dispatch_resolved', ['reason' => $note], true);

            return $booking;
        }, 3);
    }

    private function checkVersion(Booking $booking, int $version): void
    {
        if ($booking->dispatch_version !== $version) {
            throw ValidationException::withMessages(['action' => __('ui.trip_changed')]);
        }
    }

    private function requireStatus(Booking $booking, array $statuses): void
    {
        if (! in_array($booking->status, $statuses, true)) {
            throw ValidationException::withMessages(['action' => __('ui.invalid_transition')]);
        }
    }

    private function record(Booking $booking, User $actor, string $action, array $details = [], bool $notifyDriver = false): void
    {
        $context = ['actor' => $actor->name, 'status' => $booking->status, ...$details];
        BookingEvent::create(['booking_id' => $booking->id, 'user_id' => $actor->id, 'action' => $action, 'details' => $context]);
        $this->alerts->booking($booking, $action, $notifyDriver, $context);
    }
}
