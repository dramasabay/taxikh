<?php

namespace App\Services;

use App\Models\Setting;
use App\Models\TelegramDelivery;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class TelegramService
{
    public function send(int $id): bool
    {
        $delivery = DB::transaction(function () use ($id) {
            $d = TelegramDelivery::lockForUpdate()->find($id);
            if (! $d || in_array($d->status, ['sent', 'cancelled'])) {
                return null;
            }
            if ($d->status === 'sending' && $d->updated_at->greaterThan(now()->subMinute())) {
                return null;
            }
            $d->update(['status' => 'sending', 'attempts' => $d->attempts + 1]);

            return $d;
        });
        if (! $delivery) {
            return true;
        }
        $booking = $delivery->booking;
        if (! $booking || ($delivery->target === 'driver' && (! $delivery->target_user_id || $booking->driver_id !== $delivery->target_user_id || ! $delivery->targetUser?->active))) {
            $delivery->update(['status' => 'cancelled', 'last_error' => 'Assignment changed.']);

            return true;
        }
        $encrypted = Setting::get('telegram_bot_token');
        $chat = $delivery->target === 'driver' ? $delivery->targetUser?->telegram_chat_id : Setting::get('telegram_group_id');
        if (Setting::get('telegram_enabled', '0') !== '1' || ! $encrypted || ! $chat) {
            $delivery->update(['status' => 'disabled', 'last_error' => 'Configure and enable Telegram, then retry.']);

            return true;
        }
        try {
            $token = Crypt::decryptString($encrypted);
            $s = $booking->price_snapshot;
            $context = $delivery->context ?? [];
            $eventDetails = '';
            foreach (['actor' => 'Updated by', 'status' => 'Status at update', 'reason' => 'Reason / dispatch note',
                'completed_at' => 'Drop-off completed', 'payment' => 'Cash status', 'completion_note' => 'Completion note',
                'location_url' => 'Driver-reported phone location', 'accuracy_m' => 'Phone accuracy (metres)'] as $key => $label) {
                if (isset($context[$key]) && $context[$key] !== '') {
                    $eventDetails .= $label.': '.mb_substr((string) $context[$key], 0, 1000)."\n";
                }
            }
            $text = setting('brand_name', 'Mekong Ride').' • '.str_replace('_', ' ', strtoupper($delivery->event))."\n".
                "Booking: {$booking->reference}\nStatus: {$booking->status}\n".
                $eventDetails.
                "Customer: {$booking->customer_name}\nPhone: {$booking->phone}\n".
                "Contact: ".strtoupper($booking->contact_method ?? 'WHATSAPP').($booking->contact_handle ? " ({$booking->contact_handle})" : '')." (".$booking->contactChatUrl().")\n".
                "People: {$booking->people}\n".
                'Route: '.($s['route_title']['en'] ?? '')."\nVehicle: ".($s['vehicle_title']['en'] ?? '')."\n".
                "Pickup: {$booking->pickup}\nDrop-off: {$booking->dropoff}\n".
                'Pickup map: '.$booking->mapUrl('pickup')."\n".
                'Drop-off map: '.$booking->mapUrl('dropoff')."\n".
                'Departure: '.$booking->localDeparture()->format('d M Y H:i')." (Cambodia time)\n".
                'Cash on arrival: '.money($booking->total_cents)."\n".
                'Extras: '.collect($s['extras'] ?? [])->map(fn ($e) => $e['title']['en'] ?? '')->implode(', ')."\n".
                'Notes: '.($booking->notes ?: '—')."\n".
                ($delivery->target === 'group' ? url('/admin/bookings/'.$booking->id) : url('/driver/bookings/'.$booking->id));
            $response = Http::connectTimeout(3)->timeout(10)->post('https://api.telegram.org/bot'.$token.'/sendMessage', [
                'chat_id' => $chat, 'text' => mb_substr($text, 0, 4000), 'link_preview_options' => ['is_disabled' => true],
            ]);
            if (! $response->successful() || $response->json('ok') !== true) {
                $delivery->update(['status' => 'failed', 'last_error' => 'Telegram rejected the message (HTTP '.$response->status().'). Check bot permissions and chat ID.']);

                return false;
            }
            $delivery->update(['status' => 'sent', 'sent_at' => now(), 'last_error' => null]);

            return true;
        } catch (\Throwable $e) {
            $delivery->update(['status' => 'failed', 'last_error' => 'Connection or credential error. Check network and Telegram settings.']);

            return false;
        }
    }
}
