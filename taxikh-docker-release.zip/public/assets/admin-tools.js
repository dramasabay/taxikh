(() => {
  'use strict';
  document.querySelectorAll('[data-arrange-list]').forEach(list=>{
    let dragging=null;
    const update=()=>[...list.querySelectorAll('[data-arrange-row]')].forEach((row,i)=>{const input=row.querySelector('[data-sort-order]');if(input)input.value=Number(list.dataset.orderBase||0)+i;});
    list.addEventListener('click',e=>{const button=e.target.closest('[data-move]');if(!button)return;const row=button.closest('[data-arrange-row]');if(button.dataset.move==='up'&&row.previousElementSibling)list.insertBefore(row,row.previousElementSibling);if(button.dataset.move==='down'&&row.nextElementSibling)list.insertBefore(row.nextElementSibling,row);update();button.focus();});
    list.addEventListener('dragstart',e=>{if(e.target.closest('input,textarea,a,select,button')){e.preventDefault();return;}dragging=e.target.closest('[data-arrange-row]');if(dragging){e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain','reorder');dragging.classList.add('dragging');}});
    list.addEventListener('dragover',e=>{if(!dragging)return;e.preventDefault();const row=e.target.closest('[data-arrange-row]');if(!row||row===dragging)return;const rect=row.getBoundingClientRect();list.insertBefore(dragging,e.clientY<rect.top+rect.height/2?row:row.nextSibling);});
    list.addEventListener('drop',e=>{if(!dragging)return;e.preventDefault();update();});
    list.addEventListener('dragend',()=>{dragging?.classList.remove('dragging');dragging=null;update();});
  });
})();
