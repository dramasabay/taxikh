(() => {
  'use strict';
  const text = JSON.parse(document.getElementById('ui-text')?.textContent || '{}');
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content;
  const toast = message => { const el=document.getElementById('toast'); if(!el)return; el.textContent=message;el.classList.add('visible');clearTimeout(el._timer);el._timer=setTimeout(()=>el.classList.remove('visible'),4000); };
  const ajaxHeaders = extra => ({'Accept':'application/json','X-Requested-With':'XMLHttpRequest',...extra});
  const errorMessage = data => Object.values(data.errors || {}).flat().join('\n') || data.message || text.error;
  class ResponseError extends Error {}
  const responseData = async response => {
    const messages = {401:text.signin_required,419:text.session_expired,429:text.too_many_requests};
    if(messages[response.status])return {message:messages[response.status]};
    if(response.status>=500)return {message:text.server_error};
    let data;try{data=await response.json();}catch{throw new ResponseError(text.server_error);}
    if(!data || typeof data!=='object' || response.redirected)throw new ResponseError(text.server_error);
    return data;
  };
  const showError = (form,message) => { const el=form.querySelector('[data-form-error]');if(el){el.textContent=message;el.hidden=!message;} };
  const clearFieldErrors = form => {
    form.querySelectorAll('[data-field-error]').forEach(error=>error.remove());
    form.querySelectorAll('[aria-invalid="true"]').forEach(field=>{
      field.removeAttribute('aria-invalid');
      const descriptions=(field.getAttribute('aria-describedby')||'').split(' ').filter(id=>id && !id.startsWith('validation-'));
      if(descriptions.length)field.setAttribute('aria-describedby',descriptions.join(' '));else field.removeAttribute('aria-describedby');
    });
  };
  const showResponseErrors = (form,data) => {
    showError(form,errorMessage(data));clearFieldErrors(form);let first;
    Object.entries(data.errors || {}).forEach(([name,messages])=>{
      const field=form.elements.namedItem(name);if(!(field instanceof HTMLElement) || field.type==='hidden')return;
      const error=document.createElement('span');error.className='field-error';error.dataset.fieldError='';error.id='validation-'+name.replace(/[^a-z0-9_-]/gi,'-');
      error.textContent=[messages].flat().join('\n');field.insertAdjacentElement('afterend',error);field.setAttribute('aria-invalid','true');
      field.setAttribute('aria-describedby',((field.getAttribute('aria-describedby')||'')+' '+error.id).trim());first ||= field;
    });
    form.dispatchEvent(new CustomEvent('booking:errors',{detail:data.errors||{}}));
    first?.focus();
  };
  document.querySelectorAll('[data-inquiry-form],[data-booking-form]').forEach(form=>form.addEventListener('input',()=>clearFieldErrors(form)));
  document.querySelectorAll('[data-toggle]').forEach(button=>button.addEventListener('click',()=>{ const target=document.getElementById(button.dataset.toggle);if(!target)return;const open=target.classList.toggle('is-open');button.setAttribute('aria-expanded',String(open)); }));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('[data-toggle]').forEach(button=>{document.getElementById(button.dataset.toggle)?.classList.remove('is-open');button.setAttribute('aria-expanded','false');});});
  document.addEventListener('click',e=>document.querySelectorAll('[data-toggle]').forEach(button=>{const target=document.getElementById(button.dataset.toggle);if(target?.classList.contains('is-open')&&!target.contains(e.target)&&!button.contains(e.target)){target.classList.remove('is-open');button.setAttribute('aria-expanded','false');}}));
  document.querySelectorAll('[data-language-menu]').forEach(menu=>{
    const button=menu.querySelector('[data-toggle]'),panel=menu.querySelector('.language-options'),links=[...panel.querySelectorAll('a')];
    const close=()=>{panel.classList.remove('is-open');button.setAttribute('aria-expanded','false');};
    menu.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();button.focus();return;}
      if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
      event.preventDefault();panel.classList.add('is-open');button.setAttribute('aria-expanded','true');
      const current=links.indexOf(document.activeElement);
      const next=event.key==='Home'?0:event.key==='End'?links.length-1:event.key==='ArrowDown'?(current+1)%links.length:current<=0?links.length-1:current-1;
      links[next]?.focus();
    });
    menu.addEventListener('focusout',event=>{if(!menu.contains(event.relatedTarget))close();});
  });
  document.querySelectorAll('[data-confirm]').forEach(form=>form.addEventListener('submit',e=>{if(!window.confirm(form.dataset.confirm))e.preventDefault();}));
  document.querySelectorAll('[data-print]').forEach(button=>button.addEventListener('click',()=>window.print()));
  document.querySelectorAll('[data-copy-link]').forEach(button=>button.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(location.href);toast(text.copied);}catch{window.prompt(text.copied,location.href);}}));
  document.querySelectorAll('[data-slideshow]').forEach(slideshow=>{
    const slides=[...slideshow.querySelectorAll('[data-slide]')];if(slides.length<2)return;
    let current=0,paused=matchMedia('(prefers-reduced-motion: reduce)').matches;
    const render=()=>{slides.forEach((slide,i)=>{slide.classList.toggle('is-active',i===current);slide.setAttribute('aria-hidden',String(i!==current));slide.inert=i!==current;});slideshow.querySelector('[data-slide-counter]').textContent=`${current+1} / ${slides.length}`;};
    const go=step=>{current=(current+step+slides.length)%slides.length;render();};
    slideshow.querySelector('[data-prev]')?.addEventListener('click',()=>go(-1));slideshow.querySelector('[data-next]')?.addEventListener('click',()=>go(1));
    const pauseButton=slideshow.querySelector('[data-pause]');const pauseLabel=()=>{pauseButton.textContent=paused?'▶':'Ⅱ';pauseButton.setAttribute('aria-label',paused?'Play slideshow':'Pause slideshow');};
    pauseButton?.addEventListener('click',()=>{paused=!paused;pauseLabel();});pauseLabel();render();
    setInterval(()=>{if(!paused&&!document.hidden&&!slideshow.matches(':hover')&&!slideshow.contains(document.activeElement))go(1);},7500);
  });
  const bookingForm=document.querySelector('[data-booking-form]');
  if(bookingForm){
    let quoteController,quoteSequence=0,quoteValid=false,submitting=false;
    const submit=bookingForm.querySelector('[data-submit]'),total=bookingForm.querySelector('[data-total]'),originalButton=submit.innerHTML;
    const updateQuote=async()=>{
      const sequence=++quoteSequence;quoteController?.abort();quoteController=new AbortController();quoteValid=false;submit.disabled=true;total.textContent=text.price_loading;showError(bookingForm,'');
      const fields=new FormData(bookingForm);
      const payload={route_id:Number(fields.get('route_id')),vehicle_id:Number(fields.get('vehicle_id')),people:Number(fields.get('people')),extras:fields.getAll('extras[]').map(Number),locale:fields.get('locale')};
      try{
        const response=await fetch(bookingForm.dataset.quoteUrl,{method:'POST',headers:ajaxHeaders({'Content-Type':'application/json'}),body:JSON.stringify(payload),signal:quoteController.signal,credentials:'same-origin'});
        const data=await responseData(response);if(sequence!==quoteSequence)return;
        if(!response.ok){total.textContent='—';showError(bookingForm,errorMessage(data));return;}
        total.textContent=data.formatted_total||((data.total_cents/100).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})+' '+data.currency);bookingForm.querySelectorAll('[data-base-total]').forEach(el=>el.textContent=data.formatted_base||((data.base_cents/100).toFixed(2)+' '+data.currency));bookingForm.querySelectorAll('[data-extras-total]').forEach(el=>el.textContent=data.formatted_extras||(((data.total_cents-data.base_cents)/100).toFixed(2)+' '+data.currency));quoteValid=true;
      }catch(error){if(error.name==='AbortError')return;total.textContent='—';showError(bookingForm,error instanceof ResponseError?error.message:text.network);}
      finally{if(sequence===quoteSequence)submit.disabled=!quoteValid||submitting;}
    };
    bookingForm.querySelectorAll('[data-quote-field]').forEach(field=>field.addEventListener('change',updateQuote));
    bookingForm.addEventListener('submit',async event=>{
      event.preventDefault();if(submitting)return;if(!quoteValid){await updateQuote();if(!quoteValid)return;}if(!bookingForm.reportValidity())return;
      submitting=true;submit.disabled=true;submit.textContent=text.processing;showError(bookingForm,'');clearFieldErrors(bookingForm);
      // Keep the request key and form values after a network error: a retry must not create a second booking.
      const payload=new FormData(bookingForm);
      bookingForm.setAttribute('aria-busy','true');
      try{
        const response=await fetch(bookingForm.action,{method:'POST',headers:ajaxHeaders({'X-CSRF-TOKEN':csrf}),body:payload,credentials:'same-origin'});
        const data=await responseData(response);
        if(!response.ok){showResponseErrors(bookingForm,data);return;}
        if(typeof data.confirmation_url!=='string')throw new ResponseError(text.server_error);
        const url=new URL(data.confirmation_url,location.origin);if(url.origin!==location.origin)throw new Error('Unexpected redirect');
        location.assign(url.href);
      }catch(error){showError(bookingForm,error instanceof ResponseError?error.message:text.network);}
      finally{submitting=false;submit.disabled=!quoteValid;submit.innerHTML=originalButton;bookingForm.removeAttribute('aria-busy');}
    });
    updateQuote();
  }
  document.querySelectorAll('[data-inquiry-form]').forEach(form=>form.addEventListener('submit',async event=>{
    event.preventDefault();const button=form.querySelector('button[type="submit"],button:not([type])');if(button.disabled||!form.reportValidity())return;
    button.disabled=true;showError(form,'');clearFieldErrors(form);form.setAttribute('aria-busy','true');const success=form.querySelector('[data-form-success]');success.hidden=true;
    try{
      const response=await fetch(form.action,{method:'POST',headers:ajaxHeaders({'X-CSRF-TOKEN':csrf}),body:new FormData(form),credentials:'same-origin'});
      const data=await responseData(response);if(!response.ok){showResponseErrors(form,data);return;}
      if(typeof data.message!=='string' || 'items' in data)throw new ResponseError(text.server_error);
      success.textContent=data.message;success.hidden=false;form.reset();
    }catch(error){showError(form,error instanceof ResponseError?error.message:text.network);}
    finally{button.disabled=false;form.removeAttribute('aria-busy');}
  }));
  const alertsUrl=document.body.dataset.alertsUrl;
  if(alertsUrl){
    let lastUnread=null;
    const loadAlerts=async()=>{if(document.hidden)return;try{
      const response=await fetch(alertsUrl,{headers:ajaxHeaders(),credentials:'same-origin',cache:'no-store'});if(!response.ok)return;const data=await responseData(response);
      if(!Number.isInteger(data.unread)||!Array.isArray(data.items))return;
      const badge=document.querySelector('[data-unread]');badge.textContent=data.unread>99?'99+':data.unread;badge.hidden=!data.unread;
      const list=document.querySelector('[data-alert-list]');list.replaceChildren();
      if(!data.items.length){const p=document.createElement('p');p.textContent=text.empty;list.append(p);}
      data.items.forEach(item=>{const a=document.createElement('a');a.href=item.url;a.textContent=item.label;if(!item.read)a.className='unread';list.append(a);});
      if(lastUnread!==null&&data.unread>lastUnread&&data.items[0])toast(data.items[0].label);lastUnread=data.unread;
    }catch{/* Next poll retries without disturbing staff work. */}};
    document.querySelector('[data-read-alerts]')?.addEventListener('click',async()=>{try{const response=await fetch(document.body.dataset.readAlertsUrl,{method:'POST',headers:ajaxHeaders({'X-CSRF-TOKEN':csrf}),credentials:'same-origin'});if(response.ok)await loadAlerts();else toast(errorMessage(await responseData(response)));}catch(error){toast(error instanceof ResponseError?error.message:text.network);}});
    loadAlerts();setInterval(loadAlerts,15000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)loadAlerts();});
  }
})();
