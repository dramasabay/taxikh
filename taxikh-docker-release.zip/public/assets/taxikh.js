(() => {
  'use strict';
  const config = JSON.parse(document.getElementById('taxikh-text')?.textContent || '{}');
  const normalize = value => (value || '').normalize('NFKD').toLocaleLowerCase().replace(/[\s\p{P}\p{M}]/gu, '');
  const fuzzy = (source, term) => {
    let i = 0;
    for (const c of source) {
      if (c === term[i]) i++;
    }
    return i === term.length;
  };

  // 1. City Search Component
  document.querySelectorAll('[data-city-search]').forEach(form => {
    const pairs = JSON.parse(form.querySelector('[data-city-pairs]').textContent);
    const fields = {};
    form.querySelectorAll('[data-city-field]').forEach(box => {
      const select = box.querySelector('select'), options = [...select.options].filter(o => o.value), id = select.id, required = select.required;
      const input = document.createElement('input');
      input.type = 'search';
      input.id = id;
      input.autocomplete = 'off';
      input.placeholder = config.choose_city || 'Choose a city';
      input.maxLength = 150;
      input.required = required;
      input.value = select.selectedOptions[0]?.value ? select.selectedOptions[0].textContent : '';
      input.setAttribute('role', 'combobox');
      input.setAttribute('aria-autocomplete', 'list');
      input.setAttribute('aria-expanded', 'false');
      input.setAttribute('aria-controls', id + '-suggestions');
      select.id = id + '-value';
      select.hidden = true;
      select.required = false;
      box.append(input);

      const list = document.createElement('div');
      list.id = id + '-suggestions';
      list.className = 'city-options';
      list.setAttribute('role', 'listbox');
      list.hidden = true;
      box.append(list);

      let matches = [], active = -1;
      const close = () => {
        list.hidden = true;
        input.setAttribute('aria-expanded', 'false');
        input.removeAttribute('aria-activedescendant');
      };
      const sync = () => {
        input.value = select.value ? select.selectedOptions[0].textContent : '';
        input.setCustomValidity('');
      };
      const choose = option => {
        select.value = option.value;
        sync();
        close();
        select.dispatchEvent(new Event('change', { bubbles: true }));
        input.focus();
      };
      const highlight = () => {
        [...list.children].forEach((el, i) => el.setAttribute('aria-selected', String(i === active)));
        if (active >= 0) {
          input.setAttribute('aria-activedescendant', list.children[active].id);
          list.children[active].scrollIntoView?.({ block: 'nearest' });
        }
      };
      const show = () => {
        const query = normalize(input.value);
        matches = options.filter(o => !o.disabled && [o.textContent, ...JSON.parse(o.dataset.aliases || '[]')].some(v => {
          const s = normalize(v || '');
          return s.includes(query) || (query.length >= 3 && fuzzy(s, query));
        })).slice(0, 12);
        list.replaceChildren();
        active = -1;
        matches.forEach((option, i) => {
          const el = document.createElement('div');
          el.id = id + '-option-' + i;
          el.setAttribute('role', 'option');
          el.className = 'city-option';
          el.textContent = option.textContent;
          el.addEventListener('pointerdown', e => e.preventDefault());
          el.addEventListener('click', () => choose(option));
          list.append(el);
        });
        if (!matches.length) {
          const empty = document.createElement('p');
          empty.textContent = config.choose_route_city;
          list.append(empty);
        }
        list.hidden = false;
        input.setAttribute('aria-expanded', 'true');
      };

      input.addEventListener('input', () => {
        select.value = '';
        input.setCustomValidity('');
        const exact = options.find(o => !o.disabled && [o.textContent, ...JSON.parse(o.dataset.aliases || '[]')].some(s => normalize(s || '') === normalize(input.value)));
        if (exact) select.value = exact.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
        show();
      });
      input.addEventListener('focus', show);
      input.addEventListener('keydown', e => {
        if (e.key === 'Escape') { close(); return; }
        if (['ArrowDown', 'ArrowUp'].includes(e.key)) {
          e.preventDefault();
          if (list.hidden) show();
          if (!matches.length) return;
          active = e.key === 'ArrowDown' ? (active + 1) % matches.length : active <= 0 ? matches.length - 1 : active - 1;
          highlight();
        }
        if (e.key === 'Enter' && !list.hidden && matches.length) {
          e.preventDefault();
          choose(matches[active < 0 ? 0 : active]);
        }
        if (e.key === 'Tab') close();
      });
      box.addEventListener('focusout', e => { if (!box.contains(e.relatedTarget)) close(); });
      document.addEventListener('click', e => { if (!box.contains(e.target)) close(); });
      fields[select.name] = { select, input, options, sync };
    });

    const updateDestinations = () => {
      const from = fields.from?.select.value, type = form.elements.namedItem('type')?.value;
      if (!fields.to) return;
      const allowed = new Set(pairs.filter(p => (!from || p.from === from) && (!type || p.type === type)).map(p => p.to));
      fields.to.options.forEach(o => o.disabled = !allowed.has(o.value));
      if (fields.to.select.value && fields.to.select.selectedOptions[0].disabled) {
        fields.to.select.value = '';
        fields.to.sync();
      }
    };
    fields.from?.select.addEventListener('change', updateDestinations);
    updateDestinations();

    form.querySelector('[data-city-swap]')?.addEventListener('click', () => {
      if (!fields.from || !fields.to) return;
      const from = fields.from.select.value, to = fields.to.select.value;
      fields.from.select.value = to;
      fields.from.sync();
      updateDestinations();
      fields.to.select.value = from;
      if (fields.to.select.selectedOptions[0]?.disabled) fields.to.select.value = '';
      fields.to.sync();
    });

    form.addEventListener('submit', e => {
      for (const { select, input } of Object.values(fields)) {
        if (!select.value) {
          e.preventDefault();
          input.setCustomValidity(config.choose_route_city || 'Select a listed city.');
          input.reportValidity();
          return;
        }
      }
    });
  });

  // 2. Catalogue Real-Time Filtering & Autocomplete
  const root = document.querySelector('[data-catalogue-root]');
  if (root) {
    const form = root.querySelector('[data-catalogue-form]');
    const countEl = root.querySelector('[data-catalogue-count]');
    const searchInput = form?.querySelector('[data-catalogue-search]');
    const layoutSelect = form?.querySelector('select[name="layout"]');
    const baseUrl = root.dataset.baseUrl || window.location.pathname;
    let activeController = null;
    let debounceTimer = null;

    // Auto view list when user open on mobile (<= 768px)
    if (window.innerWidth <= 768) {
      const urlParams = new URLSearchParams(window.location.search);
      if (!urlParams.has('layout') && layoutSelect) {
        layoutSelect.value = 'list';
      }
      const gridEl = root.querySelector('.catalogue-grid');
      if (gridEl && !urlParams.has('layout')) {
        gridEl.classList.remove('layout-grid');
        gridEl.classList.add('layout-list');
      }
    }

    layoutSelect?.addEventListener('change', () => {
      const gridEl = root.querySelector('.catalogue-grid');
      if (gridEl) {
        if (layoutSelect.value === 'grid') {
          gridEl.classList.add('user-selected-grid');
          gridEl.classList.remove('layout-list');
          gridEl.classList.add('layout-grid');
        } else {
          gridEl.classList.remove('user-selected-grid');
          gridEl.classList.remove('layout-grid');
          gridEl.classList.add('layout-list');
        }
      }
    });

    const fetchCatalogue = async (urlOrParams) => {
      if (activeController) activeController.abort();
      activeController = new AbortController();

      let targetUrl;
      let params;
      if (urlOrParams instanceof URLSearchParams || urlOrParams instanceof FormData) {
        params = new URLSearchParams(urlOrParams);
        targetUrl = new URL(baseUrl, window.location.origin);
        for (const [k, v] of params.entries()) {
          if (v !== null && v !== '') targetUrl.searchParams.set(k, v);
        }
      } else if (typeof urlOrParams === 'string') {
        targetUrl = new URL(urlOrParams, window.location.origin);
        params = targetUrl.searchParams;
      } else {
        params = new URLSearchParams(new FormData(form));
        targetUrl = new URL(baseUrl, window.location.origin);
        for (const [k, v] of params.entries()) {
          if (v !== null && v !== '') targetUrl.searchParams.set(k, v);
        }
      }

      if (window.innerWidth <= 768 && !params.has('layout') && layoutSelect) {
        params.set('layout', layoutSelect.value || 'list');
      }

      const resultsShell = root.querySelector('[data-catalogue-results-shell]');
      if (resultsShell) resultsShell.classList.add('loading');

      try {
        const res = await fetch(targetUrl.toString(), {
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          signal: activeController.signal
        });
        if (!res.ok) throw new Error('Fetch failed');
        const data = await res.json();

        const parser = new DOMParser();
        const doc = parser.parseFromString(data.html, 'text/html');
        const newResults = doc.querySelector('[data-catalogue-results-shell]');
        const currentResults = root.querySelector('[data-catalogue-results-shell]');
        if (newResults && currentResults) {
          currentResults.replaceWith(newResults);
          if (window.innerWidth <= 768 && layoutSelect?.value === 'grid') {
            root.querySelector('.catalogue-grid')?.classList.add('user-selected-grid');
          }
        }
        if (countEl && data.count_text) {
          countEl.textContent = data.count_text;
        }

        const currentType = params.get('type') || '';
        root.querySelectorAll('[data-catalogue-tab]').forEach(tab => {
          const tabType = tab.dataset.type || '';
          if (tabType === currentType) {
            tab.setAttribute('aria-current', 'true');
          } else {
            tab.removeAttribute('aria-current');
          }
        });

        const newUrl = new URL(baseUrl, window.location.origin);
        for (const [k, v] of params.entries()) {
          if (v) newUrl.searchParams.set(k, v);
        }
        newUrl.hash = 'routes-catalogue';
        window.history.replaceState({}, '', newUrl.toString());
      } catch (err) {
        if (err.name !== 'AbortError') console.error('Catalogue filter error:', err);
      } finally {
        const shell = root.querySelector('[data-catalogue-results-shell]');
        if (shell) shell.classList.remove('loading');
      }
    };

    // Catalogue Search Combobox Dropdown
    const searchContainer = form?.querySelector('[data-catalogue-search-container]');
    const searchDropdown = searchContainer?.querySelector('#catalogue-search-suggestions');
    const searchArrow = searchContainer?.querySelector('[data-catalogue-search-arrow]');

    if (searchInput && searchDropdown) {
      let activeIdx = -1;

      const getOptions = () => [...searchDropdown.querySelectorAll('.city-option')];

      const filterDropdownOptions = () => {
        const query = normalize(searchInput.value);
        getOptions().forEach(opt => {
          const val = normalize(opt.dataset.value || opt.textContent);
          const isMatch = !query || val.includes(query) || (query.length >= 3 && fuzzy(val, query));
          opt.hidden = !isMatch;
        });
        activeIdx = -1;
      };

      const openDropdown = () => {
        filterDropdownOptions();
        searchDropdown.hidden = false;
        searchContainer.classList.add('is-open');
        searchInput.setAttribute('aria-expanded', 'true');
      };

      const closeDropdown = () => {
        searchDropdown.hidden = true;
        searchContainer.classList.remove('is-open');
        searchInput.setAttribute('aria-expanded', 'false');
        searchInput.removeAttribute('aria-activedescendant');
        activeIdx = -1;
        getOptions().forEach(el => el.removeAttribute('aria-selected'));
      };

      const selectOption = (opt) => {
        const val = (opt.dataset.value || opt.textContent).trim();
        searchInput.value = val;
        closeDropdown();
        clearTimeout(debounceTimer);
        fetchCatalogue();
        searchInput.focus();
      };

      const highlightOption = (visibleOpts) => {
        visibleOpts.forEach((el, idx) => {
          if (idx === activeIdx) {
            el.setAttribute('aria-selected', 'true');
            el.scrollIntoView({ block: 'nearest' });
          } else {
            el.removeAttribute('aria-selected');
          }
        });
      };

      searchDropdown.addEventListener('click', (e) => {
        const opt = e.target.closest('.city-option');
        if (opt) {
          e.preventDefault();
          selectOption(opt);
        }
      });

      searchInput.addEventListener('focus', openDropdown);
      searchInput.addEventListener('click', openDropdown);

      searchArrow?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (searchDropdown.hidden) {
          searchInput.focus();
          openDropdown();
        } else {
          closeDropdown();
        }
      });

      searchInput.addEventListener('input', () => {
        openDropdown();
        filterDropdownOptions();
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          fetchCatalogue();
        }, 250);
      });

      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          closeDropdown();
          return;
        }
        const visibleOpts = getOptions().filter(el => !el.hidden);
        if (['ArrowDown', 'ArrowUp'].includes(e.key)) {
          e.preventDefault();
          if (searchDropdown.hidden) {
            openDropdown();
            return;
          }
          if (!visibleOpts.length) return;
          if (e.key === 'ArrowDown') {
            activeIdx = (activeIdx + 1) % visibleOpts.length;
          } else {
            activeIdx = activeIdx <= 0 ? visibleOpts.length - 1 : activeIdx - 1;
          }
          highlightOption(visibleOpts);
        } else if (e.key === 'Enter') {
          if (!searchDropdown.hidden && activeIdx >= 0 && visibleOpts[activeIdx]) {
            e.preventDefault();
            selectOption(visibleOpts[activeIdx]);
          }
        } else if (e.key === 'Tab') {
          closeDropdown();
        }
      });

      document.addEventListener('click', (e) => {
        if (!searchContainer.contains(e.target)) {
          closeDropdown();
        }
      });
    }

    form?.querySelectorAll('[data-catalogue-auto-submit]').forEach(select => {
      select.addEventListener('change', () => {
        fetchCatalogue();
      });
    });

    root.querySelectorAll('[data-catalogue-tab]').forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
        const type = tab.dataset.type || '';
        let typeInput = form.querySelector('input[name="type"]');
        if (!typeInput) {
          typeInput = document.createElement('input');
          typeInput.type = 'hidden';
          typeInput.name = 'type';
          form.append(typeInput);
        }
        typeInput.value = type;
        fetchCatalogue();
      });
    });

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      fetchCatalogue();
    });

    root.querySelector('[data-clear-filters]')?.addEventListener('click', (e) => {
      e.preventDefault();
      if (form) {
        if (searchInput) searchInput.value = '';
        const typeInput = form.querySelector('input[name="type"]');
        if (typeInput) typeInput.value = '';
        const fromInput = form.querySelector('input[name="from"]');
        if (fromInput) fromInput.value = '';
        const toInput = form.querySelector('input[name="to"]');
        if (toInput) toInput.value = '';
        const sortSelect = form.querySelector('select[name="sort"]');
        if (sortSelect) sortSelect.selectedIndex = 0;
        const layoutSelect = form.querySelector('select[name="layout"]');
        if (layoutSelect) {
          if (window.innerWidth <= 768) {
            layoutSelect.value = 'list';
          } else {
            layoutSelect.selectedIndex = 0;
          }
        }
      }
      fetchCatalogue();
    });

    root.addEventListener('click', (e) => {
      const pageLink = e.target.closest('[data-catalogue-results-shell] .pagination a, [data-catalogue-results-shell] nav[role="navigation"] a');
      if (pageLink && pageLink.href) {
        e.preventDefault();
        fetchCatalogue(pageLink.href);
        root.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  }

  // 3. Booking Wizard
  const wizardForm = document.querySelector('[data-booking-wizard]');
  if (!wizardForm) return;

  const messages = JSON.parse(wizardForm.querySelector('[data-wizard-text]').textContent);
  const panels = [...wizardForm.querySelectorAll('[data-booking-step]')];
  const next = wizardForm.querySelector('[data-booking-next]');
  const back = wizardForm.querySelector('[data-booking-back]');
  const submit = wizardForm.querySelector('[data-submit]');
  let step = 1;

  // Preferred contact dynamic handle update
  const updateContactUI = () => {
    const selectedMethod = wizardForm.querySelector('[name="contact_method"]:checked')?.value || 'whatsapp';
    const handleWrap = document.getElementById('contact-handle-wrap');
    const handleLabel = document.getElementById('contact-handle-text');
    const handleInput = document.getElementById('contact_handle');
    if (!handleWrap) return;
    if (selectedMethod === 'phone') {
      handleWrap.style.display = 'none';
    } else {
      handleWrap.style.display = 'block';
      if (handleLabel) {
        handleLabel.textContent = selectedMethod === 'whatsapp' ? (messages.whatsapp_number || 'WhatsApp Number') : (messages.telegram_username || 'Telegram Username / Number');
      }
      if (handleInput) {
        handleInput.placeholder = selectedMethod === 'whatsapp' ? '+855 …' : '@username / +855 …';
      }
    }
  };
  wizardForm.querySelectorAll('[name="contact_method"]').forEach(r => r.addEventListener('change', updateContactUI));
  updateContactUI();

  const preview = () => {
    const target = wizardForm.querySelector('[data-booking-preview]');
    target.replaceChildren();
    const data = new FormData(wizardForm);
    const values = { vehicle_id: wizardForm.querySelector('[name="vehicle_id"]:checked')?.dataset.vehicleLabel };
    ['customer_name', 'phone'].forEach(key => values[key] = data.get(key));

    const method = data.get('contact_method') || 'phone';
    const handle = data.get('contact_handle');
    const methodNames = { whatsapp: 'WhatsApp', telegram: 'Telegram', phone: messages.phone || 'Phone' };
    values.contact_method = methodNames[method] || method;
    if (handle && method !== 'phone') {
      values.contact_handle = handle;
    }

    ['people', 'pickup', 'dropoff', 'departure_date', 'departure_time', 'notes'].forEach(key => values[key] = data.get(key));
    values.extras = [...wizardForm.querySelectorAll('[name="extras[]"]:checked')].map(e => e.dataset.extraLabel).join(', ') || '—';

    const dl = document.createElement('dl');
    dl.className = 'receipt-grid';
    Object.entries(values).forEach(([key, value]) => {
      if (!value) return;
      const wrap = document.createElement('div'), dt = document.createElement('dt'), dd = document.createElement('dd');
      dt.textContent = messages[key] || key;
      dd.textContent = value;
      wrap.append(dt, dd);
      dl.append(wrap);
    });
    target.append(dl);
  };

  const show = (number, scroll = false) => {
    step = number;
    panels.forEach(p => p.hidden = Number(p.dataset.bookingStep) !== step);
    wizardForm.querySelectorAll('[data-step-target]').forEach(el => {
      const n = Number(el.dataset.stepTarget);
      el.classList.toggle('done', n < step);
      if (n === step) el.setAttribute('aria-current', 'step');
      else el.removeAttribute('aria-current');
    });
    back.hidden = step === 1;
    next.hidden = step === 4;
    submit.hidden = step !== 4;
    preview();
    if (scroll) panels[step - 1].scrollIntoView?.({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
  };

  const validPanel = number => {
    const fields = [...panels[number - 1].querySelectorAll('input,select,textarea')];
    for (const field of fields) {
      if (!field.checkValidity()) {
        show(number);
        field.reportValidity();
        return false;
      }
    }
    return true;
  };

  next.addEventListener('click', () => { if (validPanel(step)) show(Math.min(4, step + 1), true); });
  back.addEventListener('click', () => show(Math.max(1, step - 1), true));
  wizardForm.querySelectorAll('[data-step-target]').forEach(link => link.addEventListener('click', e => {
    e.preventDefault();
    const target = Number(link.dataset.stepTarget);
    for (let n = 1; n < target; n++) {
      if (!validPanel(n)) return;
    }
    show(target, true);
  }));

  wizardForm.addEventListener('invalid', e => {
    const panel = e.target.closest('[data-booking-step]');
    if (panel?.hidden) show(Number(panel.dataset.bookingStep));
  }, true);

  wizardForm.addEventListener('booking:errors', e => {
    const names = Object.keys(e.detail || {});
    const field = names.map(n => wizardForm.elements.namedItem(n)).find(el => el instanceof HTMLElement && el.closest('[data-booking-step]'));
    if (field) {
      show(Number(field.closest('[data-booking-step]').dataset.bookingStep));
      field.focus();
    }
  });

  const selected = () => wizardForm.querySelectorAll('.vehicle-choice').forEach(card => {
    const checked = card.querySelector('input').checked;
    card.classList.toggle('selected', checked);
    card.querySelector('[data-car-select-label]').textContent = checked ? messages.selected : messages.select_vehicle;
  });
  wizardForm.querySelectorAll('[name="vehicle_id"]').forEach(radio => radio.addEventListener('change', selected));
  selected();

  wizardForm.querySelectorAll('[data-car-filter]').forEach(button => button.addEventListener('click', () => {
    wizardForm.querySelectorAll('[data-car-filter]').forEach(el => el.setAttribute('aria-pressed', String(el === button)));
    wizardForm.querySelectorAll('[data-car-category]').forEach(card => card.hidden = button.dataset.carFilter !== 'all' && card.dataset.carCategory !== button.dataset.carFilter);
  }));

  wizardForm.addEventListener('change', preview);
  wizardForm.classList.add('wizard-ready');
  show(1);
})();
