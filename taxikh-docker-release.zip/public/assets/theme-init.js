(() => {
  'use strict';
  const root = document.documentElement;
  const preference = window.matchMedia('(prefers-color-scheme: dark)');
  let saved = null;
  try { saved = localStorage.getItem('ride-theme'); } catch { /* Private browsing still supports the toggle. */ }
  if (!['light', 'dark'].includes(saved)) saved = null;
  const defaultTheme = root.dataset.defaultTheme || 'system';
  const apply = () => {
    const theme = saved || (defaultTheme === 'system' ? (preference.matches ? 'dark' : 'light') : defaultTheme);
    root.dataset.theme = theme;
    document.querySelectorAll('[data-theme-toggle]').forEach(button => button.setAttribute('aria-pressed', String(theme === 'dark')));
  };
  apply();
  preference.addEventListener('change', apply);
  document.addEventListener('DOMContentLoaded', () => {
    apply();
    document.querySelectorAll('[data-theme-toggle]').forEach(button => button.addEventListener('click', () => {
      saved = root.dataset.theme === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem('ride-theme', saved); } catch { /* Keep the choice for this page. */ }
      apply();
    }));
  });
})();
