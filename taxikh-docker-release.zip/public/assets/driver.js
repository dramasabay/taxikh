(() => {
  'use strict';
  document.querySelectorAll('[data-completion-location]').forEach(panel => {
    const capture=panel.querySelector('[data-capture-completion]'),remove=panel.querySelector('[data-clear-completion]'),status=panel.querySelector('[data-completion-location-status]');
    let sequence=0,expiry;
    const clear=()=>{sequence++;clearTimeout(expiry);panel.querySelectorAll('input').forEach(input=>input.value='');remove.hidden=true;capture.disabled=false;status.textContent='';};
    remove.addEventListener('click',clear);
    capture.addEventListener('click',()=>{
      clear();const request=sequence;
      if(!navigator.geolocation || !window.isSecureContext){status.textContent=panel.dataset.unsupported;return;}
      capture.disabled=true;remove.hidden=false;status.textContent=panel.dataset.loading;
      navigator.geolocation.getCurrentPosition(position=>{
        if(request!==sequence)return;
        const {latitude,longitude,accuracy}=position.coords;
        if(!Number.isFinite(latitude)||!Number.isFinite(longitude)||!Number.isFinite(accuracy)||Math.abs(latitude)>90||Math.abs(longitude)>180||accuracy<0||accuracy>100000||!Number.isFinite(position.timestamp)||Math.abs(Date.now()-position.timestamp)>60000){clear();status.textContent=panel.dataset.error;return;}
        const values={completion_lat:latitude.toFixed(7),completion_lng:longitude.toFixed(7),completion_accuracy_m:accuracy.toFixed(2),completion_captured_at:String(Math.floor(position.timestamp/1000))};
        Object.entries(values).forEach(([name,value])=>panel.querySelector(`[name="${name}"]`).value=value);
        capture.disabled=false;status.textContent=panel.dataset.success.replace(':meters',String(Math.round(accuracy)));
        expiry=setTimeout(()=>{clear();status.textContent=panel.dataset.error;},240000);
      },error=>{
        if(request!==sequence)return;clear();status.textContent=error.code===1?panel.dataset.denied:panel.dataset.error;
      },{enableHighAccuracy:true,maximumAge:0,timeout:15000});
    });
  });
  document.querySelectorAll('[data-driver-action-form]').forEach(form=>{
    form.addEventListener('submit',event=>{
      if(form.dataset.submitting){event.preventDefault();return;}
      if(!form.reportValidity()){event.preventDefault();return;}
      form.dataset.submitting='1';form.setAttribute('aria-busy','true');form.querySelectorAll('button').forEach(button=>button.disabled=true);
    });
  });
  window.addEventListener('pageshow',()=>{
    document.querySelectorAll('[data-driver-action-form]').forEach(form=>{
      delete form.dataset.submitting;form.removeAttribute('aria-busy');form.querySelectorAll('button').forEach(button=>button.disabled=false);
    });
  });
})();
