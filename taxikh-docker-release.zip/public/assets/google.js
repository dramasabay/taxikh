(() => {
  'use strict';
  const configElement = document.getElementById('google-config');
  if (!configElement) return;
  const config = JSON.parse(configElement.textContent);
  const messages = config.messages || {};
  let mapsPromise;
  const loadMaps = () => {
    if (!config.key) return Promise.reject(new Error('Maps is not configured'));
    if (window.google?.maps?.importLibrary) return Promise.resolve(window.google.maps);
    if (mapsPromise) return mapsPromise;
    mapsPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      const timer = setTimeout(() => reject(new Error('Maps timeout')), 12000);
      const fail = () => { clearTimeout(timer); reject(new Error('Maps unavailable')); };
      window.rideGoogleReady = () => { clearTimeout(timer); resolve(window.google.maps); };
      window.gm_authFailure = fail;
      script.src = 'https://maps.googleapis.com/maps/api/js?' + new URLSearchParams({
        key: config.key, v: 'weekly', loading: 'async', callback: 'rideGoogleReady',
        language: config.language || 'en', region: 'KH', auth_referrer_policy: 'origin'
      });
      script.async = true;
      script.onerror = fail;
      document.head.append(script);
    });
    return mapsPromise;
  };
  const httpsUrl = value => {
    try { const url = new URL(value); return url.protocol === 'https:' ? url.href : ''; } catch { return ''; }
  };
  const node = (tag, className, content) => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (content !== undefined) element.textContent = content;
    return element;
  };

  document.querySelectorAll('[data-location-field]').forEach(field => {
    const input = field.querySelector('[data-location-input]');
    const list = field.querySelector('[data-location-list]');
    const options = field.querySelector('[data-location-options]');
    const status = field.querySelector('[data-location-status]');
    const mapLink = field.querySelector('[data-location-link]');
    const latitude = field.querySelector('[data-location-lat]');
    const longitude = field.querySelector('[data-location-lng]');
    const placeId = field.querySelector('[data-location-place-id]');
    const locate = field.querySelector('[data-locate]');
    let sequence = 0, timer, predictions = [], active = -1, sessionToken, sessionStarted = 0;
    const say = key => { status.textContent = messages[key] || ''; };
    const close = () => { options.hidden = true; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); active = -1; };
    const updateMapLink = () => {
      const hasPoint = latitude.value !== '' && longitude.value !== '';
      mapLink.hidden = !hasPoint && !placeId.value;
      if (mapLink.hidden) { mapLink.removeAttribute('href'); return; }
      const params = new URLSearchParams({api: '1', query: hasPoint ? latitude.value + ',' + longitude.value : input.value});
      if (placeId.value) params.set('query_place_id', placeId.value);
      mapLink.href = 'https://www.google.com/maps/search/?' + params;
    };
    const setPoint = (address, location, id = '') => {
      input.value = address.slice(0, 300);
      latitude.value = Number(location.lat).toFixed(7);
      longitude.value = Number(location.lng).toFixed(7);
      placeId.value = id;
      updateMapLink();
      input.dispatchEvent(new Event('change', {bubbles: true}));
    };
    const select = async index => {
      const prediction = predictions[index];
      if (!prediction) return;
      const current = ++sequence;
      clearTimeout(timer); close(); say('location_searching');
      try {
        const place = prediction.toPlace();
        await place.fetchFields({fields: ['id', 'displayName', 'formattedAddress', 'location']});
        if (current !== sequence) return;
        if (!place.location) throw new Error('No coordinates');
        const address = place.formattedAddress || '';
        const name = place.displayName || '';
        const label = name && !address.toLowerCase().includes(name.toLowerCase()) ? name + ', ' + address : (address || name);
        setPoint(label, {lat: place.location.lat(), lng: place.location.lng()}, place.id || '');
        say('location_selected');
      } catch { if (current === sequence) say('location_unavailable'); }
      finally { sessionToken = null; }
    };
    const search = async current => {
      const value = input.value.trim();
      if (value.length < 3 || current !== sequence) return;
      say('location_searching');
      try {
        const maps = await loadMaps();
        const {AutocompleteSessionToken, AutocompleteSuggestion} = await maps.importLibrary('places');
        if (current !== sequence) return;
        if (!sessionToken || Date.now() - sessionStarted > 180000) {
          sessionToken = new AutocompleteSessionToken(); sessionStarted = Date.now();
        }
        const response = await AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: value, sessionToken, language: config.language, region: 'kh',
          locationBias: {north: 14.7, south: 10.3, east: 107.7, west: 102.3}
        });
        if (current !== sequence || input.value.trim() !== value || document.activeElement !== input) return;
        predictions = response.suggestions.map(item => item.placePrediction).filter(Boolean);
        list.replaceChildren();
        predictions.forEach((prediction, index) => {
          const option = node('div', 'location-option');
          option.id = list.id + '-' + index; option.setAttribute('role', 'option'); option.setAttribute('aria-selected', 'false');
          option.append(node('strong', '', prediction.mainText?.toString() || prediction.text.toString()));
          if (prediction.secondaryText) option.append(node('small', '', prediction.secondaryText.toString()));
          option.addEventListener('pointerdown', event => event.preventDefault());
          option.addEventListener('click', () => select(index));
          list.append(option);
        });
        active = -1; options.hidden = !predictions.length;
        input.setAttribute('aria-expanded', String(predictions.length > 0));
        say(predictions.length ? '' : 'location_empty');
      } catch { if (current === sequence) { close(); say('location_unavailable'); } }
    };
    if (config.maps && config.key) {
      input.setAttribute('role', 'combobox'); input.setAttribute('aria-autocomplete', 'list');
      input.setAttribute('aria-controls', list.id); input.setAttribute('aria-expanded', 'false');
    }
    input.addEventListener('input', () => {
      ++sequence; clearTimeout(timer); close();
      latitude.value = ''; longitude.value = ''; placeId.value = ''; updateMapLink(); say('');
      if (config.maps && config.key && input.value.trim().length >= 3) {
        const current = sequence; timer = setTimeout(() => search(current), 300);
      }
    });
    input.addEventListener('keydown', event => {
      if (event.key === 'Escape') { ++sequence; clearTimeout(timer); close(); say(''); return; }
      if (options.hidden || !predictions.length) return;
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        active = (active + (event.key === 'ArrowDown' ? 1 : -1) + predictions.length) % predictions.length;
        [...list.children].forEach((option, index) => option.setAttribute('aria-selected', String(index === active)));
        input.setAttribute('aria-activedescendant', list.children[active].id);
        list.children[active].scrollIntoView({block: 'nearest'});
      } else if (event.key === 'Enter') {
        event.preventDefault(); select(active < 0 ? 0 : active);
      } else if (event.key === 'Tab') close();
    });
    input.addEventListener('blur', () => { clearTimeout(timer); close(); });
    field.addEventListener('ride:location-updated', () => { ++sequence; clearTimeout(timer); close(); say(''); sessionToken = null; updateMapLink(); });
    locate?.addEventListener('click', () => {
      if (!navigator.geolocation || !window.isSecureContext) { say('location_not_supported'); return; }
      const current = ++sequence;
      clearTimeout(timer); close(); locate.disabled = true; say('location_locating');
      navigator.geolocation.getCurrentPosition(async position => {
        try {
          if (current !== sequence) return;
          const location = {lat: position.coords.latitude, lng: position.coords.longitude};
          let address = location.lat.toFixed(6) + ', ' + location.lng.toFixed(6), id = '';
          if (config.maps && config.key) {
            try {
              const maps = await loadMaps();
              const {Geocoder} = await maps.importLibrary('geocoding');
              const {results} = await new Geocoder().geocode({location});
              if (results[0]) { address = results[0].formatted_address; id = results[0].place_id; }
            } catch { /* The GPS point is still a usable pickup even without reverse geocoding. */ }
          }
          if (current !== sequence) return;
          setPoint(address, location, id); say('location_from_gps');
        } finally { locate.disabled = false; }
      }, error => {
        locate.disabled = false;
        if (current === sequence) say(error.code === 1 ? 'location_denied' : 'location_unavailable');
      }, {enableHighAccuracy: true, timeout: 10000, maximumAge: 60000});
    });
    updateMapLink();
  });

  document.querySelector('[data-swap-locations]')?.addEventListener('click', () => {
    const fields = [...document.querySelectorAll('.ride-search [data-location-field]')];
    if (fields.length !== 2) return;
    ['[data-location-input]', '[data-location-lat]', '[data-location-lng]', '[data-location-place-id]'].forEach(selector => {
      const first = fields[0].querySelector(selector), second = fields[1].querySelector(selector);
      [first.value, second.value] = [second.value, first.value];
    });
    fields.forEach(field => field.dispatchEvent(new Event('ride:location-updated')));
  });

  const reviews = document.querySelector('[data-google-reviews]');
  if (!reviews || !config.reviews || !config.key || !config.placeId) return;
  const loadReviews = async () => {
    const list = reviews.querySelector('[data-reviews-list]');
    reviews.setAttribute('aria-busy', 'true');
    try {
      const maps = await loadMaps();
      const {Place} = await maps.importLibrary('places');
      const place = new Place({id: config.placeId, requestedLanguage: config.language});
      await place.fetchFields({fields: ['displayName', 'rating', 'userRatingCount', 'reviews', 'googleMapsURI', 'attributions']});
      const data = place.reviews || [];
      list.replaceChildren();
      data.forEach(review => {
        const card = node('article', 'review-card');
        const author = review.authorAttribution || {};
        const heading = node('div', 'review-author');
        const photo = httpsUrl(author.photoURI);
        if (photo) { const img = node('img'); img.src = photo; img.alt = author.displayName || ''; img.loading = 'lazy'; img.width = 40; img.height = 40; img.addEventListener('error', () => img.remove()); heading.append(img); }
        const details = node('div');
        const authorUrl = httpsUrl(author.uri);
        const name = node(authorUrl ? 'a' : 'strong', '', author.displayName || 'Google Maps');
        if (authorUrl) { name.href = authorUrl; name.target = '_blank'; name.rel = 'noopener noreferrer'; }
        details.append(name);
        const date = node('time', '', review.relativePublishTimeDescription || '');
        if (review.publishTime instanceof Date) date.dateTime = review.publishTime.toISOString();
        details.append(date); heading.append(details); card.append(heading);
        if (Number.isFinite(review.rating)) {
          const rating = Math.max(0, Math.min(5, Math.round(review.rating)));
          const stars = node('div', 'review-stars', '★'.repeat(rating) + '☆'.repeat(5 - rating));
          stars.setAttribute('aria-label', review.rating + ' / 5'); card.append(stars);
        }
        card.append(node('p', '', review.text || ''));
        if (review.originalTextLanguageCode && review.textLanguageCode && review.originalTextLanguageCode !== review.textLanguageCode) {
          card.append(node('small', 'translated-review', messages.translated_review));
        }
        if (Number.isInteger(review.visitDateMonth) && Number.isInteger(review.visitDateYear)) {
          const visited = new Date(Date.UTC(review.visitDateYear, review.visitDateMonth, 1));
          details.append(node('time', '', new Intl.DateTimeFormat(config.language, {month: 'short', year: 'numeric', timeZone: 'UTC'}).format(visited)));
        }
        const source = httpsUrl(review.googleMapsURI || review.googleMapsUri || place.googleMapsURI);
        if (source) { const link = node('a', '', messages.read_google_review); link.href = source; link.target = '_blank'; link.rel = 'noopener noreferrer'; card.append(link); }
        list.append(card);
      });
      reviews.querySelector('[data-reviews-fallback]').hidden = data.length > 0;
      if (Number.isFinite(place.rating)) {
        reviews.querySelector('[data-rating-value]').textContent = place.rating.toFixed(1);
        reviews.querySelector('[data-rating-count]').textContent = (messages.review_count || ':count reviews').replace(':count', (place.userRatingCount || 0).toLocaleString());
        reviews.querySelector('[data-google-rating]').hidden = false;
      }
      if (data.length) list.after(node('p', 'reviews-order', messages.reviews_order));
      (place.attributions || []).forEach(attribution => {
        const url = httpsUrl(attribution.providerURI);
        const credit = node(url ? 'a' : 'span', 'reviews-order', attribution.provider || '');
        if (url) { credit.href = url; credit.target = '_blank'; credit.rel = 'noopener noreferrer'; }
        reviews.append(credit);
      });
    } catch { /* Keep the real Google review link and feedback invitation available. */ }
    finally { reviews.removeAttribute('aria-busy'); }
  };
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) { observer.disconnect(); loadReviews(); }
    }, {rootMargin: '200px'});
    observer.observe(reviews);
  } else loadReviews();
})();
