<?php

namespace Database\Seeders;

use App\Models\ContentItem;
use App\Models\Extra;
use App\Models\Setting;
use App\Models\TravelRoute;
use App\Models\Vehicle;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $defaults = ['brand_name' => 'TAXIKH', 'default_language' => 'en', 'accent_color' => '#ffd801', 'booking_enabled' => '1', 'min_notice_hours' => '2', 'home_sections' => 'hero,search,routes,benefits,fleet,guides,faq,reviews', 'telegram_enabled' => '0',
            'routes_columns' => '3', 'routes_rows' => '3', 'routes_layout' => 'grid', 'routes_sort' => 'recommended', 'maintenance_enabled' => '0', 'seo_indexable' => '0', 'seo_site_url' => 'https://taxikh.com', 'review_embed_height' => '380',
            'seo_title_en' => 'Cambodia private taxi, airport transfers & tours', 'seo_title_km' => 'តាក់ស៊ីឯកជន ការទទួលនៅអាកាសយានដ្ឋាន និងទេសចរណ៍កម្ពុជា', 'seo_title_zh' => '柬埔寨包车、机场接送与私人旅游',
            'seo_description_en' => 'Book private taxi routes across Cambodia with TAXIKH. Choose your vehicle, add optional stops, and pay cash on arrival. No customer account required.',
            'seo_description_km' => 'កក់តាក់ស៊ីឯកជននៅកម្ពុជាជាមួយ TAXIKH។ ជ្រើសរើសរថយន្ត និងកន្លែងឈប់បន្ថែម ហើយបង់ប្រាក់ពេលមកដល់។ មិនត្រូវការគណនីអតិថិជន។',
            'seo_description_zh' => '通过 TAXIKH 预订柬埔寨专车，选择车型及途中停靠点，到达后现金付款，无需注册。',
            'default_theme' => 'system', 'google_maps_enabled' => '0', 'google_reviews_enabled' => '0', 'google_maps_api_key' => '', 'google_place_id' => '', 'google_reviews_url' => '',
            'tagline_en' => 'Private transfers & tours in Cambodia', 'tagline_km' => 'ដំណើរឯកជន និងទេសចរណ៍នៅកម្ពុជា', 'tagline_zh' => '柬埔寨专属接送与旅游',
            'footer_note_en' => 'Your journey, at your own pace.', 'footer_note_km' => 'ដំណើររបស់អ្នក តាមល្បឿនរបស់អ្នក។', 'footer_note_zh' => '您的旅程，随心而行。'];
        foreach ($defaults as $key => $value) {
            if (! Setting::whereKey($key)->exists()) {
                Setting::put($key, $value);
            }
        }
        // Demo records are created only in an empty catalog; rerunning never overwrites client edits.
        if (Setting::get('catalogue_initialized', '0') === '1' || Vehicle::exists() || TravelRoute::exists() || ContentItem::exists()) {
            return;
        }
        $data = json_decode(file_get_contents(__DIR__.'/demo-content.json'), true);
        $vehicleIds = [];
        foreach ($data['vehicles'] as $i => $v) {
            $vehicleIds[] = Vehicle::create([...$v, 'sort_order' => $i])->id;
        }
        foreach ($data['routes'] as $i => $r) {
            $prices = $r['prices'];
            unset($r['prices']);
            $route = TravelRoute::create([...$r, 'sort_order' => $i]);
            foreach ($vehicleIds as $j => $id) {
                $route->vehicles()->attach($id, ['price_cents' => $prices[$j]]);
            }
        }
        foreach ($data['content'] as $i => $c) {
            ContentItem::create([...$c, 'sort_order' => $i]);
        }
        Setting::put('catalogue_initialized', '1');
        foreach ($data['extras'] as $i => $e) {
            Extra::create([...$e, 'sort_order' => $i]);
        }
    }
}
