<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->unsignedInteger('dispatch_version')->default(0);
            $table->boolean('dispatch_review')->default(false)->index();
            $table->text('dispatch_reason')->nullable();
            $table->dateTime('dispatch_requested_at')->nullable();
            $table->dateTime('driver_accepted_at')->nullable();
            $table->dateTime('on_the_way_at')->nullable();
            $table->dateTime('picked_up_at')->nullable();
            $table->dateTime('completed_at')->nullable();
            $table->foreignId('completed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('cash_collected_by')->nullable()->constrained('users')->nullOnDelete();
            $table->decimal('completion_lat', 10, 7)->nullable();
            $table->decimal('completion_lng', 10, 7)->nullable();
            $table->decimal('completion_accuracy_m', 10, 2)->nullable();
            $table->dateTime('completion_captured_at')->nullable();
            $table->text('completion_note')->nullable();
        });
        Schema::table('telegram_deliveries', fn (Blueprint $table) => $table->json('context')->nullable());
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropConstrainedForeignId('completed_by');
            $table->dropConstrainedForeignId('cash_collected_by');
            $table->dropIndex(['dispatch_review']);
            $table->dropColumn(['dispatch_version', 'dispatch_review', 'dispatch_reason', 'dispatch_requested_at',
                'driver_accepted_at', 'on_the_way_at', 'picked_up_at', 'completed_at', 'completion_lat', 'completion_lng',
                'completion_accuracy_m', 'completion_captured_at', 'completion_note']);
        });
        Schema::table('telegram_deliveries', fn (Blueprint $table) => $table->dropColumn('context'));
    }
};
