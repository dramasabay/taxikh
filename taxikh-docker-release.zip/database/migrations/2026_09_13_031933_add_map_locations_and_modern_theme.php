<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            foreach (['pickup', 'dropoff'] as $point) {
                $table->decimal($point.'_lat', 10, 7)->nullable();
                $table->decimal($point.'_lng', 10, 7)->nullable();
                $table->string($point.'_place_id')->nullable();
            }
        });
        DB::table('settings')->where('key', 'accent_color')->where('value', '#d3ed86')->update(['value' => '#ffd801']);
        DB::table('settings')->where('key', 'home_sections')->where('value', 'routes,benefits,fleet,guides,faq')
            ->update(['value' => 'benefits,fleet,routes,guides,faq,reviews']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn(['pickup_lat', 'pickup_lng', 'pickup_place_id', 'dropoff_lat', 'dropoff_lng', 'dropoff_place_id']);
        });
    }
};
