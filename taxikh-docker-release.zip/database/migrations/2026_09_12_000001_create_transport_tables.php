<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->string('role', 20)->default('driver');
            $t->string('phone', 40)->nullable();
            $t->string('telegram_chat_id', 40)->nullable();
            $t->boolean('active')->default(true);
        });
        Schema::create('settings', function (Blueprint $t) {
            $t->string('key')->primary();
            $t->text('value')->nullable();
            $t->timestamps();
        });
        Schema::create('vehicles', function (Blueprint $t) {
            $t->id();
            $t->json('title');
            $t->json('description')->nullable();
            $t->string('image_path')->nullable();
            $t->unsignedSmallInteger('passengers');
            $t->unsignedSmallInteger('luggage')->default(2);
            $t->boolean('active')->default(true);
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
        });
        Schema::create('travel_routes', function (Blueprint $t) {
            $t->id();
            $t->string('slug')->unique();
            $t->string('type', 20)->default('transfer');
            $t->json('title');
            $t->json('origin');
            $t->json('destination');
            $t->json('description')->nullable();
            $t->json('included')->nullable();
            $t->json('additional_info')->nullable();
            $t->json('seo_description')->nullable();
            $t->string('image_path')->nullable();
            $t->json('gallery')->nullable();
            $t->string('attachment_path')->nullable();
            $t->unsignedInteger('distance_km')->default(0);
            $t->unsignedInteger('duration_minutes')->default(120);
            $t->boolean('active')->default(true);
            $t->boolean('featured')->default(false);
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
        });
        Schema::create('route_vehicle', function (Blueprint $t) {
            $t->id();
            $t->foreignId('travel_route_id')->constrained()->cascadeOnDelete();
            $t->foreignId('vehicle_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('price_cents');
            $t->unique(['travel_route_id', 'vehicle_id']);
        });
        Schema::create('extras', function (Blueprint $t) {
            $t->id();
            $t->json('title');
            $t->json('description')->nullable();
            $t->unsignedInteger('price_cents')->default(0);
            $t->boolean('active')->default(true);
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
        });
        Schema::create('content_items', function (Blueprint $t) {
            $t->id();
            $t->string('kind', 30);
            $t->string('slug')->nullable()->unique();
            $t->json('title');
            $t->json('body')->nullable();
            $t->json('subtitle')->nullable();
            $t->string('image_path')->nullable();
            $t->string('link')->nullable();
            $t->boolean('active')->default(true);
            $t->unsignedInteger('sort_order')->default(0);
            $t->timestamps();
            $t->index(['kind', 'active', 'sort_order']);
        });
        Schema::create('bookings', function (Blueprint $t) {
            $t->id();
            $t->string('reference', 30)->unique();
            $t->uuid('request_key')->unique();
            $t->string('request_fingerprint', 64);
            $t->text('public_token');
            $t->string('public_token_hash', 64)->unique();
            $t->foreignId('travel_route_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('vehicle_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('driver_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('locale', 5)->default('en');
            $t->string('customer_name', 100);
            $t->string('phone', 40);
            $t->unsignedSmallInteger('people');
            $t->string('pickup', 300);
            $t->string('dropoff', 300);
            $t->dateTime('departure_at');
            $t->dateTime('estimated_end_at');
            $t->string('timezone', 60)->default('Asia/Phnom_Penh');
            $t->text('notes')->nullable();
            $t->json('price_snapshot');
            $t->unsignedInteger('total_cents');
            $t->string('currency', 3)->default('USD');
            $t->string('payment_method', 20)->default('cash_on_arrival');
            $t->string('payment_status', 20)->default('unpaid');
            $t->dateTime('paid_at')->nullable();
            $t->string('status', 30)->default('pending');
            $t->text('staff_notes')->nullable();
            $t->timestamps();
            $t->index(['status', 'departure_at']);
            $t->index(['driver_id', 'departure_at']);
        });
        Schema::create('booking_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('booking_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('action', 60);
            $t->json('details')->nullable();
            $t->timestamps();
        });
        Schema::create('inquiries', function (Blueprint $t) {
            $t->id();
            $t->string('type', 30)->default('contact');
            $t->string('name', 100);
            $t->string('phone', 40);
            $t->string('email')->nullable();
            $t->text('message');
            $t->string('status', 20)->default('new');
            $t->timestamps();
        });
        Schema::create('alerts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('booking_id')->nullable()->constrained()->cascadeOnDelete();
            $t->string('kind', 30);
            $t->string('message', 200);
            $t->timestamp('read_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'read_at']);
        });
        Schema::create('telegram_deliveries', function (Blueprint $t) {
            $t->id();
            $t->foreignId('booking_id')->constrained()->cascadeOnDelete();
            $t->foreignId('target_user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('event', 30);
            $t->string('target', 20)->default('group');
            $t->string('status', 20)->default('pending');
            $t->unsignedSmallInteger('attempts')->default(0);
            $t->string('last_error')->nullable();
            $t->timestamp('sent_at')->nullable();
            $t->timestamps();
            $t->index(['status', 'created_at']);
        });
    }

    public function down(): void
    {
        foreach (['telegram_deliveries', 'alerts', 'inquiries', 'booking_events', 'bookings', 'content_items', 'extras', 'route_vehicle', 'travel_routes', 'vehicles', 'settings'] as $table) {
            Schema::dropIfExists($table);
        }
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['role', 'phone', 'telegram_chat_id', 'active']));
    }
};
