<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('travel_routes', fn (Blueprint $t) => $t->text('map_embed_url')->nullable());
        Schema::table('vehicles', function (Blueprint $t): void {
            $t->string('category', 20)->default('basic');
            $t->json('features')->nullable();
        });
        Schema::table('extras', function (Blueprint $t): void {
            $t->string('image_path')->nullable();
            $t->json('destination')->nullable();
            $t->foreignId('travel_route_id')->nullable()->constrained()->cascadeOnDelete();
        });
        foreach (['routes_columns' => '3', 'routes_rows' => '3', 'routes_layout' => 'grid', 'routes_sort' => 'recommended', 'maintenance_enabled' => '0', 'seo_indexable' => '0'] as $key => $value) {
            DB::table('settings')->insertOrIgnore(['key' => $key, 'value' => $value, 'created_at' => now(), 'updated_at' => now()]);
        }
        $sections = DB::table('settings')->where('key', 'home_sections')->value('value');
        if ($sections !== null) {
            DB::table('settings')->where('key', 'home_sections')->update(['value' => implode(',', array_unique(array_merge(['hero', 'search'], explode(',', $sections))))]);
        }
        DB::table('settings')->where('key', 'brand_name')->where('value', 'Mekong Ride')->update(['value' => 'TAXIKH']);
        DB::table('settings')->where('key', 'google_reviews_enabled')->update(['value' => '0']);
    }

    public function down(): void
    {
        Schema::table('extras', function (Blueprint $t): void {
            $t->dropConstrainedForeignId('travel_route_id');
            $t->dropColumn(['image_path', 'destination']);
        });
        Schema::table('vehicles', fn (Blueprint $t) => $t->dropColumn(['category', 'features']));
        Schema::table('travel_routes', fn (Blueprint $t) => $t->dropColumn('map_embed_url'));
    }
};
