<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('bookings', 'actual_duration_minutes')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedInteger('actual_duration_minutes')->nullable();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('bookings', 'actual_duration_minutes')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->dropColumn('actual_duration_minutes');
            });
        }
    }
};
