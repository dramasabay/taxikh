<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->decimal('commission_rate', 5, 2)->default(20.00);
            $table->unsignedInteger('commission_cents')->default(0);
            $table->unsignedInteger('driver_payout_cents')->default(0);
            $table->boolean('driver_agreed_commission')->default(false);
            $table->unsignedInteger('overtime_minutes')->default(0);
            $table->unsignedInteger('overtime_cents')->default(0);
        });

        Schema::table('travel_routes', function (Blueprint $table) {
            $table->boolean('overtime_enabled')->default(false);
            $table->unsignedInteger('overtime_interval_minutes')->default(2);
            $table->unsignedInteger('overtime_rate_cents')->default(100);
        });
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn([
                'commission_rate',
                'commission_cents',
                'driver_payout_cents',
                'driver_agreed_commission',
                'overtime_minutes',
                'overtime_cents',
            ]);
        });

        Schema::table('travel_routes', function (Blueprint $table) {
            $table->dropColumn([
                'overtime_enabled',
                'overtime_interval_minutes',
                'overtime_rate_cents',
            ]);
        });
    }
};
