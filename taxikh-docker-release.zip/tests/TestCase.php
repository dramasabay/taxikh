<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Illuminate\Support\Facades\Auth;

abstract class TestCase extends BaseTestCase
{
    public function actingAs($user, $guard = null)
    {
        parent::actingAs($user, $guard);
        $guard ??= config('auth.defaults.guard');

        // Switching test identities represents a fresh login, including its password binding.
        return $this->withSession(['password_hash_'.$guard => Auth::guard($guard)->hashPasswordForCookie($user->getAuthPassword())]);
    }
}
