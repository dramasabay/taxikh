<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Setting;
use App\Models\TelegramDelivery;
use App\Models\TravelRoute;
use App\Models\User;
use App\Services\BookingService;
use App\Services\DispatchService;
use App\Services\TelegramService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

class DriverWorkflowTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private User $driver;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
        Http::preventStrayRequests();
        $this->admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        $this->driver = User::factory()->create(['role' => 'driver', 'active' => true]);
    }

    private function booking(bool $assign = true): Booking
    {
        $route = TravelRoute::first();
        $booking = app(BookingService::class)->create(['request_key' => (string) Str::uuid(), 'route_id' => $route->id,
            'vehicle_id' => $route->vehicles->first()->id, 'locale' => 'en', 'customer_name' => 'Workflow passenger',
            'phone' => '+85512345678', 'people' => 2, 'pickup' => 'Phnom Penh hotel', 'dropoff' => 'Siem Reap hotel',
            'dropoff_lat' => '13.3633', 'dropoff_lng' => '103.8564',
            'departure_date' => now('Asia/Phnom_Penh')->addDays(3)->format('Y-m-d'), 'departure_time' => '10:00']);
        $dispatch = app(DispatchService::class);
        $dispatch->update($booking->id, $this->admin, ['status' => 'confirmed']);
        if ($assign) {
            $dispatch->update($booking->id, $this->admin, ['status' => 'assigned', 'driver_id' => $this->driver->id]);
        }

        return $booking->refresh();
    }

    private function action(Booking $booking, string $action, array $extra = []): TestResponse
    {
        return $this->actingAs($this->driver)->postJson('/driver/bookings/'.$booking->id.'/action',
            ['action' => $action, 'dispatch_version' => $booking->fresh()->dispatch_version, ...$extra]);
    }

    private function onboard(Booking $booking): void
    {
        foreach (['accept', 'on_the_way', 'pickup'] as $action) {
            $this->action($booking, $action)->assertOk();
        }
    }

    public function test_driver_accepts_picks_up_completes_and_records_cash_with_a_location(): void
    {
        $booking = $this->booking();
        $this->action($booking, 'on_the_way')->assertUnprocessable()->assertJsonValidationErrors('action');
        $this->action($booking, 'complete')->assertUnprocessable();
        $this->onboard($booking);
        $data = ['completion_lat' => 13.36331, 'completion_lng' => 103.85641, 'completion_accuracy_m' => 8,
            'completion_captured_at' => now()->timestamp, 'completion_note' => 'Private driver completion note', 'cash_received' => 1];
        $this->action($booking, 'complete', $data)->assertOk()->assertJsonPath('status', 'completed');
        $booking->refresh();
        $this->assertNotNull($booking->driver_accepted_at);
        $this->assertNotNull($booking->on_the_way_at);
        $this->assertNotNull($booking->picked_up_at);
        $this->assertNotNull($booking->completed_at);
        $this->assertSame($this->driver->id, $booking->completed_by);
        $this->assertSame('paid', $booking->payment_status);
        $this->assertLessThan(5, $booking->completionDistanceMeters());
        $this->assertDatabaseHas('alerts', ['user_id' => $this->admin->id, 'kind' => 'trip_completed']);
        $this->actingAs($this->admin)->get('/admin/bookings/'.$booking->id)->assertOk()
            ->assertSee('Drop-off record')->assertSee('Private driver completion note')->assertSee($booking->completionMapUrl());
        $this->get('/en/reservation/'.$booking->public_token)->assertOk()->assertSee('Trip completed')
            ->assertDontSee('Private driver completion note')->assertDontSee($booking->completionMapUrl());
        $completedAt = $booking->completed_at->toISOString();
        $eventCount = $booking->events()->count();
        $this->travel(10)->seconds();
        $this->action($booking, 'complete', $data)->assertOk();
        $this->assertSame($completedAt, $booking->fresh()->completed_at->toISOString());
        $this->assertSame($eventCount, $booking->events()->count());
    }

    public function test_driver_returns_a_pre_pickup_booking_to_admin_with_a_reason(): void
    {
        $booking = $this->booking();
        $total = $booking->total_cents;
        $this->action($booking, 'return')->assertUnprocessable()->assertJsonValidationErrors('reason');
        $this->action($booking, 'return', ['reason' => 'Vehicle will not start'])->assertOk()
            ->assertJsonPath('redirect_url', url('/driver/bookings'));
        $booking->refresh();
        $this->assertNull($booking->driver_id);
        $this->assertSame('confirmed', $booking->status);
        $this->assertTrue($booking->dispatch_review);
        $this->assertSame($total, $booking->total_cents);
        $this->assertDatabaseHas('alerts', ['user_id' => $this->admin->id, 'kind' => 'driver_returned']);
        $this->get('/driver/bookings/'.$booking->id)->assertForbidden();
        $this->get('/driver/bookings')->assertOk()->assertDontSee($booking->reference);
        $this->actingAs($this->admin)->get('/admin')->assertOk()->assertSee('Needs dispatch');
        $this->get('/admin/bookings?dispatch_review=1')->assertOk()->assertSee($booking->reference);
        $this->get('/admin/bookings/'.$booking->id)->assertOk()->assertSee('Vehicle will not start');
        $this->post('/admin/bookings/'.$booking->id.'/resolve-dispatch', ['dispatch_version' => $booking->dispatch_version,
            'dispatch_note' => 'Reviewed'])->assertSessionHasErrors('driver_id');
        $this->assertTrue($booking->fresh()->dispatch_review);
    }

    public function test_return_during_pickup_travel_resets_assignment_and_admin_can_reassign(): void
    {
        $booking = $this->booking();
        $this->action($booking, 'accept')->assertOk();
        $this->action($booking, 'on_the_way')->assertOk();
        $this->action($booking, 'return', ['reason' => 'Flat tyre'])->assertOk();
        $booking->refresh();
        $this->assertNull($booking->driver_accepted_at);
        $this->assertNull($booking->on_the_way_at);
        $replacement = User::factory()->create(['role' => 'driver', 'active' => true]);
        $this->actingAs($this->admin)->patch('/admin/bookings/'.$booking->id, ['status' => 'assigned',
            'driver_id' => $replacement->id, 'dispatch_version' => $booking->dispatch_version])->assertSessionHasNoErrors();
        $this->assertFalse($booking->fresh()->dispatch_review);
        $this->assertSame($replacement->id, $booking->fresh()->driver_id);
        $this->action($booking, 'accept')->assertForbidden();
    }

    public function test_help_after_pickup_preserves_driver_until_admin_resolves_it(): void
    {
        $booking = $this->booking();
        $this->onboard($booking);
        $this->action($booking, 'return', ['reason' => 'Passenger needs another vehicle'])->assertOk()->assertJsonPath('dispatch_review', true);
        $booking->refresh();
        $this->assertSame('in_progress', $booking->status);
        $this->assertSame($this->driver->id, $booking->driver_id);
        $this->assertTrue($booking->dispatch_review);
        $this->action($booking, 'return', ['reason' => 'Repeated tap'])->assertOk();
        $this->assertSame(1, $booking->events()->where('action', 'driver_help_requested')->count());
        $this->assertSame('Passenger needs another vehicle', $booking->fresh()->dispatch_reason);
        $version = $booking->dispatch_version;
        $this->actingAs($this->admin)->post('/admin/bookings/'.$booking->id.'/resolve-dispatch',
            ['dispatch_version' => $version, 'dispatch_note' => 'Spoke with driver; safe to continue'])->assertRedirect('/admin/bookings/'.$booking->id)->assertSessionHasNoErrors();
        $this->assertFalse($booking->fresh()->dispatch_review);
        $this->assertDatabaseHas('alerts', ['user_id' => $this->driver->id, 'kind' => 'dispatch_resolved']);
        $this->action($booking, 'complete', ['dispatch_version' => $version])->assertUnprocessable()->assertJsonValidationErrors('action');
        $this->action($booking, 'complete')->assertOk();
    }

    public function test_admin_handover_preserves_pickup_time_and_requires_the_new_driver_to_accept(): void
    {
        $booking = $this->booking();
        $this->onboard($booking);
        $pickedUpAt = $booking->fresh()->picked_up_at->toISOString();
        $this->action($booking, 'return', ['reason' => 'Need a replacement vehicle'])->assertOk();
        $replacement = User::factory()->create(['role' => 'driver', 'active' => true]);
        $this->actingAs($this->admin)->patch('/admin/bookings/'.$booking->id, ['status' => 'in_progress',
            'driver_id' => $replacement->id, 'dispatch_version' => $booking->fresh()->dispatch_version])->assertSessionHasNoErrors();
        $booking->refresh();
        $this->assertFalse($booking->dispatch_review);
        $this->assertNull($booking->driver_accepted_at);
        $this->assertSame($pickedUpAt, $booking->picked_up_at->toISOString());
        $this->action($booking, 'complete')->assertForbidden();
        $this->driver = $replacement;
        $this->action($booking, 'complete')->assertUnprocessable()->assertJsonValidationErrors('action');
        $this->action($booking, 'accept')->assertOk();
        $this->action($booking, 'complete')->assertOk();
        $this->assertSame($replacement->id, $booking->fresh()->completed_by);
    }

    public function test_manual_completion_does_not_claim_cash_or_location_and_cash_can_be_recorded_later(): void
    {
        $booking = $this->booking();
        $this->action($booking, 'collect_cash')->assertUnprocessable();
        $this->onboard($booking);
        $this->action($booking, 'complete')->assertOk();
        $booking->refresh();
        $this->assertNull($booking->completionMapUrl());
        $this->assertSame('unpaid', $booking->payment_status);
        $this->get('/driver/bookings/'.$booking->id)->assertOk()->assertSee('cash is still recorded as unpaid');
        $completedAt = $booking->completed_at->toISOString();
        $this->action($booking, 'collect_cash')->assertOk();
        $this->assertSame('paid', $booking->fresh()->payment_status);
        $this->assertSame($completedAt, $booking->fresh()->completed_at->toISOString());
    }

    public function test_a_handover_keeps_cash_attributed_to_the_original_collector(): void
    {
        $booking = $this->booking();
        $this->onboard($booking);
        $this->action($booking, 'collect_cash')->assertOk();
        $originalDriver = $this->driver;
        $this->action($booking, 'return', ['reason' => 'Arrange handover'])->assertOk();
        $replacement = User::factory()->create(['role' => 'driver', 'active' => true]);
        app(DispatchService::class)->update($booking->id, $this->admin, ['status' => 'in_progress', 'driver_id' => $replacement->id]);
        $this->driver = $replacement;
        $this->action($booking, 'accept')->assertOk();
        $this->action($booking, 'complete', ['cash_received' => 1])->assertOk();
        $this->assertSame($originalDriver->id, $booking->fresh()->cash_collected_by);
        $this->actingAs($replacement)->get('/driver')->assertOk()->assertViewHas('stats', fn ($stats) => $stats['cash'] === 0);
        $this->actingAs($originalDriver)->get('/driver')->assertOk()->assertViewHas('stats', fn ($stats) => $stats['cash'] === $booking->total_cents);
    }

    public function test_bad_or_stale_location_data_cannot_complete_a_trip(): void
    {
        $booking = $this->booking();
        $this->onboard($booking);
        $data = ['completion_lat' => 13.36, 'completion_lng' => 103.85, 'completion_accuracy_m' => 10, 'completion_captured_at' => now()->timestamp];
        $this->action($booking, 'complete', [...$data, 'completion_lat' => 91])->assertUnprocessable()->assertJsonValidationErrors('completion_lat');
        $this->action($booking, 'complete', [...$data, 'completion_lng' => ''])->assertUnprocessable()->assertJsonValidationErrors('completion_lng');
        $this->action($booking, 'complete', [...$data, 'completion_accuracy_m' => -1])->assertUnprocessable();
        $this->action($booking, 'complete', [...$data, 'completion_captured_at' => now()->subMinutes(10)->timestamp])->assertUnprocessable()->assertJsonValidationErrors('completion_lat');
        $this->action($booking, 'complete', [...$data, 'completion_captured_at' => now()->addMinutes(10)->timestamp])->assertUnprocessable();
        $this->assertSame('in_progress', $booking->fresh()->status);
        $this->assertNull($booking->fresh()->completed_at);
    }

    public function test_driver_permissions_and_stale_assignment_versions_are_enforced(): void
    {
        $booking = $this->booking();
        $version = $booking->dispatch_version;
        $other = User::factory()->create(['role' => 'driver', 'active' => true]);
        $url = '/driver/bookings/'.$booking->id.'/action';
        $this->actingAs($other)->postJson($url, ['action' => 'accept', 'dispatch_version' => $version])->assertForbidden();
        $this->actingAs($this->admin)->postJson($url, ['action' => 'accept', 'dispatch_version' => $version])->assertForbidden();
        $this->action($booking, 'return', ['reason' => 'Temporary issue'])->assertOk();
        $this->actingAs($this->admin)->patch('/admin/bookings/'.$booking->id,
            ['status' => 'assigned', 'driver_id' => $this->driver->id])->assertSessionHasNoErrors();
        $this->action($booking, 'accept', ['dispatch_version' => $version])->assertUnprocessable()->assertJsonValidationErrors('action');
        $this->action($booking, 'accept')->assertOk();
    }

    public function test_legacy_driver_update_requires_the_current_assignment_version(): void
    {
        $booking = $this->booking();
        $this->actingAs($this->driver)->patchJson('/driver/bookings/'.$booking->id, ['status' => 'on_the_way'])
            ->assertUnprocessable()->assertJsonValidationErrors('status');
        $this->assertSame('assigned', $booking->fresh()->status);
    }

    public function test_telegram_return_reason_is_retained_even_when_admin_has_already_reassigned(): void
    {
        $booking = $this->booking();
        $this->action($booking, 'return', ['reason' => 'Original return reason'])->assertOk();
        $delivery = TelegramDelivery::where('event', 'driver_returned')->firstOrFail();
        $replacement = User::factory()->create(['role' => 'driver', 'active' => true]);
        app(DispatchService::class)->update($booking->id, $this->admin, ['status' => 'assigned', 'driver_id' => $replacement->id]);
        $booking->update(['dispatch_reason' => 'Later unrelated note']);
        Setting::put('telegram_enabled', '1');
        Setting::put('telegram_bot_token', Crypt::encryptString('123456:workflow-test-token'));
        Setting::put('telegram_group_id', '-1001234567');
        Http::fake(['api.telegram.org/*' => Http::response(['ok' => true])]);
        $this->assertTrue(app(TelegramService::class)->send($delivery->id));
        Http::assertSent(fn ($request) => str_contains($request['text'], 'Original return reason') && ! str_contains($request['text'], 'Later unrelated note'));
    }

    public function test_driver_controls_and_completion_details_render_in_three_languages(): void
    {
        $booking = $this->booking();
        foreach (['en', 'km', 'zh'] as $locale) {
            $this->actingAs($this->driver)->get('/staff/language/'.$locale);
            $this->get('/driver/bookings/'.$booking->id)->assertOk()->assertSee('data-driver-action-form', false)->assertDontSee('ui.accept_trip')->assertDontSee('name="staff_notes"', false);
        }
        $this->onboard($booking);
        $this->get('/driver/bookings/'.$booking->id)->assertOk()->assertSee('data-capture-completion', false)->assertDontSee('ui.completion_');
        $this->action($booking, 'complete')->assertOk();
        $this->get('/driver/bookings/'.$booking->id)->assertOk()->assertDontSee('ui.dropoff_record')->assertDontSee('value="return"', false);
    }

    public function test_driver_workflow_migration_preserves_existing_bookings(): void
    {
        $booking = $this->booking();
        $id = $booking->id;
        $total = $booking->total_cents;
        $migration = require database_path('migrations/2026_09_13_093853_add_driver_workflow_to_bookings_table.php');
        $migration->down();
        $this->assertFalse(Schema::hasColumn('bookings', 'completed_at'));
        $migration->up();
        $this->assertSame($total, Booking::findOrFail($id)->total_cents);
        $this->assertSame($this->driver->id, Booking::findOrFail($id)->driver_id);
        $this->assertNull(Booking::findOrFail($id)->completed_at);
        $this->assertSame('assigned', Booking::findOrFail($id)->status);
    }
}
