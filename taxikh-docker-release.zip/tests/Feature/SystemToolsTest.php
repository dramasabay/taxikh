<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Setting;
use App\Models\TravelRoute;
use App\Models\User;
use App\Services\BackupService;
use App\Services\BookingService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Tests\TestCase;
use ZipArchive;

class SystemToolsTest extends TestCase
{
    use RefreshDatabase;

    private string $backupDirectory;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
        Http::preventStrayRequests();
        Storage::fake('public');
        $this->backupDirectory = storage_path('framework/testing/system-'.Str::random(10));
        File::makeDirectory($this->backupDirectory, 0700, true);
        $path = $this->backupDirectory;
        $service = new class($path) extends BackupService
        {
            public function __construct(private string $testPath) {}

            public function directory(): string
            {
                return $this->testPath;
            }
        };
        $this->app->instance(BackupService::class, $service);
        $this->admin = User::factory()->create(['role' => 'admin', 'active' => true, 'password' => 'System-test-password-123']);
        $this->actingAs($this->admin);
    }

    protected function tearDown(): void
    {
        File::deleteDirectory($this->backupDirectory);
        parent::tearDown();
    }

    private function booking(): Booking
    {
        $route = TravelRoute::first();

        return app(BookingService::class)->create(['request_key' => (string) Str::uuid(), 'route_id' => $route->id, 'vehicle_id' => $route->vehicles->first()->id, 'locale' => 'en', 'customer_name' => 'Backup Customer', 'phone' => '+85512345678', 'people' => 2, 'pickup' => 'Phnom Penh Hotel', 'dropoff' => 'Siem Reap Hotel', 'departure_date' => now()->addDays(3)->format('Y-m-d'), 'departure_time' => '09:00']);
    }

    private function confirmed(string $phrase): array
    {
        return ['confirm' => $phrase, 'current_password' => 'System-test-password-123', 'worker_stopped' => 1];
    }

    private function backup(): string
    {
        return app(BackupService::class)->create();
    }

    private function upload(string $file): UploadedFile
    {
        return new UploadedFile($this->backupDirectory.'/'.$file, 'backup.zip', 'application/zip', null, true);
    }

    public function test_private_encrypted_backup_can_be_downloaded_only_by_admin(): void
    {
        $this->booking();
        Storage::disk('public')->put('uploads/2026/09/Example.png', 'test-image');
        $this->post('/admin/system/backup', ['current_password' => 'System-test-password-123'])->assertSessionHasNoErrors()->assertRedirect('/admin/system');
        $file = basename(glob($this->backupDirectory.'/*.zip')[0]);
        $zip = new ZipArchive;
        $zip->open($this->backupDirectory.'/'.$file);
        $encrypted = $zip->getFromName('database.enc');
        $this->assertStringNotContainsString('Backup Customer', $encrypted);
        $manifest = json_decode(Crypt::decryptString($encrypted), true);
        $this->assertSame('Backup Customer', $manifest['tables']['bookings'][0]['customer_name']);
        $this->assertSame('test-image', $zip->getFromName('media/uploads/2026/09/Example.png'));
        $this->assertArrayNotHasKey('jobs', $manifest['tables']);
        $zip->close();
        $this->get('/admin/system')->assertOk()->assertSee($file);
        $this->get('/admin/system/backups/'.$file)->assertDownload($file);
        $this->actingAs(User::factory()->create(['role' => 'dispatcher', 'active' => true]))->get('/admin/system')->assertForbidden();
        $this->get('/admin/system/backups/'.$file)->assertForbidden();
    }

    public function test_maintenance_blocks_public_bookings_but_preserves_staff_access(): void
    {
        $this->post('/admin/system/maintenance', ['enabled' => 1])->assertRedirect('/admin/system');
        $this->get('/en')->assertStatus(503)->assertSee('back soon')->assertHeader('Retry-After', '3600');
        $this->postJson('/api/v1/bookings', [])->assertStatus(503);
        $this->post('/en/inquiry', [])->assertStatus(503);
        $this->get('/staff/login')->assertOk();
        $this->get('/admin/system')->assertOk();
        $this->post('/admin/system/maintenance', ['enabled' => 0]);
        $this->get('/en')->assertOk();
    }

    public function test_restore_reinstates_data_and_media_without_replaying_notifications(): void
    {
        $booking = $this->booking();
        $token = $booking->public_token;
        Storage::disk('public')->put('uploads/2026/09/Photo.png', 'original');
        $file = $this->backup();
        Storage::disk('public')->delete('uploads/2026/09/Photo.png');
        $booking->update(['customer_name' => 'Changed']);
        Setting::put('brand_name', 'Changed brand');
        Setting::put('maintenance_enabled', '1');
        $this->post('/admin/system/restore', [...$this->confirmed('RESTORE'), 'backup' => $this->upload($file)])->assertSessionHasNoErrors()->assertRedirect('/staff/login');
        $this->assertSame('Backup Customer', Booking::first()->customer_name);
        $this->assertSame($token, Booking::first()->public_token);
        $this->assertSame('TAXIKH', Setting::get('brand_name'));
        $this->assertSame('1', Setting::get('maintenance_enabled'));
        $this->assertDatabaseHas('telegram_deliveries', ['status' => 'cancelled']);
        Storage::disk('public')->assertExists('uploads/2026/09/Photo.png');
        $this->assertCount(2, glob($this->backupDirectory.'/*.zip'));
        $this->assertGuest();
    }

    public function test_destructive_controls_require_password_confirmation_and_maintenance(): void
    {
        $booking = $this->booking();
        $this->post('/admin/system/clear', [...$this->confirmed('CLEAR BOOKINGS'), 'scope' => 'operations'])->assertSessionHasErrors('system');
        $this->assertModelExists($booking);
        Setting::put('maintenance_enabled', '1');
        foreach ([['current_password' => 'wrong'], ['confirm' => 'wrong'], ['worker_stopped' => 0]] as $extra) {
            $this->post('/admin/system/clear', [...$this->confirmed('CLEAR BOOKINGS'), 'scope' => 'operations', ...$extra])->assertSessionHasErrors(array_key_first($extra));
            $this->assertModelExists($booking);
        }
        $this->assertCount(0, glob($this->backupDirectory.'/*.zip'));
    }

    public function test_clear_and_catalogue_reset_preserve_accounts_settings_and_safety_backups(): void
    {
        $this->booking();
        Setting::put('maintenance_enabled', '1');
        $count = TravelRoute::count();
        $this->post('/admin/system/clear', [...$this->confirmed('CLEAR BOOKINGS'), 'scope' => 'operations'])->assertSessionHasNoErrors();
        $this->assertDatabaseCount('bookings', 0);
        $this->assertSame($count, TravelRoute::count());
        $this->post('/admin/system/clear', [...$this->confirmed('RESET CATALOGUE'), 'scope' => 'reset'])->assertSessionHasNoErrors();
        $this->assertDatabaseCount('travel_routes', 0);
        $this->assertDatabaseCount('vehicles', 0);
        $this->assertModelExists($this->admin);
        $this->assertSame('TAXIKH', Setting::get('brand_name'));
        $this->assertCount(2, glob($this->backupDirectory.'/*.zip'));
        $this->seed();
        $this->assertDatabaseCount('travel_routes', 0);
        $this->post('/admin/system/maintenance', ['enabled' => 0]);
        $this->get('/en')->assertOk();
    }

    public function test_tampered_manifest_path_traversal_or_media_corruption_never_replace_data(): void
    {
        $booking = $this->booking();
        $file = $this->backup();
        $zip = new ZipArchive;
        $zip->open($this->backupDirectory.'/'.$file);
        $zip->addFromString('../outside.php', '<?php bad();');
        $zip->close();
        Setting::put('maintenance_enabled', '1');
        $this->post('/admin/system/restore', [...$this->confirmed('RESTORE'), 'backup' => $this->upload($file)])->assertSessionHasErrors('backup');
        $this->assertModelExists($booking);
        $this->assertFileDoesNotExist(dirname($this->backupDirectory).'/outside.php');
        $file = $this->backup();
        $zip->open($this->backupDirectory.'/'.$file);
        $zip->addFromString('database.enc', 'modified');
        $zip->close();
        $this->post('/admin/system/restore', [...$this->confirmed('RESTORE'), 'backup' => $this->upload($file)])->assertSessionHasErrors('backup');
        $this->assertSame('Backup Customer', $booking->fresh()->customer_name);
    }

    public function test_foreign_key_backup_and_schema_mismatch_are_rejected_before_mutation(): void
    {
        $booking = $this->booking();
        $file = $this->backup();
        $zip = new ZipArchive;
        $zip->open($this->backupDirectory.'/'.$file);
        $manifest = json_decode(Crypt::decryptString($zip->getFromName('database.enc')), true);
        $manifest['migrations'][] = 'future-version';
        $zip->addFromString('database.enc', Crypt::encryptString(json_encode($manifest)));
        $zip->close();
        Setting::put('maintenance_enabled', '1');
        $this->post('/admin/system/restore', [...$this->confirmed('RESTORE'), 'backup' => $this->upload($file)])->assertSessionHasErrors('backup');
        $this->assertModelExists($booking);
    }

    public function test_a_database_constraint_failure_rolls_back_the_restore_and_removes_new_media(): void
    {
        $booking = $this->booking();
        Storage::disk('public')->put('uploads/2026/09/Recovered.png', 'recover-me');
        $file = $this->backup();
        $zip = new ZipArchive;
        $zip->open($this->backupDirectory.'/'.$file);
        $manifest = json_decode(Crypt::decryptString($zip->getFromName('database.enc')), true);
        $manifest['tables']['bookings'][0]['vehicle_id'] = 999999;
        $zip->addFromString('database.enc', Crypt::encryptString(json_encode($manifest)));
        $zip->close();
        Storage::disk('public')->delete('uploads/2026/09/Recovered.png');
        $booking->update(['customer_name' => 'Keep current record']);
        Setting::put('maintenance_enabled', '1');
        $this->post('/admin/system/restore', [...$this->confirmed('RESTORE'), 'backup' => $this->upload($file)])->assertSessionHasErrors('backup');
        $this->assertSame('Keep current record',$booking->fresh()->customer_name);
        $this->assertModelExists($this->admin);
        Storage::disk('public')->assertMissing('uploads/2026/09/Recovered.png');
        $this->assertAuthenticatedAs($this->admin);
    }
}
