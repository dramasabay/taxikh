<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\StaffSessionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class SecuritySessionTest extends TestCase
{
    use RefreshDatabase;

    public function test_staff_login_binds_the_session_to_the_current_password(): void
    {
        $user = User::factory()->create(['role' => 'admin', 'active' => true, 'password' => 'Original-password-123']);

        $this->post('/staff/login', ['email' => $user->email, 'password' => 'Original-password-123'])
            ->assertRedirect('/admin')
            ->assertSessionHas('password_hash_web', Auth::guard('web')->hashPasswordForCookie($user->fresh()->getAuthPassword()));
    }

    public function test_password_reset_invalidates_existing_sessions_on_each_staff_area(): void
    {
        foreach ([['admin', '/admin'], ['driver', '/driver'], ['dispatcher', '/staff/profile']] as [$role, $path]) {
            $user = User::factory()->create(['role' => $role, 'active' => true]);
            $oldHash = $user->getAuthPassword();
            $user->update(['password' => 'Replacement-password-123']);

            $this->actingAs($user)->withSession(['password_hash_web' => $oldHash])
                ->getJson($path)->assertUnauthorized();
        }
    }

    public function test_self_password_change_rotates_credentials_and_keeps_current_session_valid(): void
    {
        $user = User::factory()->create(['role' => 'admin', 'active' => true, 'password' => 'Original-password-123', 'remember_token' => 'old-remember-token']);
        $this->actingAs($user);
        $oldSessionId = session()->getId();

        $this->post('/staff/password', ['current_password' => 'Original-password-123', 'password' => 'Replacement-password-123', 'password_confirmation' => 'Replacement-password-123'])
            ->assertRedirect('/staff/profile')->assertSessionHasNoErrors();

        $fresh = $user->fresh();
        $this->assertTrue(Hash::check('Replacement-password-123', $fresh->password));
        $this->assertNotSame('old-remember-token', $fresh->remember_token);
        $this->assertNotSame($oldSessionId, session()->getId());
        $this->get('/staff/profile')->assertOk();
    }

    public function test_revocation_removes_legacy_database_sessions_without_affecting_other_staff(): void
    {
        $user = User::factory()->create(['role' => 'driver', 'active' => true]);
        $other = User::factory()->create(['role' => 'driver', 'active' => true]);
        config(['session.driver' => 'database']);
        foreach ([['keep', $user->id], ['stale', $user->id], ['other-staff', $other->id]] as [$id, $userId]) {
            DB::table('sessions')->insert(['id' => $id, 'user_id' => $userId, 'payload' => '', 'last_activity' => now()->timestamp]);
        }

        app(StaffSessionService::class)->revoke($user, 'keep');
        $this->assertDatabaseHas('sessions', ['id' => 'keep']);
        $this->assertDatabaseMissing('sessions', ['id' => 'stale']);
        $this->assertDatabaseHas('sessions', ['id' => 'other-staff']);

        app(StaffSessionService::class)->revoke($user);
        $this->assertDatabaseMissing('sessions', ['user_id' => $user->id]);
        $this->assertDatabaseHas('sessions', ['id' => 'other-staff']);
    }

    public function test_administrator_password_reset_revokes_target_sessions_and_remember_tokens(): void
    {
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        $driver = User::factory()->create(['role' => 'driver', 'active' => true, 'remember_token' => 'old-remember-token']);
        $oldHash = $driver->getAuthPassword();
        $this->mock(StaffSessionService::class, function ($mock) use ($driver): void {
            $mock->shouldReceive('revoke')->once()->withArgs(fn (User $target, ?string $keep) => $target->id === $driver->id && $keep === null);
        });

        $this->actingAs($admin)->put('/admin/manage/users/'.$driver->id, [
            'name' => $driver->name, 'email' => $driver->email, 'role' => 'driver', 'active' => 1,
            'password' => 'Administrator-reset-123', 'password_confirmation' => 'Administrator-reset-123',
        ])->assertSessionHasNoErrors()->assertRedirect('/admin/manage/users/'.$driver->id.'/edit');

        $driver->refresh();
        $this->assertTrue(Hash::check('Administrator-reset-123', $driver->password));
        $this->assertNotSame('old-remember-token', $driver->remember_token);
        $this->actingAs($driver)->withSession(['password_hash_web' => $oldHash])->getJson('/driver')->assertUnauthorized();
    }
}
