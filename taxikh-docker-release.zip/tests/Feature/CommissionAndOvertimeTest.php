<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Setting;
use App\Models\TravelRoute;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\DispatchService;
use App\Services\DriverTripService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Queue;
use Tests\TestCase;

class CommissionAndOvertimeTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
    }

    public function test_dual_currency_formatting()
    {
        Setting::put('riel_exchange_rate', 4100);
        Setting::put('currency_mode', 'dual');

        $formatted = money(3000); // $30.00
        $this->assertStringContainsString('$30.00', $formatted);
        $this->assertStringContainsString('123,000 ៛', $formatted);

        Setting::put('currency_mode', 'usd_only');
        $this->assertSame('$30.00', money(3000));
    }

    public function test_driver_commission_calculation_and_acceptance()
    {
        Setting::put('default_driver_commission', 20);

        $driver = User::factory()->create(['role' => 'driver', 'active' => true]);
        $route = TravelRoute::first();
        $vehicle = Vehicle::first();

        // Create booking with $30.00 fare (3000 cents)
        $booking = Booking::create([
            'reference' => 'BK-COMMISSION-1',
            'request_key' => (string) \Illuminate\Support\Str::uuid(),
            'request_fingerprint' => hash('sha256', 'test-fp-1'),
            'public_token' => 'tok-commission-1',
            'public_token_hash' => hash('sha256', 'tok-commission-1'),
            'travel_route_id' => $route->id,
            'vehicle_id' => $vehicle->id,
            'pickup' => 'Phnom Penh Hotel',
            'dropoff' => 'Sihanoukville Beach',
            'customer_name' => 'John Doe',
            'phone' => '+85512345678',
            'departure_at' => now('Asia/Phnom_Penh')->addDay(),
            'estimated_end_at' => now('Asia/Phnom_Penh')->addDay()->addHours(2),
            'people' => 2,
            'price_snapshot' => ['base' => 3000, 'total' => 3000],
            'total_cents' => 3000,
            'commission_rate' => 20,
            'commission_cents' => 600, // 20% of $30 = $6
            'driver_payout_cents' => 2400, // $24
            'driver_agreed_commission' => false,
            'status' => 'confirmed',
            'payment_status' => 'unpaid',
            'payment_method' => 'cash_on_arrival',
        ]);

        $this->assertEquals(600, $booking->commission_cents);
        $this->assertEquals(2400, $booking->driver_payout_cents);
        $this->assertFalse((bool) $booking->driver_agreed_commission);

        // Assign to driver
        $booking->update(['driver_id' => $driver->id, 'status' => 'assigned']);

        // Driver accepts trip and agrees to commission
        $driverTripService = app(DriverTripService::class);
        $driverTripService->act($booking->id, $driver, [
            'action' => 'accept',
            'dispatch_version' => $booking->dispatch_version,
        ]);

        $freshBooking = $booking->fresh();
        $this->assertTrue((bool) $freshBooking->driver_agreed_commission);
        $this->assertNotNull($freshBooking->driver_accepted_at);
    }

    public function test_overtime_fee_calculation_on_completion()
    {
        $driver = User::factory()->create(['role' => 'driver', 'active' => true]);
        $route = TravelRoute::first();
        $route->update([
            'duration_minutes' => 10,
            'overtime_enabled' => true,
            'overtime_interval_minutes' => 2,
            'overtime_rate_cents' => 100, // $1 per 2 minutes
        ]);
        $vehicle = Vehicle::first();

        $booking = Booking::create([
            'reference' => 'BK-OVERTIME-1',
            'request_key' => (string) \Illuminate\Support\Str::uuid(),
            'request_fingerprint' => hash('sha256', 'test-fp-2'),
            'public_token' => 'tok-overtime-1',
            'public_token_hash' => hash('sha256', 'tok-overtime-1'),
            'travel_route_id' => $route->id,
            'vehicle_id' => $vehicle->id,
            'driver_id' => $driver->id,
            'pickup' => 'Point A',
            'dropoff' => 'Point B',
            'customer_name' => 'Jane Smith',
            'phone' => '+85598765432',
            'departure_at' => now('Asia/Phnom_Penh')->addDay(),
            'estimated_end_at' => now('Asia/Phnom_Penh')->addDay()->addMinutes(10),
            'people' => 1,
            'price_snapshot' => ['base' => 1000, 'total' => 1000],
            'total_cents' => 1000,
            'commission_rate' => 20,
            'commission_cents' => 200,
            'driver_payout_cents' => 800,
            'driver_agreed_commission' => true,
            'driver_accepted_at' => now(),
            'dispatch_version' => 1,
            'status' => 'in_progress',
            'payment_status' => 'unpaid',
            'payment_method' => 'cash_on_arrival',
        ]);

        $driverTripService = app(DriverTripService::class);
        // Actual duration: 15 minutes. Scheduled was 10 minutes.
        // Overtime = 5 minutes.
        // 5 / 2 = ceil(2.5) = 3 intervals of 2 minutes -> 3 * $1.00 = $3.00 (300 cents)
        $driverTripService->act($booking->id, $driver, [
            'action' => 'complete',
            'dispatch_version' => $booking->dispatch_version,
            'actual_duration_minutes' => 15,
        ]);

        $fresh = $booking->fresh();
        $this->assertEquals('completed', $fresh->status);
        $this->assertEquals(15, $fresh->actual_duration_minutes);
        $this->assertEquals(5, $fresh->overtime_minutes);
        $this->assertEquals(300, $fresh->overtime_cents);
        $this->assertEquals(1300, $fresh->total_cents); // $10 base + $3 overtime = $13
        $this->assertEquals(260, $fresh->commission_cents); // 20% of $13 = $2.60
        $this->assertEquals(1040, $fresh->driver_payout_cents); // 80% of $13 = $10.40

        // Staff can reopen completed trips. Completing the same trip again must
        // replace its overtime calculation rather than charging it twice.
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        app(DispatchService::class)->update($booking->id, $admin, ['status' => 'in_progress']);
        $driverTripService->act($booking->id, $driver, [
            'action' => 'complete', 'dispatch_version' => $fresh->dispatch_version,
            'actual_duration_minutes' => 15,
        ]);
        $fresh = $booking->fresh();
        $this->assertSame(1300, $fresh->total_cents);
        $this->assertSame(300, $fresh->overtime_cents);
        $this->assertSame(260, $fresh->commission_cents);

        // A corrected duration must also remove an earlier overtime charge.
        app(DispatchService::class)->update($booking->id, $admin, ['status' => 'in_progress']);
        $driverTripService->act($booking->id, $driver, [
            'action' => 'complete', 'dispatch_version' => $fresh->dispatch_version,
            'actual_duration_minutes' => 10,
        ]);
        $fresh = $booking->fresh();
        $this->assertSame(1000, $fresh->total_cents);
        $this->assertSame(0, $fresh->overtime_minutes);
        $this->assertSame(0, $fresh->overtime_cents);
        $this->assertSame(200, $fresh->commission_cents);

        // Zero commission is intentional and must not fall back to 20 percent.
        app(DispatchService::class)->update($booking->id, $admin, ['status' => 'in_progress', 'commission_rate' => 0]);
        $driverTripService->act($booking->id, $driver, [
            'action' => 'complete', 'dispatch_version' => $fresh->dispatch_version,
            'actual_duration_minutes' => 15,
        ]);
        $fresh = $booking->fresh();
        $this->assertSame(1300, $fresh->total_cents);
        $this->assertSame(0, $fresh->commission_cents);
        $this->assertSame(1300, $fresh->driver_payout_cents);
    }

    public function test_admin_can_save_new_commission_and_currency_settings()
    {
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);

        $response = $this->actingAs($admin)->post(route('admin.settings.save'), [
            'brand_name' => 'TAXIKH',
            'accent_color' => '#ffd801',
            'default_language' => 'en',
            'min_notice_hours' => 2,
            'home_sections' => 'hero,search,routes,faq,reviews',
            'routes_columns' => 3,
            'routes_rows' => 3,
            'routes_layout' => 'list',
            'routes_list_columns' => 2,
            'default_driver_commission' => 25,
            'riel_exchange_rate' => 4150,
            'currency_mode' => 'dual',
            'routes_sort' => 'recommended',
        ]);

        $response->assertRedirect(route('admin.settings'));
        $this->assertEquals('2', Setting::get('routes_list_columns'));
        $this->assertEquals('25', Setting::get('default_driver_commission'));
        $this->assertEquals('4150', Setting::get('riel_exchange_rate'));
        $this->assertEquals('dual', Setting::get('currency_mode'));
    }

    public function test_zero_commission_is_preserved_in_admin_and_driver_trip_views(): void
    {
        $driver = User::factory()->create(['role' => 'driver', 'active' => true]);
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        $route = TravelRoute::first();
        $booking = app(\App\Services\BookingService::class)->create([
            'request_key' => (string) \Illuminate\Support\Str::uuid(),
            'route_id' => $route->id, 'vehicle_id' => $route->vehicles->first()->id,
            'locale' => 'en', 'customer_name' => 'Zero commission customer',
            'phone' => '+85512345678', 'people' => 1, 'pickup' => 'Hotel pickup', 'dropoff' => 'Airport dropoff',
            'departure_date' => now('Asia/Phnom_Penh')->addDays(3)->format('Y-m-d'), 'departure_time' => '10:00',
        ]);
        app(DispatchService::class)->update($booking->id, $admin, [
            'status' => 'assigned', 'driver_id' => $driver->id, 'commission_rate' => 0,
        ]);

        $this->actingAs($admin)->get('/admin/bookings/'.$booking->id)->assertOk()
            ->assertSee(__('taxikh.company_commission').' (0%)')->assertSee('name="commission_rate" value="0"', false);
        $this->actingAs($driver)->get('/driver/bookings/'.$booking->id)->assertOk()
            ->assertSee(__('taxikh.company_commission').' (0%)')->assertSee('0%');
    }
}
