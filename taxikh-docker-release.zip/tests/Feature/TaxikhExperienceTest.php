<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\ContentItem;
use App\Models\Extra;
use App\Models\Setting;
use App\Models\TravelRoute;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Tests\TestCase;

class TaxikhExperienceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
        Http::preventStrayRequests();
    }

    private function admin(): User
    {
        return User::factory()->create(['role' => 'admin', 'active' => true, 'password' => 'Safe-test-password-123']);
    }

    private function settings(array $extra = []): array
    {
        return [...['brand_name' => 'TAXIKH', 'accent_color' => '#ffd801', 'default_language' => 'en', 'min_notice_hours' => 2, 'home_sections' => 'hero,search,routes,faq,reviews'], ...$extra];
    }

    private function routeData(TravelRoute $trip, array $extra = []): array
    {
        return [...$trip->only(['title', 'slug', 'type', 'origin', 'destination', 'description', 'included', 'additional_info', 'seo_description', 'duration_minutes', 'distance_km', 'active', 'featured', 'sort_order']),
            'fares' => $trip->vehicles->mapWithKeys(fn ($v) => [$v->id => number_format($v->pivot->price_cents / 100, 2, '.', '')])->all(), ...$extra];
    }

    private function payload(TravelRoute $trip, array $extra = []): array
    {
        return [...['request_key' => (string) Str::uuid(), 'route_id' => $trip->id, 'vehicle_id' => $trip->vehicles->first()->id, 'locale' => 'en', 'customer_name' => 'TAXIKH Guest', 'phone' => '+85512345678', 'people' => 2, 'pickup' => 'Phnom Penh Hotel', 'dropoff' => 'Siem Reap Hotel', 'departure_date' => now()->addDays(3)->format('Y-m-d'), 'departure_time' => '09:30'], ...$extra];
    }

    public function test_configured_cities_preserve_dates_into_guest_booking(): void
    {
        $trip = TravelRoute::first();
        $data = ['from' => $trip->text('origin', 'en'), 'to' => $trip->text('destination', 'en'), 'departure_date' => now()->addDays(3)->format('Y-m-d'), 'departure_time' => '13:45'];
        $r = $this->get('/en/booking?'.http_build_query($data));
        $r->assertRedirect();
        parse_str(parse_url($r->headers->get('Location'), PHP_URL_QUERY), $query);
        $this->assertEquals($data, $query);
        $this->assertSame('/en/routes/'.$trip->slug, parse_url($r->headers->get('Location'), PHP_URL_PATH));
        $page = $this->get($r->headers->get('Location'))->assertOk()->assertSee('data-booking-wizard', false)->assertSee('value="13:45"', false)->assertSee('name="pickup"', false)->assertSee('data-locate', false);
        $this->get('/en/booking?from=NotConfigured&to=Siem+Reap')->assertSessionHasErrors('to');
        $this->get('/en')->assertOk()->assertSee('data-city-select', false)->assertDontSee('data-locate', false)->assertDontSee('href="'.url('/staff/login').'"', false);
        $this->get('/en/routes')->assertOk()->assertDontSee('data-location-field', false)->assertDontSee('data-locate', false);
    }

    public function test_category_filters_sorting_layout_and_pagination_use_active_routes(): void
    {
        Setting::put('routes_columns', '2');
        Setting::put('routes_rows', '1');
        foreach (['/en', '/en/routes'] as $path) {
            $r = $this->get($path.'?type=airport&layout=list')->assertOk()->assertSee('layout-list', false);
            $this->assertTrue($r->viewData('routes')->getCollection()->every(fn ($t) => $t->type === 'airport'));
            $page = $this->get($path.'?sort=price_desc')->assertOk()->viewData('routes');
            $this->assertSame(2, $page->perPage());
            $this->assertCount(2, $page);
            $this->assertNotNull($page->nextPageUrl());
            $prices = $page->getCollection()->map(fn ($t) => $t->startingPrice())->all();
            $sorted = $prices;
            rsort($sorted);
            $this->assertSame($sorted, $prices);
            $other = $this->get($path.'?sort=price_desc&page=2')->assertOk()->viewData('routes');
            $this->assertEmpty(array_intersect($page->pluck('id')->all(), $other->pluck('id')->all()));
        }
        $this->get('/en/routes?sort[]=bad')->assertSessionHasErrors('sort');
    }

    public function test_admin_route_embed_extracts_only_an_official_url_and_renders_it(): void
    {
        $this->actingAs($this->admin());
        $trip = TravelRoute::first();
        $url = 'https://www.google.com/maps/embed?pb=!1m18!test';
        $data = $this->routeData($trip, ['map_embed' => '<iframe src="'.$url.'" onload="alert(1)"></iframe><script>alert(2)</script>']);
        $this->put('/admin/manage/routes/'.$trip->id, $data)->assertSessionHasNoErrors();
        $this->assertSame($url, $trip->fresh()->map_embed_url);
        $this->get('/en/routes/'.$trip->slug)->assertOk()->assertSee($url)->assertDontSee('alert(1)', false)->assertDontSee('alert(2)', false);
        foreach (['https://www.google.com.evil.test/maps/embed?pb=x', 'javascript:alert(1)', 'https://www.google.com/maps/embed/v1/directions?key=x', '<iframe srcdoc="<script>alert(1)</script>"></iframe>'] as $bad) {
            $this->put('/admin/manage/routes/'.$trip->id, [...$data, 'map_embed' => $bad])->assertSessionHasErrors('map_embed');
            $this->assertSame($url, $trip->fresh()->map_embed_url);
        }
        $this->put('/admin/manage/routes/'.$trip->id, [...$data, 'map_embed' => ''])->assertSessionHasNoErrors();
        $this->assertNull($trip->fresh()->map_embed_url);
    }

    public function test_route_specific_image_extras_are_enforced_by_server_pricing(): void
    {
        Storage::fake('public');
        $this->actingAs($this->admin());
        $trip = TravelRoute::first();
        $other = TravelRoute::where('id', '!=', $trip->id)->first();
        $this->post('/admin/manage/extras', ['title' => ['en' => 'Scenic stop'], 'description' => ['en' => 'An optional stop'], 'destination' => ['en' => 'Rest area'], 'price' => '7.50', 'active' => 1, 'travel_route_id' => $trip->id,
            'image' => UploadedFile::fake()->createWithContent('stop.png', file_get_contents(public_path('demo/taxi-hero-v2.png')))])->assertSessionHasNoErrors();
        $extra = Extra::where('title->en', 'Scenic stop')->firstOrFail();
        Storage::disk('public')->assertExists($extra->image_path);
        $this->get('/en/routes/'.$trip->slug)->assertOk()->assertSee('Scenic stop')->assertSee('Rest area');
        $this->get('/en/routes/'.$other->slug)->assertOk()->assertDontSee('Scenic stop');
        $this->postJson('/api/v1/quote', ['route_id' => $other->id, 'vehicle_id' => $other->vehicles->first()->id, 'people' => 2, 'extras' => [$extra->id]])->assertUnprocessable()->assertJsonValidationErrors('extras');
        $this->postJson('/api/v1/bookings', $this->payload($trip, ['extras' => [$extra->id], 'total_cents' => 1]))->assertCreated();
        $booking = Booking::first();
        $this->assertSame($trip->vehicles->first()->pivot->price_cents + 750, $booking->total_cents);
        $this->assertSame('Rest area', $booking->price_snapshot['extras'][0]['destination']['en']);
    }

    public function test_home_sections_and_review_embeds_save_without_a_google_api_key(): void
    {
        $this->actingAs($this->admin());
        $google = 'https://www.google.com/maps/embed?pb=place-map';
        $widget = '<div id="TA_selfserveprop123"></div><script async src="https://www.jscache.com/wejs?wtype=selfserveprop&uniq=123&locationId=456&lang=en_US"></script>';
        $this->post('/admin/settings', $this->settings(['sections_present' => 1, 'sections' => ['reviews', 'search', 'routes'], 'routes_columns' => 4, 'routes_rows' => 3, 'routes_layout' => 'list', 'google_embed' => '<iframe src="'.$google.'"></iframe>', 'tripadvisor_embed' => $widget]))->assertSessionHasNoErrors();
        $this->assertSame('reviews,search,routes', Setting::get('home_sections'));
        $this->assertSame('4', Setting::get('routes_columns'));
        $this->get('/en')->assertOk()->assertSee('data-review-embeds', false)->assertSee('srcdoc=', false)->assertSee('sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"', false)->assertDontSee('hero-frame', false)->assertDontSee('data-google-reviews', false);
        $this->get('/admin/settings')->assertOk()->assertSee('jscache.com');
        $this->post('/admin/settings', $this->settings(['google_embed' => '<iframe src="https://attacker.test"></iframe>']))->assertSessionHasErrors('google_embed');
        $this->post('/admin/settings', $this->settings(['sections_present' => 1, 'sections' => []]))->assertSessionHasNoErrors();
        $this->assertSame('', Setting::get('home_sections'));
    }

    public function test_cms_order_visibility_and_guarded_permanent_deletion(): void
    {
        $this->actingAs($this->admin());
        $items = ContentItem::where('kind', 'menu')->take(2)->get();
        $this->post('/admin/manage/content/arrange', ['items' => [['id' => $items[0]->id, 'sort_order' => 9, 'active' => 0], ['id' => $items[1]->id, 'sort_order' => 1, 'active' => 1]]])->assertSessionHasNoErrors();
        $this->assertFalse($items[0]->fresh()->active);
        $this->assertSame(1, $items[1]->fresh()->sort_order);
        $this->delete('/admin/manage/content/'.$items[0]->id, ['current_password' => 'wrong', 'confirm' => 'DELETE'])->assertSessionHasErrors('current_password');
        $this->assertModelExists($items[0]);
        $this->delete('/admin/manage/content/'.$items[0]->id, ['current_password' => 'Safe-test-password-123', 'confirm' => 'DELETE'])->assertSessionHasNoErrors();
        $this->assertModelMissing($items[0]);
        $trip = TravelRoute::first();
        $this->postJson('/api/v1/bookings', $this->payload($trip))->assertCreated();
        $this->delete('/admin/manage/routes/'.$trip->id, ['current_password' => 'Safe-test-password-123', 'confirm' => 'DELETE'])->assertSessionHasErrors('delete');
        $this->assertModelExists($trip);
        $this->actingAs(User::factory()->create(['role' => 'driver', 'active' => true]))->delete('/admin/manage/extras/'.Extra::first()->id, [])->assertForbidden();
    }

    public function test_all_new_admin_and_booking_views_render_with_translated_labels(): void
    {
        $admin = $this->admin();
        $this->actingAs($admin);
        foreach (['en', 'km', 'zh'] as $locale) {
            $this->withSession(['locale' => $locale]);
            foreach (['/admin/settings', '/admin/manage/routes', '/admin/manage/routes/'.TravelRoute::first()->id.'/edit', '/admin/manage/extras/create', '/admin/manage/vehicles/create', '/staff/login'] as $path) {
                $page = $this->get($path)->assertOk();
                $this->assertDoesNotMatchRegularExpression('/\btaxikh\.(?!com\b)[a-z_]+/', strip_tags($page->getContent()));
            }
            $this->get('/'.$locale.'/routes/'.TravelRoute::first()->slug)->assertOk()->assertSee('data-booking-wizard', false)->assertSee(__('taxikh.choose_vehicle', [], $locale));
        }
        $this->get('/staff/login')->assertOk()->assertDontSee('<img', false)->assertDontSee('login-art', false);
    }

    public function test_seo_is_noindex_locally_then_outputs_canonicals_and_public_sitemap(): void
    {
        $this->get('/robots.txt')->assertOk()->assertSee('Disallow: /');
        $this->get('/en')->assertOk()->assertSee('content="noindex, nofollow"', false);
        Setting::put('seo_indexable', '1');
        Setting::put('seo_site_url', 'https://taxikh.com');
        $this->get('/en')->assertOk()->assertSee('href="https://taxikh.com/en"',false)->assertSee('hreflang="zh-CN"',false)->assertSee('application/ld+json',false);
        $this->get('/sitemap.xml')->assertOk()->assertSee('https://taxikh.com/km/routes/'.TravelRoute::first()->slug)->assertDontSee('/admin');
        $this->get('/robots.txt')->assertSee('Sitemap: https://taxikh.com/sitemap.xml');
    }
}
