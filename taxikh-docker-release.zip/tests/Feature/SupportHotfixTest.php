<?php

namespace Tests\Feature;

use App\Models\Inquiry;
use App\Models\Setting;
use App\Models\TravelRoute;
use App\Models\User;
use App\Services\BookingService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Tests\TestCase;

class SupportHotfixTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
        Http::preventStrayRequests();
    }

    private function settings(array $values = []): array
    {
        return array_replace(['brand_name' => 'Mekong Ride', 'accent_color' => '#ffd801',
            'default_language' => 'en', 'min_notice_hours' => 2, 'home_sections' => 'routes,faq,reviews',
            'booking_enabled' => 1, 'telegram_enabled' => 1, 'telegram_group_id' => '-1001234567'], $values);
    }

    public function test_notification_poll_does_not_replace_the_settings_page_before_a_save(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'admin', 'active' => true]));
        $this->get('/admin/settings')->assertOk();
        $this->getJson('/staff/alerts')->assertOk()->assertJsonStructure(['unread', 'items']);
        $this->assertSame(url('/admin/settings'), session()->previousUrl());
        $this->post('/admin/settings', $this->settings(['telegram_bot_token' => '123456:demo-regression-token']))
            ->assertRedirect('/admin/settings')->assertSessionHasNoErrors();
        $this->assertSame('123456:demo-regression-token', Crypt::decryptString(Setting::get('telegram_bot_token')));
        $this->getJson('/staff/alerts')->assertOk();
        $this->post('/admin/settings', $this->settings(['telegram_bot_token' => 'invalid-token']))
            ->assertRedirect('/admin/settings')->assertSessionHasErrors('telegram_bot_token');
        Http::assertNothingSent();
    }

    public function test_short_contact_messages_and_local_phone_digits_are_accepted(): void
    {
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        $dispatcher = User::factory()->create(['role' => 'dispatcher', 'active' => true]);
        $driver = User::factory()->create(['role' => 'driver', 'active' => true]);
        foreach (['en' => ['Li', '+855 12 345 678', 'Hello'], 'km' => ['សុខ', '០១២ ៣៤៥ ៦៧៨', 'សួស្តី'], 'zh' => ['王', '＋８５５ １２ ３４５ ６７８', '你好']] as $locale => [$name, $phone, $message]) {
            $this->postJson('/'.$locale.'/inquiry', ['type' => 'contact', 'name' => $name, 'phone' => $phone,
                'email' => '', 'message' => $message, 'website' => ''])->assertOk()->assertJsonStructure(['message']);
            $this->assertDatabaseHas('inquiries', ['name' => $name, 'message' => $message]);
        }
        $this->assertSame(3, Inquiry::count());
        $this->assertSame(3, $admin->alerts()->count());
        $this->assertSame(3, $dispatcher->alerts()->count());
        $this->assertSame(0, $driver->alerts()->count());
        $this->assertDatabaseHas('inquiries', ['name' => 'សុខ', 'phone' => '012 345 678']);
        $this->assertDatabaseHas('inquiries', ['name' => '王', 'phone' => '+855 12 345 678']);
    }

    public function test_admin_and_driver_saves_return_to_the_booking_after_polling(): void
    {
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        $driver = User::factory()->create(['role' => 'driver', 'active' => true]);
        $route = TravelRoute::first();
        $booking = app(BookingService::class)->create(['request_key' => (string) Str::uuid(),
            'route_id' => $route->id, 'vehicle_id' => $route->vehicles->first()->id, 'locale' => 'en',
            'customer_name' => 'Regression passenger', 'phone' => '+85512345678', 'people' => 2,
            'pickup' => 'Phnom Penh hotel', 'dropoff' => 'Siem Reap hotel',
            'departure_date' => now('Asia/Phnom_Penh')->addDays(3)->format('Y-m-d'), 'departure_time' => '10:00']);
        $this->actingAs($admin)->get('/admin/bookings/'.$booking->id)->assertOk();
        $this->getJson('/staff/alerts')->assertOk();
        $this->patch('/admin/bookings/'.$booking->id, ['status' => 'confirmed'])->assertRedirect('/admin/bookings/'.$booking->id);
        $this->patch('/admin/bookings/'.$booking->id, ['status' => 'assigned', 'driver_id' => $driver->id])->assertRedirect('/admin/bookings/'.$booking->id);
        $this->actingAs($driver)->get('/driver/bookings/'.$booking->id)->assertOk();
        $this->getJson('/staff/alerts')->assertJsonPath('unread', 1)->assertJsonPath('items.0.url', url('/driver/bookings/'.$booking->id));
        $this->patch('/driver/bookings/'.$booking->id, ['dispatch_version' => $booking->fresh()->dispatch_version, 'status' => 'completed'])->assertRedirect('/driver/bookings/'.$booking->id)->assertSessionHasErrors('status');
        $this->patch('/driver/bookings/'.$booking->id, ['dispatch_version' => $booking->fresh()->dispatch_version, 'status' => 'on_the_way'])->assertRedirect('/driver/bookings/'.$booking->id)->assertSessionHasNoErrors();
        $this->assertSame('on_the_way', $booking->fresh()->status);
        $this->postJson('/staff/alerts/read')->assertOk();
        $this->getJson('/staff/alerts')->assertJsonPath('unread', 0)->assertJsonPath('items.0.read', true);
    }

    public function test_opening_the_alert_endpoint_in_a_browser_returns_to_the_correct_dashboard(): void
    {
        foreach (['admin', 'dispatcher', 'driver'] as $role) {
            $this->actingAs(User::factory()->create(['role' => $role, 'active' => true]));
            $this->get('/staff/alerts')->assertRedirect($role === 'driver' ? '/driver' : '/admin');
        }
    }

    public function test_contact_validation_identifies_the_field_in_each_language(): void
    {
        foreach (['en', 'km', 'zh'] as $locale) {
            $response = $this->postJson('/'.$locale.'/inquiry', ['type' => 'contact', 'name' => 'Test',
                'phone' => '123', 'email' => 'bad-email', 'message' => ''])->assertUnprocessable()
                ->assertJsonValidationErrors(['phone', 'email', 'message']);
            $this->assertStringContainsString('7', $response->json('errors.phone.0'));
            $this->assertStringContainsString(__('ui.message'), $response->json('errors.message.0'));
        }
        $this->assertDatabaseCount('inquiries', 0);
    }

    public function test_contact_and_partner_forms_work_without_javascript_and_return_errors_to_the_form(): void
    {
        $data = ['type' => 'contact', 'name' => 'Test person', 'phone' => '+85512345678', 'message' => 'Hello'];
        $this->get('/en/contact')->assertOk()->assertSee('minlength="1"', false)->assertSee('contact-phone-help');
        $this->post('/en/inquiry', $data)->assertRedirect('/en/contact')->assertSessionHas('success');
        $this->post('/en/inquiry', [...$data, 'type' => 'agency'])->assertRedirect('/en/partners');
        $this->withSession(['_previous' => ['url' => url('/staff/alerts')]])->post('/en/inquiry', [...$data, 'phone' => 'bad'])
            ->assertRedirect('/en/contact')->assertSessionHasErrors('phone')->assertSessionHasInput('message', 'Hello');
        $this->assertDatabaseCount('inquiries', 2);
    }

    public function test_contact_honeypot_and_request_limits_remain_enforced(): void
    {
        $data = ['type' => 'contact', 'name' => 'Test', 'phone' => '+85512345678', 'message' => 'Hello', 'website' => 'spam'];
        $this->postJson('/en/inquiry', $data)->assertUnprocessable()->assertJsonValidationErrors('website');
        for ($attempt = 0; $attempt < 2; $attempt++) {
            $this->postJson('/en/inquiry', [...$data, 'website' => ''])->assertOk();
        }
        $this->postJson('/en/inquiry', [...$data, 'website' => ''])->assertTooManyRequests()->assertHeader('Retry-After');
        $this->assertDatabaseCount('inquiries', 2);
    }

    public function test_contact_and_staff_alerts_are_saved_together(): void
    {
        User::factory()->create(['role' => 'admin', 'active' => true]);
        DB::unprepared("CREATE TRIGGER reject_inquiry_alert BEFORE INSERT ON alerts WHEN NEW.kind = 'new_inquiry' BEGIN SELECT RAISE(ABORT, 'simulated alert failure'); END");
        try {
            $this->postJson('/en/inquiry', ['type' => 'contact', 'name' => 'Test', 'phone' => '+85512345678', 'message' => 'Hello'])->assertStatus(500);
            $this->assertDatabaseCount('inquiries', 0);
            $this->assertDatabaseCount('alerts', 0);
        } finally {
            DB::unprepared('DROP TRIGGER reject_inquiry_alert');
        }
    }

    public function test_contact_csrf_protection_accepts_a_real_form_token_and_rejects_missing_or_stale_tokens(): void
    {
        $this->app->instance('env', 'local');
        $this->get('/en/contact')->assertOk();
        $token = session()->token();
        $data = ['type' => 'contact', 'name' => 'Test', 'phone' => '+85512345678', 'message' => 'Hello'];
        $headers = ['Accept' => 'application/json', 'X-Requested-With' => 'XMLHttpRequest'];
        $this->post('/en/inquiry', $data, $headers)->assertStatus(419);
        $this->post('/en/inquiry', $data, [...$headers, 'X-CSRF-TOKEN' => $token])->assertOk()->assertJsonStructure(['message']);
        $this->post('/en/inquiry', $data, [...$headers, 'X-CSRF-TOKEN' => 'stale-token'])->assertStatus(419);
        $this->assertDatabaseCount('inquiries', 1);
    }

    public function test_diagnostic_log_entry_creates_a_file_when_no_error_log_exists(): void
    {
        $path = sys_get_temp_dir().'/mekong-log-check-'.Str::uuid().'.log';
        config(['logging.default' => 'hotfix_test', 'logging.channels.hotfix_test' => ['driver' => 'single', 'path' => $path, 'level' => 'warning']]);
        try {
            $this->assertFileDoesNotExist($path);
            $this->assertSame(0, Artisan::call('ride:diagnose', ['--write-log' => true]));
            $this->assertFileExists($path);
            $this->assertStringContainsString('Mekong Ride diagnostic log check.', file_get_contents($path));
            $this->assertStringContainsString($path, Artisan::output());
        } finally {
            Log::forgetChannel('hotfix_test');
            if (is_file($path)) {
                unlink($path);
            }
        }
    }

    public function test_flag_menus_preserve_the_public_page_and_work_on_staff_pages(): void
    {
        foreach (['en', 'km', 'zh'] as $locale) {
            $response = $this->get('/'.$locale.'/routes?from=Phnom%20Penh')->assertOk()->assertSee('data-language-menu', false);
            foreach (['gb', 'kh', 'cn'] as $flag) {
                $response->assertSee('assets/flags/'.$flag.'.svg', false);
            }
            $response->assertSee('/km/routes?from=Phnom%20Penh', false)->assertDontSee('ui.language');
        }
        foreach (['admin', 'driver'] as $role) {
            $this->actingAs(User::factory()->create(['role' => $role, 'active' => true]))->get('/'.$role)->assertOk()
                ->assertSee('data-language-menu', false)->assertSee('/staff/language/km', false)->assertSee('type="button" data-read-alerts', false);
        }
    }

    public function test_diagnostics_reports_log_paths_without_exposing_credentials_or_sending_messages(): void
    {
        Setting::put('telegram_enabled', '1');
        Setting::put('telegram_bot_token', Crypt::encryptString('123456:private-diagnostic-token'));
        Setting::put('telegram_group_id', '-1009999999');
        Log::shouldReceive('warning')->once()->with('Mekong Ride diagnostic log check.', ['event' => 'manual_diagnostic', 'checks_passed' => true]);
        $this->assertSame(0, Artisan::call('ride:diagnose', ['--write-log' => true]));
        $output = Artisan::output();
        $this->assertStringContainsString(storage_path('logs'), $output);
        $this->assertStringContainsString('[OK] Telegram token saved and decryptable', $output);
        $this->assertStringNotContainsString('private-diagnostic-token', $output);
        $this->assertStringNotContainsString('-1009999999', $output);
        Http::assertNothingSent();
    }
}
