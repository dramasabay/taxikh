<?php

namespace Tests\Feature;

use App\Http\Middleware\TrustedProxies;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Tests\TestCase;

class SecurityBoundaryTest extends TestCase
{
    use RefreshDatabase;

    public function test_rotating_account_names_does_not_bypass_login_ip_limit(): void
    {
        for ($i = 0; $i < 20; $i++) {
            $this->postJson('/staff/login', ['email' => "unknown{$i}@example.com", 'password' => 'incorrect'])
                ->assertUnprocessable();
        }
        $this->postJson('/staff/login', ['email' => 'another@example.com', 'password' => 'incorrect'])
            ->assertTooManyRequests();
    }

    public function test_login_account_limit_applies_across_different_ips(): void
    {
        for ($i = 1; $i <= 5; $i++) {
            $this->withServerVariables(['REMOTE_ADDR' => '198.51.100.'.$i])
                ->postJson('/staff/login', ['email' => 'staff@example.com', 'password' => 'incorrect'])
                ->assertUnprocessable();
        }
        $this->withServerVariables(['REMOTE_ADDR' => '198.51.100.6'])
            ->postJson('/staff/login', ['email' => 'STAFF@example.com', 'password' => 'incorrect'])
            ->assertTooManyRequests();
    }

    public function test_malformed_login_email_is_validation_error_not_server_error(): void
    {
        $this->postJson('/staff/login', ['email' => ['invalid'], 'password' => 'incorrect'])
            ->assertUnprocessable()->assertJsonValidationErrors('email');
    }

    public function test_only_configured_proxy_can_supply_client_ip_and_https_but_never_host(): void
    {
        config(['security.trusted_proxies' => ['172.29.92.2']]);
        $check = function (string $peer, string $client, bool $secure): void {
            $request = Request::create('http://taxikh.com/staff/login', server: [
                'REMOTE_ADDR' => $peer,
                'HTTP_X_FORWARDED_FOR' => '198.51.100.10',
                'HTTP_X_FORWARDED_PROTO' => 'https',
                'HTTP_X_FORWARDED_HOST' => 'attacker.example',
            ]);
            (new TrustedProxies)->handle($request, function (Request $request) use ($client, $secure) {
                $this->assertSame($client, $request->ip());
                $this->assertSame($secure, $request->isSecure());
                $this->assertSame('taxikh.com', $request->getHost());

                return new Response;
            });
        };
        try {
            $check('203.0.113.10', '203.0.113.10', false);
            $check('172.29.92.2', '198.51.100.10', true);
        } finally {
            Request::setTrustedProxies([], -1);
        }
    }

    public function test_production_rejects_unconfigured_host_headers(): void
    {
        $this->app['env'] = 'production';
        config(['security.allowed_hosts' => ['taxikh.com']]);
        try {
            $this->get('http://attacker.example/staff/login')->assertStatus(400);
            $this->get('http://taxikh.com/staff/login')->assertOk();
        } finally {
            Request::setTrustedHosts([]);
        }
    }

    public function test_sensitive_pages_are_not_cacheable_and_csp_blocks_inline_scripts(): void
    {
        $response = $this->get('/staff/login')->assertOk()
            ->assertHeader('X-Content-Type-Options', 'nosniff')
            ->assertHeader('Referrer-Policy', 'no-referrer');
        $this->assertStringContainsString('no-store', $response->headers->get('Cache-Control'));
        $csp = $response->headers->get('Content-Security-Policy');
        $this->assertStringContainsString("object-src 'none'", $csp);
        $this->assertStringContainsString("form-action 'self'", $csp);
        preg_match('/(?:^|; )script-src ([^;]+)/', $csp, $script);
        $this->assertStringNotContainsString("'unsafe-inline'", $script[1]);
        $this->assertStringNotContainsString("'unsafe-eval'", $script[1]);
    }
}
