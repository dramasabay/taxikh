<?php

namespace Tests\Feature;

use App\Models\Alert;
use App\Models\Booking;
use App\Models\ContentItem;
use App\Models\Extra;
use App\Models\Setting;
use App\Models\TelegramDelivery;
use App\Models\TravelRoute;
use App\Models\User;
use App\Models\Vehicle;
use App\Services\BookingService;
use App\Services\TelegramService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Tests\TestCase;

class BookingPlatformTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
        Http::preventStrayRequests();
    }

    private function staff(string $role = 'admin'): User
    {
        return User::factory()->create(['role' => $role, 'active' => true]);
    }

    private function payload(array $override = []): array
    {
        $route = TravelRoute::first();
        $vehicle = $route->vehicles()->first();

        return array_replace(['request_key' => (string) Str::uuid(), 'route_id' => $route->id, 'vehicle_id' => $vehicle->id, 'locale' => 'en', 'customer_name' => 'Test Passenger', 'phone' => '+855 12 345 678', 'people' => 2, 'pickup' => 'Phnom Penh riverside hotel', 'dropoff' => 'Siem Reap city hotel', 'departure_date' => now('Asia/Phnom_Penh')->addDays(3)->format('Y-m-d'), 'departure_time' => '09:30', 'extras' => [], 'notes' => 'One suitcase'], $override);
    }

    private function booking(array $override = []): Booking
    {
        return app(BookingService::class)->create($this->payload($override));
    }

    public function test_all_public_pages_render_in_three_languages(): void
    {
        foreach (['en', 'km', 'zh'] as $l) {
            foreach (['', '/routes', '/routes/'.TravelRoute::first()->slug, '/fleet', '/faq', '/contact', '/partners', '/guides', '/guides/'.ContentItem::where('kind', 'guide')->first()->slug, '/page/about', '/page/terms', '/page/privacy'] as $path) {
                $this->get('/'.$l.$path)->assertOk();
            }
        }
        $this->get('/en/routes?from=Phnom&to=Siem')->assertOk()->assertSee('Phnom Penh');
        $this->get('/en/routes?from[]=bad')->assertSessionHasErrors('from');
    }

    public function test_guest_booking_uses_server_price_and_notifies_staff_without_login(): void
    {
        $admin = $this->staff();
        $dispatcher = $this->staff('dispatcher');
        $driver = $this->staff('driver');
        $payload = $this->payload(['extras' => [Extra::first()->id]]);
        $response = $this->postJson('/api/v1/bookings', [...$payload, 'total_cents' => 1, 'payment_status' => 'paid', 'driver_id' => $driver->id, 'status' => 'completed']);
        $response->assertCreated();
        $b = Booking::first();
        $expected = (int) TravelRoute::first()->vehicles()->first()->pivot->price_cents + Extra::first()->price_cents;
        $this->assertSame($expected, $b->total_cents);
        $this->assertSame('pending', $b->status);
        $this->assertSame('unpaid', $b->payment_status);
        $this->assertNull($b->driver_id);
        $this->assertSame('cash_on_arrival', $b->payment_method);
        $this->assertSame(2, Alert::where('booking_id', $b->id)->count());
        $this->assertSame(0, $driver->alerts()->count());
        $this->assertDatabaseHas('telegram_deliveries', ['booking_id' => $b->id, 'target' => 'group']);
        $this->get($response->json('confirmation_url'))->assertOk()->assertSee($payload['customer_name'])->assertHeader('Referrer-Policy', 'no-referrer');
        $this->assertNotSame($b->public_token, DB::table('bookings')->value('public_token'));
        $this->assertSame('02:30', $b->departure_at->format('H:i'));
    }

    public function test_duplicate_retries_are_idempotent_and_changed_payload_conflicts(): void
    {
        $payload = $this->payload();
        $a = $this->postJson('/api/v1/bookings', $payload)->assertCreated();
        $b = $this->postJson('/api/v1/bookings', $payload)->assertCreated();
        $this->assertSame($a->json('confirmation_url'), $b->json('confirmation_url'));
        $this->assertSame(1, Booking::count());
        $this->assertSame(1, TelegramDelivery::count());
        $this->postJson('/api/v1/bookings', [...$payload, 'people' => 3])->assertConflict();
    }

    public function test_invalid_capacity_archived_fares_extras_and_past_dates_are_rejected(): void
    {
        $payload = $this->payload();
        $this->postJson('/api/v1/bookings', [...$payload, 'people' => 60])->assertUnprocessable()->assertJsonValidationErrors('people');
        $this->postJson('/api/v1/bookings', [...$payload, 'departure_date' => now()->subDay()->format('Y-m-d')])->assertUnprocessable()->assertJsonValidationErrors('departure_date');
        $this->postJson('/api/v1/bookings', [...$payload, 'extras' => [99999]])->assertUnprocessable()->assertJsonValidationErrors('extras');
        Vehicle::find($payload['vehicle_id'])->update(['active' => false]);
        $this->postJson('/api/v1/bookings', $payload)->assertUnprocessable()->assertJsonValidationErrors('vehicle_id');
        $this->assertSame(0, Booking::count());
    }

    public function test_booking_pause_and_honeypot_and_malformed_names_are_enforced(): void
    {
        $payload = $this->payload();
        $this->postJson('/api/v1/bookings', [...$payload, 'website' => 'spam'])->assertUnprocessable();
        $this->postJson('/api/v1/bookings', [...$payload, 'customer_name' => ['bad']])->assertUnprocessable();
        $this->postJson('/api/v1/bookings', [...$payload, 'phone' => '-------'])->assertUnprocessable();
        Setting::put('booking_enabled', '0');
        $this->postJson('/api/v1/bookings', $payload)->assertUnprocessable()->assertJsonValidationErrors('booking');
    }

    public function test_public_catalog_exposes_no_customer_or_staff_secrets(): void
    {
        $this->staff();
        $this->booking();
        $response = $this->getJson('/api/v1/catalog')->assertOk();
        $this->assertCount(6, $response->json('data'));
        $response->assertDontSee('Test Passenger')->assertDontSee('password')->assertDontSee('public_token');
        $this->get('/en/reservation/MR-123456')->assertNotFound();
        $this->get('/en/reservation/'.Str::random(48))->assertNotFound();
        $this->getJson('/api/v1/bookings')->assertStatus(405);
        $this->get('/admin')->assertRedirect('/staff/login');
    }

    public function test_every_admin_dashboard_and_editor_renders(): void
    {
        $admin = $this->staff();
        $b = $this->booking();
        $this->actingAs($admin);
        foreach (['/admin', '/admin/bookings', '/admin/bookings/'.$b->id, '/admin/notifications', '/admin/inquiries', '/admin/reports', '/admin/settings', '/staff/profile'] as $path) {
            $this->get($path)->assertOk();
        }
        foreach (['routes' => TravelRoute::first()->id, 'vehicles' => Vehicle::first()->id, 'extras' => Extra::first()->id, 'content' => ContentItem::first()->id, 'users' => $admin->id] as $resource => $id) {
            $this->get('/admin/manage/'.$resource)->assertOk();
            $this->get('/admin/manage/'.$resource.'/create')->assertOk();
            $this->get('/admin/manage/'.$resource.'/'.$id.'/edit')->assertOk();
        }
        $this->get('/staff/language/km')->assertRedirect('/admin');
        $this->get('/admin')->assertOk()->assertSee('lang="km"', false);
    }

    public function test_dispatcher_and_driver_cannot_edit_admin_settings_and_drivers_are_isolated(): void
    {
        $admin = $this->staff();
        $d1 = $this->staff('driver');
        $d2 = $this->staff('driver');
        $b = $this->booking();
        $b->update(['driver_id' => $d1->id, 'status' => 'assigned']);
        $this->actingAs($this->staff('dispatcher'))->get('/admin/settings')->assertForbidden();
        $this->actingAs($d2)->get('/admin')->assertForbidden();
        $this->get('/driver/bookings/'.$b->id)->assertForbidden();
        $this->get('/driver/bookings')->assertOk()->assertDontSee($b->reference);
        $this->patch('/driver/bookings/'.$b->id, ['dispatch_version' => $b->fresh()->dispatch_version, 'status' => 'on_the_way'])->assertForbidden();
        $this->actingAs($d1)->get('/driver/bookings/'.$b->id)->assertOk()->assertDontSee('name="staff_notes"', false);
        $this->get('/driver')->assertOk();
        $this->getJson('/staff/alerts')->assertOk();
    }

    public function test_assignment_overlap_status_changes_and_cash_recording(): void
    {
        $admin = $this->staff();
        $driver = $this->staff('driver');
        $b = $this->booking();
        $other = $this->booking();
        $this->actingAs($admin)->patch('/admin/bookings/'.$b->id, ['status' => 'confirmed'])->assertSessionHasNoErrors();
        $this->patch('/admin/bookings/'.$b->id, ['status' => 'assigned', 'driver_id' => $driver->id])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('alerts', ['user_id' => $driver->id, 'booking_id' => $b->id]);
        $this->assertDatabaseHas('telegram_deliveries', ['booking_id' => $b->id, 'target' => 'driver', 'target_user_id' => $driver->id]);
        $other->update(['status' => 'confirmed']);
        $this->patch('/admin/bookings/'.$other->id, ['status' => 'assigned', 'driver_id' => $driver->id])->assertSessionHasErrors('driver_id');
        $this->actingAs($driver)->patch('/driver/bookings/'.$b->id, ['dispatch_version' => $b->fresh()->dispatch_version, 'status' => 'completed'])->assertSessionHasErrors('status');
        $this->patch('/driver/bookings/'.$b->id, ['dispatch_version' => $b->fresh()->dispatch_version, 'status' => 'on_the_way', 'cash_received' => 1])->assertSessionHasErrors('cash_received');
        $this->patch('/driver/bookings/'.$b->id, ['dispatch_version' => $b->fresh()->dispatch_version, 'status' => 'on_the_way'])->assertSessionHasNoErrors();
        $this->patch('/driver/bookings/'.$b->id, ['dispatch_version' => $b->fresh()->dispatch_version, 'status' => 'in_progress', 'cash_received' => 1])->assertSessionHasNoErrors();
        $this->patch('/driver/bookings/'.$b->id, ['dispatch_version' => $b->fresh()->dispatch_version, 'status' => 'completed'])->assertSessionHasNoErrors();
        $this->assertSame('completed', $b->fresh()->status);
        $this->assertSame('paid', $b->fresh()->payment_status);
        $this->assertNotNull($b->fresh()->paid_at);
    }

    public function test_active_route_fares_can_be_edited_and_booking_snapshot_stays_fixed(): void
    {
        $admin = $this->staff();
        $b = $this->booking();
        $route = TravelRoute::first();
        $before = $b->total_cents;
        $data = $route->only(['title', 'origin', 'destination', 'description', 'included', 'additional_info', 'seo_description', 'slug', 'type', 'distance_km', 'duration_minutes']);
        $data += ['active' => 1, 'featured' => 1, 'fares' => [$b->vehicle_id => '123.45']];
        $this->actingAs($admin)->put('/admin/manage/routes/'.$route->id, $data)->assertSessionHasNoErrors();
        $this->postJson('/api/v1/quote', ['route_id' => $route->id, 'vehicle_id' => $b->vehicle_id, 'people' => 1])->assertOk()->assertJsonPath('total_cents', 12345);
        $this->assertSame($before, $b->fresh()->total_cents);
    }

    public function test_content_and_safe_image_upload_are_editable_svg_is_rejected(): void
    {
        Storage::fake('public');
        $this->actingAs($this->staff());
        $data = ['kind' => 'slide', 'title' => ['en' => 'Your new headline', 'km' => 'ចំណងជើងថ្មី', 'zh' => '新的标题'], 'subtitle' => ['en' => 'Cambodia', 'km' => null, 'zh' => null], 'body' => ['en' => 'Welcome aboard', 'km' => null, 'zh' => null], 'active' => 1, 'link' => '/routes'];
        $this->post('/admin/manage/content', $data)->assertSessionHasNoErrors();
        $this->get('/en')->assertSee('Your new headline');
        $png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aVZkAAAAASUVORK5CYII=');
        $this->post('/admin/manage/content', [...$data, 'image' => UploadedFile::fake()->createWithContent('test.png', $png)])->assertSessionHasNoErrors();
        $image = ContentItem::latest('id')->first()->image_path;
        Storage::disk('public')->assertExists($image);
        $this->get('/media/'.$image)->assertOk()->assertHeader('X-Content-Type-Options', 'nosniff');
        $this->post('/admin/manage/content', [...$data, 'image' => UploadedFile::fake()->createWithContent('bad.svg', '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>')])->assertSessionHasErrors('image');
        $this->post('/admin/manage/content', [...$data, 'link' => 'javascript:alert(1)'])->assertSessionHasErrors('link');
    }

    public function test_last_admin_cannot_be_archived_and_inactive_staff_cannot_sign_in(): void
    {
        $admin = $this->staff();
        $this->actingAs($admin)->post('/admin/manage/users/'.$admin->id.'/archive')->assertSessionHasErrors('role');
        $this->assertTrue($admin->fresh()->active);
        $this->post('/staff/logout')->assertRedirect();
        $user = User::factory()->create(['active' => false, 'password' => 'Inactive-Password-123']);
        $this->post('/staff/login', ['email' => $user->email, 'password' => 'Inactive-Password-123'])->assertSessionHasErrors('email');
    }

    public function test_telegram_delivery_uses_safe_messages_and_does_not_resend_success(): void
    {
        $b = $this->booking();
        Setting::put('telegram_enabled', '1');
        Setting::put('telegram_bot_token', Crypt::encryptString('123456:demo-test-token'));
        Setting::put('telegram_group_id', '-1001234567');
        Http::fake(['api.telegram.org/*' => Http::response(['ok' => true])]);
        $d = TelegramDelivery::first();
        $this->assertTrue(app(TelegramService::class)->send($d->id));
        $this->assertSame('sent', $d->fresh()->status);
        $this->assertTrue(app(TelegramService::class)->send($d->id));
        Http::assertSentCount(1);
        Http::assertSent(fn ($request) => $request['chat_id'] === '-1001234567' && str_contains($request['text'], $b->customer_name) && ! str_contains($request['text'], $b->public_token));
    }

    public function test_telegram_disabled_failed_and_reassigned_driver_cases_are_recorded(): void
    {
        $b = $this->booking();
        $d = TelegramDelivery::first();
        $service = app(TelegramService::class);
        $this->assertTrue($service->send($d->id));
        $this->assertSame('disabled', $d->fresh()->status);
        Http::assertNothingSent();
        Setting::put('telegram_enabled', '1');
        Setting::put('telegram_bot_token', Crypt::encryptString('123456:demo-test-token'));
        Setting::put('telegram_group_id', '-1001234567');
        Http::fake(['api.telegram.org/*' => Http::response(['ok' => false], 403)]);
        $d->update(['status' => 'pending']);
        $this->assertFalse($service->send($d->id));
        $this->assertSame('failed', $d->fresh()->status);
        $this->assertStringNotContainsString('demo-test-token', $d->fresh()->last_error);
        $driver = $this->staff('driver');
        $stale = TelegramDelivery::create(['booking_id' => $b->id, 'target' => 'driver', 'target_user_id' => $driver->id, 'event' => 'driver_assigned']);
        $this->assertTrue($service->send($stale->id));
        $this->assertSame('cancelled', $stale->fresh()->status);
        Http::assertSentCount(1);
    }

    public function test_settings_encrypt_telegram_token_and_keep_it_out_of_html(): void
    {
        $this->actingAs($this->staff());
        $data = ['brand_name' => 'New Brand', 'accent_color' => '#cdee88', 'default_language' => 'km', 'min_notice_hours' => 3, 'home_sections' => 'routes,faq', 'booking_enabled' => 1, 'telegram_enabled' => 1, 'telegram_bot_token' => '123456:demo-secret-value', 'telegram_group_id' => '-1001234567'];
        $this->post('/admin/settings', $data)->assertSessionHasNoErrors();
        $encrypted = DB::table('settings')->where('key', 'telegram_bot_token')->value('value');
        $this->assertNotSame($data['telegram_bot_token'], $encrypted);
        $this->assertSame($data['telegram_bot_token'], Crypt::decryptString($encrypted));
        $this->get('/admin/settings')->assertOk()->assertDontSee('demo-secret-value');
        $this->get('/')->assertRedirect('/km');
    }

    public function test_staff_login_alerts_and_export_values(): void
    {
        $admin = User::factory()->create(['role' => 'admin', 'active' => true, 'password' => 'Correct-Password-123']);
        $b = $this->booking(['customer_name' => '=HYPERLINK("bad")']);
        $this->post('/staff/login', ['email' => $admin->email, 'password' => 'wrong'])->assertSessionHasErrors('email');
        $this->post('/staff/login', ['email' => $admin->email, 'password' => 'Correct-Password-123'])->assertRedirect('/admin');
        $response = $this->get('/admin/bookings/export')->assertOk();
        $this->assertStringContainsString("'=HYPERLINK", $response->streamedContent());
        $this->getJson('/staff/alerts')->assertOk();
        $this->postJson('/staff/alerts/read')->assertOk();
    }

    public function test_console_workers_read_updated_settings_and_recover_stale_sending(): void
    {
        Setting::put('telegram_enabled', '0');
        $this->assertSame('0', Setting::get('telegram_enabled'));
        DB::table('settings')->where('key', 'telegram_enabled')->update(['value' => '1']);
        $this->assertSame('1', Setting::get('telegram_enabled'));
        $b = $this->booking();
        Setting::put('telegram_bot_token', Crypt::encryptString('123456:demo-test-token'));
        Setting::put('telegram_group_id', '-1001234567');
        $d = TelegramDelivery::first();
        $d->update(['status' => 'sending', 'updated_at' => now()->subMinutes(2)]);
        Http::fake(['api.telegram.org/*' => Http::response(['ok' => true])]);
        $this->assertTrue(app(TelegramService::class)->send($d->id));
        $this->assertSame('sent', $d->fresh()->status);
        Http::assertSentCount(1);
    }
}
