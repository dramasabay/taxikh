<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\Setting;
use App\Models\TravelRoute;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Tests\TestCase;

class ModernExperienceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
        Queue::fake();
    }

    private function payload(): array
    {
        $trip = TravelRoute::first();

        return ['request_key' => (string) Str::uuid(), 'route_id' => $trip->id, 'vehicle_id' => $trip->vehicles->first()->id,
            'locale' => 'en', 'customer_name' => 'Map Passenger', 'phone' => '+85512345678', 'people' => 2,
            'pickup' => 'Riverside Hotel, Phnom Penh, Cambodia', 'dropoff' => 'Central Hotel, Siem Reap, Cambodia',
            'pickup_lat' => '11.5564000', 'pickup_lng' => '104.9282000', 'pickup_place_id' => 'ChIJ-pickup-example',
            'dropoff_lat' => '13.3633000', 'dropoff_lng' => '103.8564000', 'dropoff_place_id' => 'ChIJ-dropoff-example',
            'departure_date' => now('Asia/Phnom_Penh')->addDays(3)->format('Y-m-d'), 'departure_time' => '10:00'];
    }

    private function settings(array $values = []): array
    {
        return array_replace(['brand_name' => 'Mekong Ride', 'accent_color' => '#ffd801', 'default_language' => 'en',
            'min_notice_hours' => 2, 'home_sections' => 'benefits,fleet,routes,faq,reviews', 'default_theme' => 'system'], $values);
    }

    public function test_google_locations_survive_guest_booking_and_staff_receipt(): void
    {
        $response = $this->postJson('/api/v1/bookings', $this->payload())->assertCreated();
        $booking = Booking::first();
        $this->assertEquals(11.5564, $booking->pickup_lat);
        $this->assertEquals(103.8564, $booking->dropoff_lng);
        $this->assertSame('ChIJ-pickup-example', $booking->pickup_place_id);
        $this->assertStringContainsString('query_place_id=ChIJ-pickup-example', $booking->mapUrl('pickup'));
        $this->get($response->json('confirmation_url'))->assertOk()->assertSee($booking->mapUrl('pickup'));
        $admin = User::factory()->create(['role' => 'admin', 'active' => true]);
        $this->actingAs($admin)->get('/admin/bookings/'.$booking->id)->assertOk()->assertSee($booking->mapUrl('dropoff'));
    }

    public function test_invalid_or_incomplete_coordinates_are_rejected_but_manual_booking_works(): void
    {
        $payload = $this->payload();
        $this->postJson('/api/v1/bookings', [...$payload, 'pickup_lat' => 91])->assertUnprocessable()->assertJsonValidationErrors('pickup_lat');
        $this->postJson('/api/v1/bookings', [...$payload, 'dropoff_lng' => ''])->assertUnprocessable()->assertJsonValidationErrors('dropoff_lng');
        $this->postJson('/api/v1/bookings', [...$payload, 'pickup_place_id' => '<script>'])->assertUnprocessable()->assertJsonValidationErrors('pickup_place_id');
        foreach (['pickup', 'dropoff'] as $point) {
            foreach (['lat', 'lng', 'place_id'] as $part) {
                unset($payload[$point.'_'.$part]);
            }
        }
        $this->postJson('/api/v1/bookings', $payload)->assertCreated();
        $this->assertNull(Booking::first()->pickup_lat);
    }

    public function test_configured_route_cities_prefill_booking_and_legacy_detail_coordinates_remain_supported(): void
    {
        $context = ['from' => 'Riverside Hotel, Phnom Penh, Cambodia', 'to' => 'Central Hotel, Siem Reap, Cambodia',
            'from_lat' => '11.5564', 'from_lng' => '104.9282', 'from_place_id' => 'ChIJ-pickup-example',
            'departure_date' => now()->addDays(3)->format('Y-m-d'), 'departure_time' => '10:00'];
        $trip = TravelRoute::first();
        $query = http_build_query($context);
        $cities = http_build_query(['from' => $trip->text('origin', 'en'), 'to' => $trip->text('destination', 'en')]);
        $results = $this->get('/en/routes?'.$cities)->assertOk()->viewData('routes');
        $this->assertTrue($results->contains('id', $trip->id));
        $this->get('/en/routes/'.$trip->slug.'?'.$query)->assertOk()->assertSee('value="11.5564"', false)->assertSee('value="Riverside Hotel, Phnom Penh, Cambodia"', false);
        $this->get('/en/routes/'.$trip->slug.'?from[]=bad')->assertSessionHasErrors('from');
        $this->get('/en/routes?from_lat=100&from_lng=104')->assertSessionHasErrors('from_lat');
    }

    public function test_optional_google_address_autocomplete_requires_and_preserves_a_browser_key(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'admin', 'active' => true]));
        $this->post('/admin/settings', $this->settings(['google_maps_enabled' => 1]))->assertSessionHasErrors('google_maps_api_key');
        $this->post('/admin/settings', $this->settings(['google_maps_enabled' => 1, 'google_maps_api_key' => 'sample-browser-key', 'default_theme' => 'dark']))->assertSessionHasNoErrors();
        $this->assertSame('sample-browser-key', Setting::get('google_maps_api_key'));
        $this->get('/admin/settings')->assertOk()->assertDontSee('value="sample-browser-key"', false);
        $this->post('/admin/settings', $this->settings(['clear_google_maps_key' => 1]))->assertSessionHasErrors('google_maps_api_key');
        $this->post('/admin/settings', $this->settings(['google_maps_api_key' => '', 'google_maps_enabled' => 1]))->assertSessionHasNoErrors();
        $this->assertSame('sample-browser-key', Setting::get('google_maps_api_key'));
        $this->post('/admin/settings', $this->settings(['google_reviews_url' => 'https://google.com.evil.test/reviews']))->assertSessionHasErrors('google_reviews_url');
        $this->post('/admin/settings', $this->settings(['default_theme' => 'invalid']))->assertSessionHasErrors('default_theme');
    }

    public function test_navigation_theme_and_reviews_render_without_google_credentials_in_each_language(): void
    {
        foreach (['en', 'km', 'zh'] as $locale) {
            $this->get('/'.$locale)->assertOk()->assertSee('data-default-theme="system"', false)
                ->assertSee('mobile-app-nav', false)->assertDontSee('data-google-reviews', false)
                ->assertSee('data-theme-toggle', false)->assertDontSee('ui.location_')
                ->assertHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)')
                ->assertHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
        }
        $this->assertSame('#ffd801', Setting::get('accent_color'));
    }

    public function test_upgrade_keeps_bookings_and_custom_settings(): void
    {
        $this->postJson('/api/v1/bookings', $this->payload())->assertCreated();
        $bookingId = Booking::first()->id;
        $migration = require database_path('migrations/2026_09_13_031933_add_map_locations_and_modern_theme.php');
        $migration->down();
        Setting::put('accent_color', '#123456');
        Setting::put('home_sections', 'fleet,faq');
        $migration->up();
        $this->assertSame('#123456', Setting::get('accent_color'));
        $this->assertSame('fleet,faq', Setting::get('home_sections'));
        $this->assertSame($bookingId, Booking::first()->id);
        $this->assertSame('Map Passenger', Booking::first()->customer_name);
        DB::table('settings')->where('key', 'accent_color')->update(['value' => '#d3ed86']);
        DB::table('settings')->where('key', 'home_sections')->update(['value' => 'routes,benefits,fleet,guides,faq']);
        $migration->down();
        $migration->up();
        $this->assertSame('#ffd801', Setting::get('accent_color'));
        $this->assertSame('benefits,fleet,routes,guides,faq,reviews', Setting::get('home_sections'));
    }
}
