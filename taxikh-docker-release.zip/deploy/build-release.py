"""Build a source-only Docker release without credentials or runtime data."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[1]
output = root / 'deploy' / 'taxikh-docker-release.zip'
files = [
    'Dockerfile', '.dockerignore', '.env.example', '.env.docker.example',
    'compose.yaml', 'compose.host-npm.yaml', 'composer.json', 'composer.lock',
    'artisan', 'README.md', 'phpunit.xml', 'deploy/build-release.py',
]
folders = ['app', 'bootstrap', 'config', 'database', 'lang', 'public',
           'resources', 'routes', 'tests', 'docs', 'deploy/docker']
excluded = ['bootstrap/cache', 'public/storage', 'public/hot',
            'public/uploads', 'public/media']
allowed_extensions = {'.php', '.js', '.css', '.svg', '.png', '.jpg', '.jpeg',
                      '.webp', '.woff', '.woff2', '.ttf', '.txt', '.md',
                      '.json', '.html', '.conf', '.ini', '.sh'}
for folder in folders:
    for path in (root / folder).rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root).as_posix()
        if any(relative == item or relative.startswith(item + '/') for item in excluded):
            continue
        if path.suffix.lower() not in allowed_extensions or path.name.startswith('.env'):
            continue
        path.resolve().relative_to(root)
        files.append(relative)

with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(set(files)):
        path = root / name
        if path.is_symlink():
            raise ValueError(f'Symlink not allowed in release: {name}')
        archive.write(path, name)

with zipfile.ZipFile(output) as archive:
    names = archive.namelist()
    assert archive.testzip() is None
    assert not any(n.startswith(('storage/', 'vendor/', 'deploy/secrets/')) for n in names)
    assert '.env' not in names

digest = hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix('.zip.sha256').write_text(f'{digest}  {output.name}\n', encoding='utf-8')
print(f'Release: {output}\nFiles: {len(names)}\nBytes: {output.stat().st_size}\nSHA256: {digest}')
