#!/bin/sh
set -eu
umask 077

if [ "$(id -u)" != 0 ]; then
    echo 'Run with sudo from the project root; the host secret directory must remain private.' >&2
    exit 1
fi
directory="${TAXIKH_SECRETS_DIR:-./deploy/secrets}"
mkdir -p "$directory"
chmod 700 "$directory"
for name in db_password db_root_password migration_password; do
    if [ ! -e "$directory/$name" ]; then
        openssl rand -hex 32 > "$directory/$name"
    fi
done

if [ ! -s "$directory/app_key" ]; then
    echo 'Missing app_key: securely copy the EXISTING APP_KEY into deploy/secrets/app_key.' >&2
    echo 'For a genuinely empty installation only, generate: printf "base64:" > deploy/secrets/app_key; openssl rand -base64 32 >> deploy/secrets/app_key' >&2
    exit 1
fi
for name in app_key db_password db_root_password migration_password; do
    chown 0:0 "$directory/$name"
    # Compose file secrets are bind mounts: UID/GID/mode remapping is unsupported.
    # Read-only files are readable by each container's non-root UID. The enclosing
    # root-only 0700 host directory keeps them inaccessible to other host users.
    chmod 0444 "$directory/$name"
done
echo 'Secret files prepared; existing values preserved.'
