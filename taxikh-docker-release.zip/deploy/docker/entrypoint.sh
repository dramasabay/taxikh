#!/bin/sh
set -eu

read_secret() {
    name="$1"
    file="$2"
    if [ ! -r "$file" ]; then
        echo "Required secret is unreadable: $name" >&2
        exit 1
    fi
    value="$(cat "$file")"
    if [ -z "$value" ]; then
        echo "Required secret is empty: $name" >&2
        exit 1
    fi
    export "$name=$value"
}

read_secret APP_KEY "${APP_KEY_FILE:-/run/secrets/app_key}"
read_secret DB_PASSWORD "${DB_PASSWORD_FILE:-/run/secrets/db_password}"

mkdir -p storage/app/public storage/app/private storage/framework/cache/data \
    storage/framework/sessions storage/framework/views storage/logs bootstrap/cache

exec "$@"
