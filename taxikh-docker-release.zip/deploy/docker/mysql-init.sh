#!/bin/bash
set -eu

# Docker's MySQL entrypoint runs this on a new, empty data volume only.
# Hex passwords avoid SQL interpolation ambiguity. prepare-secrets.sh generates them.
migration_password="$(cat "$TAXIKH_MIGRATION_PASSWORD_FILE")"
if [[ ! "$migration_password" =~ ^[a-f0-9]{64}$ ]]; then
    echo 'migration_password must be 64 lowercase hexadecimal characters.' >&2
    exit 1
fi
# Standalone invocation also works if a transfer preserves the executable bit.
MYSQL_PWD="$(cat /run/secrets/db_root_password)" mysql --protocol=socket -u root <<SQL
REVOKE ALL PRIVILEGES ON taxikh.* FROM 'taxikh_app'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON taxikh.* TO 'taxikh_app'@'%';
CREATE USER 'taxikh_migrator'@'%' IDENTIFIED BY '${migration_password}';
GRANT ALL PRIVILEGES ON taxikh.* TO 'taxikh_migrator'@'%';
SQL
unset migration_password
