<?php

return [
    // Exact hostnames only. Never derive this list from an incoming Host header.
    'allowed_hosts' => array_values(array_filter(array_map('trim', explode(',', (string) env(
        'ALLOWED_HOSTS', parse_url((string) env('APP_URL', 'http://localhost'), PHP_URL_HOST) ?: 'localhost'
    ))))),

    // Only the final, private proxy may supply client IPs and the HTTPS scheme.
    'trusted_proxies' => array_values(array_filter(array_map('trim', explode(',', (string) env('TRUSTED_PROXIES', ''))))),
];
