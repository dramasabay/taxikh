# TAXIKH Docker hosting with your existing Nginx Proxy Manager

This deployment is prepared for **taxikh.com**, server **217.216.54.187**, with application HTTP on **host loopback port 91**. Your existing Nginx Proxy Manager (NPM) remains the public HTTPS entry point. The app, PHP-FPM and database have no public listener. Do not open port 91 or the database port to the internet.

These files prepare a deployment; they do not configure your server or DNS automatically. Docker is not installed in the current development workspace, so a real image build and container smoke test must run on the Linux server before switching live traffic.

## Traffic and isolation

```text
Internet -> existing NPM :443 -> taxikh-web:8080 -> app:9000 -> db:3306
                                |
                         127.0.0.1:91 on host
```

- Only NPM exposes public HTTP/HTTPS ports. Its administration port must be private, restricted by VPN/IP allowlist or accessed through an SSH tunnel.
- `web` is a non-root nginx container with request/connection limits, bounded timeouts, a 2 MB public body limit and a guarded dashboard upload allowance.
- App processes run as UID 10001, with read-only code, dropped Linux capabilities, process/memory/CPU limits and writable named storage only. PHP executes the front controller exclusively.
- MySQL has no published host port and joins an internal Docker network. Its root account is local only. `taxikh_app` has SELECT/INSERT/UPDATE/DELETE privileges on this database; the separate migration service has schema privileges and its own secret. Neither application nor worker receives the MySQL root secret.
- The app key and passwords are granted as read-only Compose secret files, not baked into images or stored in Compose environment values. Keep the existing APP_KEY when moving existing data.
- New deployments leave notification worker and scheduler off until explicitly enabled. Enabling them can deliver queued Telegram messages.

Docker secrets are plain files protected by the Linux filesystem, not an encrypted vault. Docker administrators and host root can read them. Protect Docker/SSH access and encrypted off-server backups accordingly.

## 1. Prepare the Linux host and release

Use a supported Linux host with Docker Engine and the Docker Compose plugin. Start with at least 6 GB RAM available for this stack plus NPM/OS, then size PHP workers and database memory from measured traffic. The configured resource ceilings are bounds, not a capacity guarantee.

Back up the existing production database, `.env`/APP_KEY and `storage/app/public` before migration. Keep the current site serving until the new stack passes verification. Transfer the project source to `/opt/taxikh`, excluding `.git`, local `.env`, `vendor`, test outputs and runtime storage; Docker installs production PHP dependencies from `composer.lock`. Transfer existing uploads and a database dump separately through a private channel.

The following Linux commands run as root from the release directory, so the secret directory can stay root-only:

```sh
sudo -i
cd /opt/taxikh
cp .env.docker.example deploy/compose.env
install -d -m 0700 deploy/secrets
```

Securely place the **existing APP_KEY value only**, including its `base64:` prefix, in `deploy/secrets/app_key`. Do not copy the whole `.env` file or regenerate an existing key. Avoid typing secrets into shell command lines or chat.

For a genuinely empty installation without existing encrypted data, generate a fresh key instead:

```sh
printf 'base64:' > deploy/secrets/app_key
openssl rand -base64 32 >> deploy/secrets/app_key
```

Prepare database passwords and permissions:

```sh
sh deploy/docker/prepare-secrets.sh
```

The helper preserves existing secrets. It sets the enclosing host directory to 0700 and files to 0444: the directory prevents other host users from traversing it, while the individually granted read-only mounts remain readable by the different non-root container UIDs. Compose file secrets do not support UID/GID/mode remapping. Do not loosen the directory permissions. Run future Compose commands with sufficient access to this directory.

## 2. Connect your existing NPM

Check `docker network ls`/`docker network inspect` for address conflicts before creating the dedicated proxy network. If either subnet overlaps an existing network, update all related addresses together in Compose, nginx configuration, and `TRUSTED_PROXIES`; do not broaden the trust range.

```sh
docker network create --driver bridge --subnet 172.29.91.0/24 --gateway 172.29.91.1 taxikh_proxy
```

If the correctly configured network already exists, reuse it.

### NPM runs in Docker on this server

Add the following network to **NPM's existing Compose configuration**, preserving its current volumes, published ports and other networks. The service name below is illustrative; use its real service name. Persist this in NPM's configuration so it survives recreation:

```yaml
services:
  npm:
    networks:
      default: {}
      taxikh_proxy:
        ipv4_address: 172.29.91.2
networks:
  taxikh_proxy:
    external: true
```

Recreate only the NPM service with its own Compose project after reviewing the change. This briefly affects proxied sites. The TAXIKH nginx trusts only this exact NPM address for `X-Real-IP`; NPM must overwrite that header with its observed client address. Keep its standard `X-Forwarded-Proto $scheme` behavior. Do not copy client-supplied forwarding headers unchanged. Do not trust `*` or the entire internet.

In your existing TAXIKH Proxy Host, set:

| Field | Value |
|---|---|
| Domain names | `taxikh.com` and, if used/configured in DNS, `www.taxikh.com` |
| Scheme | `http` |
| Forward hostname | `taxikh-web` |
| Forward port | `8080` |
| SSL | Valid certificate for these names; Force SSL enabled |

NPM in Docker must reach `taxikh-web:8080` over the shared network. `127.0.0.1:91` inside the NPM container refers to NPM itself. It is not the app.

### NPM/reverse proxy runs directly on the host

Use both Compose files for **every** command in the remaining sections:

```sh
docker compose --env-file deploy/compose.env -f compose.yaml -f compose.host-npm.yaml config --quiet
```

Point that proxy to **127.0.0.1:91**, with public Host `taxikh.com`, `X-Real-IP` overwritten from its real client address and `X-Forwarded-Proto` overwritten from its TLS scheme. The override trusts only Docker's dedicated proxy-network gateway. Verify the resulting client IP in logs/rate limits before opening traffic. The bridge gateway depends on the subnet configured above.

If NPM is on a different server, this loopback binding cannot serve it. Use a private network/VPN, bind only its private interface, and allow only that NPM host at the provider firewall; adjust the exact trusted address. Do not expose the origin publicly to work around connectivity.

## 3. Build and initialize without opening traffic

The commands below are for Docker NPM. Host-installed NPM must add `-f compose.yaml -f compose.host-npm.yaml` to every Compose invocation.

```sh
docker compose --env-file deploy/compose.env config --quiet
docker compose --env-file deploy/compose.env build --pull app web
docker compose --env-file deploy/compose.env up -d db
docker compose --env-file deploy/compose.env ps
```

Wait for the database to become healthy. The privilege initialization script runs only on a **new empty** MySQL volume; changing a secret file does not update an existing database user's password. Rotate database passwords with SQL and secret updates during a planned maintenance window. Never delete an existing database volume to fix a credential mismatch.

For an existing installation, import a dump containing **only the application database**, never MySQL system databases. The example reads its password inside the container and keeps it out of shell arguments:

```sh
docker compose --env-file deploy/compose.env exec -T db bash -c 'export MYSQL_PWD="$(cat /run/secrets/migration_password)"; exec mysql -h 127.0.0.1 -u taxikh_migrator taxikh' < /private/application-only.sql
```

Then run schema updates:

```sh
docker compose --env-file deploy/compose.env run --rm migrate
```

For a new installation only, seed the starter catalogue deliberately:

```sh
docker compose --env-file deploy/compose.env run --rm migrate php artisan db:seed --force
```

Start PHP and nginx, without notification services:

```sh
docker compose --env-file deploy/compose.env up -d app web
docker compose --env-file deploy/compose.env exec web nginx -t
docker compose --env-file deploy/compose.env exec app php artisan ride:diagnose --no-ansi
curl -I -H 'Host: taxikh.com' http://127.0.0.1:91/en
```

For migrated media, copy the **contents** of the old `storage/app/public` into `/var/www/html/storage/app/public` in the app container using `docker compose cp` or a controlled volume import. Afterwards ensure ownership is UID/GID 10001 and that only intended files were transferred. For example, with the old uploads staged in `/private/uploads`:

```sh
chown -R 10001:10001 /private/uploads
docker compose --env-file deploy/compose.env cp --archive /private/uploads/. app:/var/www/html/storage/app/public/
```

For a new installation create your admin interactively; no default password is provided:

```sh
docker compose --env-file deploy/compose.env exec app php artisan ride:admin
```

After migration and diagnostics, review the existing branding, pricing, Telegram delivery queue and canonical-domain settings. Existing data and staff accounts should be preserved; don't reseed an imported installation blindly.

## 4. Verify and switch traffic

If DNS is already configured, preserve it. Otherwise create the required A records pointing to **217.216.54.187** and remove stale AAAA records unless IPv6 is deliberately configured. DNS records do not specify port 91. Visitors should use **https://taxikh.com** on standard port 443.

Before switching the NPM forward target, verify:

```sh
docker compose --env-file deploy/compose.env exec web nginx -t
docker compose --env-file deploy/compose.env ps
docker compose --env-file deploy/compose.env logs --tail=100 app web db
curl -I -H 'Host: taxikh.com' http://127.0.0.1:91/.env
curl -I -H 'Host: taxikh.com' http://127.0.0.1:91/.git/config
```

The sensitive paths must return 403/404, never their content. Check HTTPS homepage, languages, assets, booking quote, login, role permissions, media, backup download and a controlled booking with your own details. Confirm secure/HttpOnly session cookies and that spoofed forwarding headers cannot change client identity. From an external machine, confirm 91/3306/9000 are closed. Verify isolation using `docker compose ps` and the host/provider firewall as well; application HTTP checks cannot prove firewall rules.

NPM and any CDN may otherwise record reservation tokens in URL paths. Disable this Proxy Host's access log or configure redaction there, retain error logs privately and never share raw request logs. TAXIKH's nginx log already omits query strings and redacts reservation paths. Avoid browser/network traces containing booking links in public support requests.

The dashboard accepts ZIP backups up to 128 MB. If needed, allow `client_max_body_size 160m;` and `proxy_read_timeout 120s;` in this NPM Proxy Host's Advanced configuration; verify nginx accepts the configuration and a legitimate restore upload. Other upstream/CDN upload limits may be lower. Keep this allowance scoped to this host; the app nginx limits ordinary public requests to 2 MB.

After reviewing pending messages, deliberately start notification processing:

```sh
docker compose --env-file deploy/compose.env --profile notifications up -d worker scheduler
```

The scheduler retries recoverable notification deliveries every five minutes. Review the queue before enabling it because pending messages may belong to migrated bookings.

## DDoS and host access

The per-client nginx limits and application throttles reduce request abuse. They cannot absorb a distributed flood that saturates the server's network or provider uplink. Use the hosting provider's DDoS protection and, if desired, a suitable CDN/WAF with origin lockdown. A CDN setup must restore real client addresses only from that provider's maintained trusted IP ranges at NPM; never accept arbitrary `CF-Connecting-IP` or forwarding headers from the public internet.

At the provider firewall allow public 80/443 only to NPM; restrict SSH to your administrator IP/VPN and deny public database, FPM, port 91 and NPM administration access. When using a CDN, allow origin web traffic only from the CDN's published ranges after certificate/renewal and monitoring paths are planned. Keep SSH key-only access, supported host packages and patched Docker/NPM/images. Do not give app containers the Docker socket or privileged mode.

Docker-published ports can bypass ordinary UFW rules. Prefer the provider firewall, loopback binding and carefully tested Docker `DOCKER-USER`/nftables rules rather than relying on UFW alone. Keep an out-of-band console available when changing host firewall rules. Do not run unbounded load tests against a live site.

## Backups and updates

Keep encrypted off-server copies of the application database, media, original APP_KEY and matching source release. The dashboard data backup excludes code and `.env`. Test restoration on an isolated stack with notifications disabled. Docker volumes are persistence, not a backup.

For updates: back up, enable application maintenance, stop `worker`/`scheduler`, build a fresh release tag, run `migrate`, recreate `app`/`web`, verify, and restart notifications. Keep the previous image/tag for code rollback. A schema change may require a matching database restore rather than just an image rollback. **Never use `docker compose down -v` on an installation you want to keep.**

After initial server validation, pin tested base images by digest in the release process and schedule image/dependency updates. The supplied supported-version tags intentionally receive upstream security updates when rebuilt with `--pull`; retain the tested image IDs for each deployed release.

Primary references: [NPM setup](https://nginxproxymanager.com/setup/), [Compose secrets](https://docs.docker.com/compose/how-tos/use-secrets/), [nginx request limiting](https://nginx.org/en/docs/http/ngx_http_limit_req_module.html), [nginx real IP trust](https://nginx.org/en/docs/http/ngx_http_realip_module.html), [Docker firewall behavior](https://docs.docker.com/engine/network/packet-filtering-firewalls/).
