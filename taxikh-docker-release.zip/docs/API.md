# Public API v1

Base: your application origin plus `/api/v1`. Send JSON with `Content-Type: application/json` and `Accept: application/json`. Public guest endpoints do not require a customer account. Do not expose database credentials or a Telegram bot token to clients.

## Catalog

`GET /api/v1/catalog`

Returns active routes with translated titles/origins/destinations, route IDs, slugs, vehicle capacities, vehicle IDs and fares in integer USD cents, plus available extras. v2.0 adds `distance_km`, `map_embed_url`, vehicle `category` and translated `features`, plus extra `destination`, `travel_route_id` and `image_path`. An extra with `travel_route_id: null` is global; otherwise it is restricted to that route. Only public catalog fields are returned.

## Quote

`POST /api/v1/quote`

```json
{
  "route_id": 1,
  "vehicle_id": 1,
  "people": 2,
  "extras": [1],
  "locale": "en"
}
```

Use IDs returned by the catalog; they are not guaranteed to be 1 on an edited installation. The quote includes `base_cents`, `total_cents`, `currency`, selected extras and `capacity`. A vehicle must belong to that active route. Extras are charged once per booking. The server rejects extras restricted to another route, even when their IDs are supplied manually.

## Guest booking

`POST /api/v1/bookings`

```json
{
  "request_key": "947c8fd4-b4c6-4c50-bd35-21e1a762a3f8",
  "route_id": 1,
  "vehicle_id": 1,
  "locale": "en",
  "customer_name": "Example Passenger",
  "phone": "+855 12 345 678",
  "people": 2,
  "pickup": "Hotel name and address in the pickup area",
  "dropoff": "Hotel name and address in the destination area",
  "pickup_lat": 11.5564,
  "pickup_lng": 104.9282,
  "pickup_place_id": "your-selected-place-id",
  "departure_date": "2026-10-15",
  "departure_time": "09:30",
  "extras": [1],
  "notes": "Flight number or special requests",
  "website": ""
}
```

The date above is an example: use a future date that meets the site's minimum notice period and is no more than 365 days ahead. Date/time input is always Cambodia time (Asia/Phnom_Penh, UTC+7). `locale` is `en`, `km` or `zh`.

Optional map fields are `pickup_lat`, `pickup_lng`, `pickup_place_id`, `dropoff_lat`, `dropoff_lng` and `dropoff_place_id`. Send latitude/longitude together; latitude must be -90 to 90 and longitude -180 to 180. Place IDs are at most 255 letters, digits, underscores or hyphens. Omit these fields for a manual address. Store the customer's selected location only after their action/permission. Location metadata does not change the catalog fare.

Generate a new UUID request key for each intended new reservation. Preserve the key and exact payload if a network interruption requires a retry. A repeated matching request returns the existing reservation; reusing the key with different data returns 409. Keep the request key private with the customer's reservation data.

Successful response: HTTP 201.

```json
{
  "reference": "MR-260912-EXAMPLE",
  "status": "pending",
  "total_cents": 10000,
  "currency": "USD",
  "confirmation_url": "https://your-domain.example/en/reservation/<private-token>"
}
```

The response reference, price and URL are examples. The backend calculates the authoritative price. The `confirmation_url` is a private access credential: do not place it in analytics, public posts or Telegram group messages. The operator and driver use their authenticated staff pages instead.

The website uses the CSRF-protected equivalent `POST /{locale}/booking` with FormData and the `X-CSRF-TOKEN` header. The `/api/v1` routes are guest JSON endpoints, suitable for a future mobile client.

## Errors and rate limits

| Response | Meaning |
|---|---|
| 422 | Validation error; `errors` contains field messages |
| 409 | Request key was already used with different booking details |
| 429 | Rate limit exceeded; respect the response headers and wait before retrying |
| 401 / 403 | Missing staff authentication or forbidden staff action |
| 419 | Missing/expired CSRF protection on a web form; reload the form |
| 503 | Public booking is paused for maintenance; respect Retry-After |

Booking submissions are limited to 5 per minute per IP across web/API. Quote/catalog requests are limited to 90 per minute per IP. Contact inquiries allow 3 per minute. Staff login is limited to 5 per minute per email/IP pair. Additional abuse protection may be appropriate as traffic grows.

## Extending to a mobile app

`PricingService`, `BookingService`, `DispatchService`, `AlertService` and `TelegramService` hold shared business logic. The website's admin/driver endpoints currently use session authentication and role middleware. A native staff/driver app needs separately implemented token authentication, device registration, API policies, account recovery and push notification endpoints. Do not make admin endpoints public to connect an app.

Continuous driver GPS tracking, map-distance pricing, automatic dispatch and customer push messages are not part of API v1. A future Flutter or React Native app can consume the public catalog/quote/booking API and share this backend.

## Driver trip actions (v1.4)

The staff website uses `POST /driver/bookings/{id}/action` with its authenticated driver session and CSRF token. Send `Accept: application/json` and `X-Requested-With: XMLHttpRequest` for JSON. This endpoint is not native-app token authentication.

Required fields: `action` and the booking's current `dispatch_version` integer.

| Action | Additional fields / behavior |
|---|---|
| `accept` | Accepts an assignment or handover. |
| `on_the_way` | Moves an accepted assigned trip toward pickup. |
| `pickup` | Moves On the way to In progress. |
| `complete` | Moves In progress to Completed. Optional `completion_note` (max 1000) and `cash_received` boolean. |
| `return` | Required `reason` (1–1000 characters). Before pickup, unassigns and flags dispatch; after pickup, retains assignment and asks for admin review. |
| `collect_cash` | Explicitly records collection during or after the trip. |

For optional completion location, send all four fields together: `completion_lat`, `completion_lng`, `completion_accuracy_m` (0–100000) and `completion_captured_at` (Unix seconds). Coordinates are validated and samples must be no older than five minutes, allowing up to one minute of forward clock skew. This records a driver-reported point; it does not independently verify arrival.

A successful JSON response contains `message`, `status`, `dispatch_review`, `dispatch_version` and `redirect_url`. Repeating the current accept/progress/completion action has no duplicate side effects. Use the returned version or reload before the next action. Unauthorized assignments return 403; invalid transitions or stale versions return 422. An HTML form redirects to the trip, or to the driver's booking list after returning the task.

Admin/dispatcher review is `POST /admin/bookings/{id}/resolve-dispatch`, with `dispatch_version` and required `dispatch_note`. This keeps the current driver. Reassign using the existing admin booking PATCH route; the backend preserves pickup progress and clears the review. Unassigned review requests must be reassigned or cancelled, not simply dismissed. Driver calls to the older PATCH route also require `dispatch_version`.

Completion time is visible on the customer's private confirmation page after refresh. Driver location and internal notes remain in staff views.

## Route discovery and dashboard operations (v2.0)

`GET /{locale}/booking?from=Phnom%20Penh&to=Siem%20Reap&departure_date=2026-10-15&departure_time=09%3A30` accepts configured city names (English, Khmer or Chinese), then redirects to the matching route or a results list if several match. It does not create a booking. `/routes` and the homepage accept `type`, `q`, `sort` (`recommended`, `price_asc`, `price_desc`, `duration`, `name`), `layout` (`grid`, `list`) and `page`. Pagination size comes from admin column × row settings.

System tools are administrator-only session/CSRF routes, not guest mobile APIs. Backup export/restore uses a versioned, encrypted manifest and media ZIP. It never accepts SQL or executes queue payloads. See README for the maintenance, password, stopped-worker, confirmation and same-APP_KEY requirements.
