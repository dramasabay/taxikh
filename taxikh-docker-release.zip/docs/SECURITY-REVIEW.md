# Security review and fixes — 2 November 2026

Reviewed this source checkout, its locked PHP dependencies, and the proposed Docker deployment. This is a source review and regression check, not a guarantee that the application has no vulnerabilities or a production penetration test.

## Confirmed issues fixed

| Finding | Fix |
| --- | --- |
| Completing a reopened trip could compound overtime charges | Recalculate from the fare before overtime; remove old overtime when correcting duration. |
| A configured 0% commission could become 20% | Preserve zero in calculation and staff/driver forms. |
| Staff password changes left previous sessions active | Bind sessions to password hashes; delete other database sessions; rotate remember tokens, current session ID and CSRF token. Admin password resets revoke sessions too. |
| Rotating login account names bypassed the original per-account-and-IP throttle | Apply independent per-IP and normalized-account limits; malformed email arrays receive validation errors. Password-change attempts are throttled too. |
| Arbitrary Host headers could influence generated URLs | Restrict production hosts to an explicit list, defaulting to the APP_URL hostname. |
| HTTPS/client-IP handling was not configured for NPM | Trust only configured private proxy IPs for forwarded address and scheme, never forwarded Host/Port. The Docker proxy rewrites these headers. |
| No Content Security Policy | Block executable inline scripts, eval, objects, foreign form submissions and unauthorized framing; allow the existing map/review providers. |
| Four dependency advisories, including denial of service | Update league/commonmark 2.10.1 → 2.10.7, symfony/http-foundation 7.4.18 → 7.4.22 and symfony/mime 7.4.18 → 7.4.22. Composer reported no known advisories after the update. |
| Default test command referenced a missing tests/Unit folder | Point the suite at the existing feature tests. |

Also reviewed role/driver authorization, CSRF protection, parameterized database queries, upload/media path restrictions, server-calculated booking prices, booking retries, public reservation tokens, backup encryption and archive path validation. No additional exploit was confirmed in those reviewed paths.

## Deployment protections

The Docker configuration keeps MySQL and PHP-FPM off public host ports. The normal application database account has only SELECT/INSERT/UPDATE/DELETE on its own schema. Schema migration uses a separate credential through an explicitly invoked tool service. Root login is local to the database container. Secrets stay outside the image and source archive. App/web filesystems are read-only except dedicated storage and temporary mounts; app/web run without root or Linux capabilities.

Nginx limits request rates, concurrent connections, body sizes and timeouts before PHP handles requests. Containers also have memory, CPU and process limits. The website port is bound to 127.0.0.1:91; an existing NPM container can instead connect over the dedicated private network. Private reservation paths are redacted from the supplied access log format. NPM's own access logs must be configured separately.

## Verification

- Full PHP regression suite: **80 tests, 951 assertions passed** after all application changes and dependency updates, using disposable SQLite data.
- Composer manifest validation passed. Dependency update completed with no known security advisories.
- Browser checks: local homepage, language menu, route map, booking step navigation and server price quote worked. No browser warnings/errors were reported during these checks.
- No booking was submitted during browser checks and no Telegram worker was started.
- Docker was not installed in the review environment. Build, nginx configuration validation and MySQL startup must be checked on a Docker host before production traffic is switched.
- The HTTP connection to 217.216.54.187:91 timed out from this environment. Server access, existing NPM configuration, TLS, DNS, provider firewall and production data migration have not been verified or changed.
- The client's optional Google Places key and Tripadvisor widget require their own browser checks; the review did not validate those external services.

## DDoS and database limits

Application throttles cannot stop traffic from saturating a server's network connection. Use provider DDoS protection and an edge proxy such as Cloudflare. If Cloudflare is used, restrict public origin HTTP/HTTPS ingress to its published networks at the provider firewall, and configure NPM to trust client-IP headers only from those networks. Do not simply trust every inbound X-Forwarded-For or CF-Connecting-IP value. Check IPv6 as well as IPv4.

Keep SSH and NPM administration reachable only from a VPN or administrator IPs. Do not publish database, PHP-FPM, Docker daemon or website port91 publicly. Docker-published ports can bypass ordinary UFW rules; enforce provider firewall and the appropriate Docker forwarding rules. Preserve the existing APP_KEY when migrating encrypted records, back up data and uploads off-server, and apply regular image/dependency updates.

These controls reduce exposure; they do not make unauthorized access or DDoS impossible. Production protection is incomplete until the host controls and live smoke checks are actually applied.

References: [Laravel request/proxy configuration](https://github.com/laravel/docs/blob/13.x/requests.md), [Laravel rate limiting](https://laravel.com/framework/docs/rate-limiting), [Cloudflare DDoS defense](https://developers.cloudflare.com/ddos-protection/best-practices/proactive-defense/), [Docker firewall behavior](https://docs.docker.com/engine/network/packet-filtering-firewalls/).
