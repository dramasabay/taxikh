<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#ffd801">
<script src="{{ ride_asset('assets/theme-init.js') }}"></script>
<link rel="stylesheet" href="{{ ride_asset('assets/app.css') }}">
<link rel="stylesheet" href="{{ ride_asset('assets/theme.css') }}">
<link rel="stylesheet" href="{{ ride_asset('assets/taxikh.css') }}">
@php
    $hwMap = ['standard' => '1224px', 'wide' => '1440px', 'extra' => '1600px', 'full' => '100%'];
    $hw = $hwMap[setting('header_max_width', 'standard')] ?? '1224px';
    $cw = $hwMap[setting('content_max_width', 'standard')] ?? '1224px';
@endphp
<style>
:root{--accent:{{ setting('accent_color','#ffd801') }};--accent-ink:{{ accent_text_color() }};--header-max-width:{{ $hw }};--content-max-width:{{ $cw }}}
.header-inner{max-width:var(--header-max-width)!important}
.container,.booking-container{max-width:var(--content-max-width)!important}
</style>
