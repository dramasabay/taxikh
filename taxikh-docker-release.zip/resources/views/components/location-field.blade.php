@php($locationId = $id ?? $name)
<div class="location-field {{ ($compact ?? false) ? 'compact' : '' }}" data-location-field>
    <label for="{{ $locationId }}">{{ $label }} @if($required ?? false)<span aria-hidden="true">*</span>@endif @if($area ?? false)<small>{{ $area }}</small>@endif</label>
    <div class="location-input-row">
        @include('components.icon', ['name' => 'pin'])
        <input id="{{ $locationId }}" name="{{ $name }}" value="{{ $value ?? '' }}" placeholder="{{ __('ui.address_hint') }}" maxlength="300" minlength="{{ ($required ?? false) ? 3 : 0 }}" @required($required ?? false) autocomplete="off" data-location-input>
        @if($locate ?? false)<button type="button" class="locate-button" data-locate aria-label="{{ __('ui.use_location') }}" title="{{ __('ui.use_location') }}"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 1v4m0 14v4M1 12h4m14 0h4"/></svg></button>@endif
    </div>
    @foreach(['lat', 'lng', 'place_id'] as $part)<input type="hidden" name="{{ $name }}_{{ $part }}" value="{{ $metadata[$part] ?? '' }}" data-location-{{ str_replace('_','-',$part) }}>@endforeach
    <div class="location-options" data-location-options hidden><div role="listbox" id="{{ $locationId }}-suggestions" aria-label="{{ $label }}" data-location-list></div><div class="google-attribution"><img src="{{ asset('assets/google-maps-attribution.svg') }}" alt="Google Maps" width="100" height="18"></div></div>
    <div class="location-feedback"><small data-location-status role="status" aria-live="polite"></small><a data-location-link hidden target="_blank" rel="noopener noreferrer">{{ __('ui.view_on_map') }} ↗</a></div>
</div>
