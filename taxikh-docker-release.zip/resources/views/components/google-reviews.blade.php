<section class="reviews-section container section" id="reviews" data-google-reviews>
    <div class="section-heading"><div><span class="eyebrow">{{ __('ui.traveler_experiences') }}</span><h2>{{ __('ui.reviews') }}</h2><p>{{ __('ui.reviews_intro') }}</p></div>
        <div class="google-rating" data-google-rating hidden><img src="{{ asset('assets/google-maps-attribution.svg') }}" alt="Google Maps" width="100" height="18"><strong data-rating-value></strong><span class="review-stars" aria-hidden="true">★★★★★</span><span data-rating-count></span></div>
    </div>
    <div class="reviews-grid" data-reviews-list></div>
    <div class="reviews-empty" data-reviews-fallback><span class="feature-icon">@include('components.icon',['name'=>'star'])</span><div><h3>{{ __('ui.share_experience') }}</h3><p>{{ __('ui.feedback_welcome') }}</p></div></div>
    <div class="reviews-actions">
        @if(google_reviews_link())<a class="button outline" href="{{ google_reviews_link() }}" target="_blank" rel="noopener noreferrer">{{ __('ui.read_google_reviews') }} ↗</a>@endif
        @if(setting('google_place_id'))<a class="button" href="https://search.google.com/local/writereview?placeid={{ rawurlencode(setting('google_place_id')) }}" target="_blank" rel="noopener noreferrer">{{ __('ui.write_review') }} @include('components.icon',['name'=>'star'])</a>@else<a class="button outline" href="{{ route('contact') }}">{{ __('ui.contact_support') }} ↗</a>@endif
    </div>
</section>
