@php($googleEmbed=json_decode(setting('google_embed','[]'),true)?:[])
@php($tripadvisorEmbed=json_decode(setting('tripadvisor_embed','[]'),true)?:[])
@if($googleEmbed || $tripadvisorEmbed || google_reviews_link() || setting('tripadvisor_url'))
<section class="reviews-section container section" id="reviews" data-review-embeds><div class="section-heading"><div><span class="eyebrow">{{ __('ui.traveler_experiences') }}</span><h2>{{ __('ui.reviews') }}</h2></div><div class="review-links">
@if(google_reviews_link())<a class="button outline small" href="{{ google_reviews_link() }}" target="_blank" rel="noopener noreferrer">Google ↗</a>@endif
@if(setting('tripadvisor_url'))<a class="button outline small" href="{{ setting('tripadvisor_url') }}" target="_blank" rel="noopener noreferrer">Tripadvisor ↗</a>@endif
</div></div><div class="review-embed-grid">@if($googleEmbed)@include('components.provider-embed',['embed'=>$googleEmbed,'embedTitle'=>'Google Maps'])@endif @if($tripadvisorEmbed)@include('components.provider-embed',['embed'=>$tripadvisorEmbed,'embedTitle'=>'Tripadvisor'])@endif</div></section>
@endif
