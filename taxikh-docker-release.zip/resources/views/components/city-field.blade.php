<div class="city-field" data-city-field>
<label for="{{ $searchId }}-{{ $name }}">{{ $label }}</label>
<select id="{{ $searchId }}-{{ $name }}" name="{{ $name }}" @required($required??false) data-city-select>
<option value="">{{ __('taxikh.choose_city') }}</option>
@foreach($cities as $city)<option value="{{ $city['value'] }}" data-aliases="{{ json_encode($city['aliases'],JSON_UNESCAPED_UNICODE) }}" @selected(in_array(old($name,request($name)),array_merge([$city['value']],$city['aliases']),true))>{{ $city['label'] }}</option>@endforeach
</select>
</div>
