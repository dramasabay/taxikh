@if($booking->completed_at)
<section class="panel padded completion-summary">
    <span class="eyebrow">{{ __('ui.trip_completed') }}</span><h2>{{ __('ui.dropoff_record') }}</h2>
    <div class="receipt-grid">
        <div><small>{{ __('ui.completed_time') }}</small><strong>{{ $booking->completed_at->timezone('Asia/Phnom_Penh')->format('d M Y H:i') }}</strong><small>{{ __('ui.timezone_note') }}</small></div>
        <div><small>{{ __('ui.completed_by') }}</small><strong>{{ $booking->completedBy?->name ?? '—' }}</strong></div>
        <div><small>{{ __('ui.payment') }}</small><strong>{{ __('ui.'.$booking->payment_status) }}</strong></div>
        @if($booking->cashCollectedBy)<div><small>{{ __('ui.cash_recorded_by') }}</small><strong>{{ $booking->cashCollectedBy->name }}</strong></div>@endif
    </div>
    @if($booking->completion_note)<p class="preserve-lines">{{ $booking->completion_note }}</p>@endif
    @if($booking->completionMapUrl())
        <a class="button outline small" href="{{ $booking->completionMapUrl() }}" target="_blank" rel="noopener noreferrer">{{ __('ui.completion_location') }} ↗</a>
        <p class="help">{{ __('ui.location_accuracy') }}: ± {{ number_format($booking->completion_accuracy_m) }} m
            @if($booking->completionDistanceMeters()!==null) · {{ __('ui.distance_to_dropoff',['meters'=>number_format($booking->completionDistanceMeters())]) }}@endif
        </p><p class="help">{{ __('ui.location_evidence_note') }}</p>
    @else
        <p class="help">{{ __('ui.completion_without_location') }}</p>
    @endif
</section>
@endif
