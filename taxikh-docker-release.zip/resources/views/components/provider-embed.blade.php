@if(($embed['kind']??'')==='widget')
<iframe class="provider-embed" title="Tripadvisor" srcdoc="{{ app(\App\Services\EmbedService::class)->widgetDocument($embed) }}" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" style="height:{{ (int)setting('review_embed_height',380) }}px"></iframe>
@elseif(!empty($embed['url']))
<iframe class="provider-embed" title="{{ $embedTitle??__('ui.reviews') }}" src="{{ $embed['url'] }}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen style="height:{{ (int)setting('review_embed_height',380) }}px"></iframe>
@endif
