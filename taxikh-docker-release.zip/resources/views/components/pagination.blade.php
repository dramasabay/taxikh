@if($paginator->hasPages())<nav class="pagination" aria-label="Pagination">
@if($paginator->onFirstPage())<span class="disabled">{{ __('ui.previous') }}</span>@else<a href="{{ $paginator->previousPageUrl() }}" rel="prev">{{ __('ui.previous') }}</a>@endif
<span>{{ $paginator->currentPage() }} / {{ $paginator->lastPage() }}</span>
@if($paginator->hasMorePages())<a href="{{ $paginator->nextPageUrl() }}" rel="next">{{ __('ui.next') }}</a>@else<span class="disabled">{{ __('ui.next') }}</span>@endif
</nav>@endif
