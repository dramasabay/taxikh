<section class="panel padded driver-controls">
    <h2>{{ __('ui.your_trip') }}</h2>
    <ol class="trip-steps">
        @foreach(['driver_accepted_at'=>'driver_accepted','on_the_way_at'=>'driver_on_the_way','picked_up_at'=>'passenger_picked_up','completed_at'=>'trip_completed'] as $field=>$label)
            <li class="{{ $booking->$field ? 'done' : '' }}"><span class="step-dot">{{ $loop->iteration }}</span><div><b>{{ __('ui.'.$label) }}</b>@if($booking->$field)<small>{{ $booking->$field->timezone('Asia/Phnom_Penh')->format('d M H:i') }}</small>@endif</div></li>
        @endforeach
    </ol>
    <div class="driver-commission-card" style="background:var(--pale); border:1px solid var(--line); border-radius:14px; padding:16px; margin:16px 0;">
        <h3 style="font-size:14px; margin-bottom:10px;">{{ __('taxikh.trip_earnings') }}</h3>
        <div style="display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px;">
            <span>{{ __('taxikh.customer_fare') }}</span>
            <b>{{ money($booking->total_cents) }}</b>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px; color:#b03a2e;">
            <span>{{ __('taxikh.company_commission') }} ({{ (float)($booking->commission_rate ?? 20) }}%)</span>
            <b>-{{ money($booking->commission_cents) }}</b>
        </div>
        <div style="display:flex; justify-content:space-between; border-top:1px solid var(--line); padding-top:8px; font-size:14px; color:#1e7e34;">
            <span><strong>{{ __('taxikh.driver_net_earnings') }}</strong></span>
            <strong>{{ money($booking->driver_payout_cents) }}</strong>
        </div>
        @if(!$booking->driver_agreed_commission && in_array($booking->status, ['assigned', 'on_the_way']))
            <p class="help" style="margin-top:8px; color:#9c4118; font-size:12px;">{{ __('taxikh.must_agree_commission', ['percent' => (float)($booking->commission_rate ?? 20)]) }}</p>
        @endif
    </div>
    @if($booking->dispatch_review)
        <div class="notice"><b>{{ __('ui.awaiting_dispatch') }}</b><p>{{ __('ui.help_pending') }}</p></div>
    @endif
    @php
        $driverAction = match (true) {
            in_array($booking->status,['assigned','on_the_way','in_progress']) && (!$booking->driver_accepted_at || !$booking->driver_agreed_commission) => 'accept',
            $booking->status === 'assigned' => 'on_the_way',
            $booking->status === 'on_the_way' => 'pickup',
            $booking->status === 'in_progress' => 'complete',
            default => null,
        };
        $actionLabels = ['accept'=>'agree_and_accept','on_the_way'=>'start_pickup','pickup'=>'confirm_pickup','complete'=>'complete_dropoff'];
    @endphp
    @if($driverAction)
        <form method="post" action="{{ route('driver.booking.action',$booking->id) }}" data-driver-action-form>
            @csrf<input type="hidden" name="action" value="{{ $driverAction }}"><input type="hidden" name="dispatch_version" value="{{ $booking->dispatch_version }}">
            @if($driverAction==='complete')
                <p class="help">{{ __('ui.complete_help') }}</p>
                @if($booking->route?->overtime_enabled)
                    <div class="field" style="margin-bottom:12px;">
                        <label>{{ __('taxikh.actual_duration') }} ({{ __('ui.minutes') }})</label>
                        <input type="number" name="actual_duration_minutes" min="1" max="2880" placeholder="{{ $booking->route->duration_minutes }}" value="{{ old('actual_duration_minutes', $booking->route->duration_minutes) }}">
                        <small class="help">{{ __('taxikh.overtime_calc_hint', ['scheduled' => $booking->route->duration_minutes, 'rate' => money($booking->route->overtime_rate_cents), 'min' => $booking->route->overtime_interval_minutes]) }}</small>
                    </div>
                @endif
                <label class="field">{{ __('ui.completion_note') }} ({{ __('ui.optional') }})<textarea name="completion_note" rows="3" maxlength="1000">{{ old('completion_note') }}</textarea></label>
                <div class="completion-location" data-completion-location data-loading="{{ __('ui.location_locating') }}" data-success="{{ __('ui.completion_location_saved') }}" data-error="{{ __('ui.completion_location_failed') }}" data-denied="{{ __('ui.location_denied') }}" data-unsupported="{{ __('ui.location_not_supported') }}">
                    <p class="help">{{ __('ui.completion_location_help') }}</p>
                    @foreach(['completion_lat','completion_lng','completion_accuracy_m','completion_captured_at'] as $field)<input type="hidden" name="{{ $field }}" value="">@endforeach
                    <button type="button" class="button outline full" data-capture-completion>@include('components.icon',['name'=>'pin']) {{ __('ui.capture_completion_location') }}</button>
                    <span class="help" data-completion-location-status role="status" aria-live="polite"></span>
                    <button type="button" class="text-button" data-clear-completion hidden>{{ __('ui.remove_location') }}</button>
                </div>
                @if($booking->payment_status!=='paid')<label class="check-label"><input type="checkbox" name="cash_received" value="1" @checked(old('cash_received'))>{{ __('ui.cash_received') }} · {{ money($booking->total_cents) }}</label>@endif
            @endif
            <button type="submit" class="button dark full">@if($driverAction==='accept') {{ __('taxikh.agree_and_accept', ['percent' => (float)($booking->commission_rate ?? 20)]) }} @else {{ __('ui.'.$actionLabels[$driverAction]) }} @endif @include('components.icon',['name'=>'check'])</button>
        </form>
    @endif
    @if(in_array($booking->status,['assigned','on_the_way','in_progress']) && !$booking->dispatch_review)
        <details class="return-trip"><summary>{{ __($booking->status==='in_progress'?'ui.request_dispatch_help':'ui.return_trip') }}</summary>
            <p class="help">{{ __($booking->status==='in_progress'?'ui.help_pending':'ui.return_help') }}</p>
            <form method="post" action="{{ route('driver.booking.action',$booking->id) }}" data-driver-action-form>
                @csrf<input type="hidden" name="action" value="return"><input type="hidden" name="dispatch_version" value="{{ $booking->dispatch_version }}">
                <label class="field">{{ __('ui.return_reason') }} *<textarea name="reason" required rows="3" minlength="1" maxlength="1000">{{ old('reason') }}</textarea></label>
                <button type="submit" class="button outline full">{{ __('ui.send_to_dispatch') }}</button>
            </form>
        </details>
    @endif
    @if($booking->payment_status==='paid')
        <div class="notice success">{{ __('ui.cash_received') }} · {{ $booking->paid_at?->timezone('Asia/Phnom_Penh')->format('d M H:i') }}</div>
    @elseif($booking->status==='completed')
        <div class="notice error">{{ __('ui.cash_still_unpaid') }}</div>
        <form method="post" action="{{ route('driver.booking.action',$booking->id) }}" data-driver-action-form>
            @csrf<input type="hidden" name="action" value="collect_cash"><input type="hidden" name="dispatch_version" value="{{ $booking->dispatch_version }}">
            <button type="submit" class="button outline full">{{ __('ui.record_cash') }} · {{ money($booking->total_cents) }}</button>
        </form>
    @endif
    @if($booking->status==='completed')
        <div class="notice success" style="margin-top: 0.75rem;">
            <b>@include('components.icon',['name'=>'check']) {{ __('ui.trip_completed') }}</b>
            <p>{{ $booking->completed_at?->timezone('Asia/Phnom_Penh')->format('d M Y, H:i') }} (UTC+7)</p>
            @if($booking->completion_note)<p><small>{{ $booking->completion_note }}</small></p>@endif
        </div>
    @endif
</section>
