@php($searchId=$searchId??'trip-search')
<form action="{{ route('booking.start') }}" class="ride-search city-search" data-city-search>
@include('components.city-field',['name'=>'from','label'=>__('ui.from'),'cities'=>$cityOrigins,'required'=>true])
<button type="button" class="route-connector" data-city-swap aria-label="{{ __('ui.swap_locations') }}">⇄</button>
@include('components.city-field',['name'=>'to','label'=>__('ui.to'),'cities'=>$cityDestinations,'required'=>true])
<label>{{ __('ui.departure_date') }}<input name="departure_date" type="date" required min="{{ now('Asia/Phnom_Penh')->format('Y-m-d') }}" max="{{ now('Asia/Phnom_Penh')->addDays(365)->format('Y-m-d') }}" value="{{ old('departure_date',request('departure_date',now('Asia/Phnom_Penh')->addDay()->format('Y-m-d'))) }}"></label>
<label>{{ __('ui.departure_time') }}<input name="departure_time" type="time" required value="{{ old('departure_time',request('departure_time','09:00')) }}"></label>
@if(request('type'))<input type="hidden" name="type" value="{{ request('type') }}">@endif
<button class="button" type="submit">{{ __('ui.get_price') }} @include('components.icon',['name'=>'arrow'])</button>
<script type="application/json" data-city-pairs>@json($cityPairs)</script>
</form>
