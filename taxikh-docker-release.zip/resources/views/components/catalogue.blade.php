@php($catalogueUrl=request()->routeIs('home')?route('home'):route('routes'))
@php($availableDestinations=$availableDestinations??$routes->getCollection()->flatMap(fn($t)=>[$t->text('destination'),$t->text('origin'),$t->text('title')])->filter()->unique()->values()->all())
<section class="container section" id="routes-catalogue" data-catalogue-root data-base-url="{{ $catalogueUrl }}">
<div class="section-heading"><div><span class="eyebrow">{{ __('ui.services') }}</span><h2>{{ __('ui.routes') }}</h2><p>{{ __('ui.popular_subtitle') }}</p></div><span class="result-count" data-catalogue-count>{{ trans_choice('taxikh.route_count',$routes->total(),['count'=>$routes->total()]) }}</span></div>
<nav class="category-tabs" aria-label="{{ __('ui.services') }}">@foreach([''=>__('ui.all_services'),'transfer'=>__('ui.transfer'),'airport'=>__('ui.airport'),'tour'=>__('ui.tour')] as $type=>$label)<a href="{{ $catalogueUrl.'?'.http_build_query(array_filter([...request()->except('page','type'),'type'=>$type],fn($v)=>$v!==null && $v!=='')) }}#routes-catalogue" @if((request('type')??'')===$type)aria-current="true"@endif data-catalogue-tab data-type="{{ $type }}">{{ $label }}</a>@endforeach</nav>
<form action="{{ $catalogueUrl }}#routes-catalogue" class="catalogue-toolbar" data-catalogue-form>
@foreach(request()->only(['from','to','departure_date','departure_time','type']) as $key=>$value)<input type="hidden" name="{{ $key }}" value="{{ $value }}">@endforeach
<div class="catalogue-query-wrap" data-catalogue-search-container>
    <label class="catalogue-query" for="catalogue-search-q">
        <span class="sr-only">{{ __('ui.search') }}</span>
        <div class="catalogue-search-field">
            <input id="catalogue-search-q" type="search" name="q" value="{{ request('q') }}" placeholder="{{ __('ui.search_placeholder') }}" maxlength="100" autocomplete="off" data-catalogue-search role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="catalogue-search-suggestions">
            <button type="button" class="catalogue-search-toggle" tabindex="-1" aria-label="{{ __('ui.search') }}" data-catalogue-search-arrow>
                <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/></svg>
            </button>
        </div>
    </label>
    <div id="catalogue-search-suggestions" class="city-options catalogue-dropdown" role="listbox" hidden>
        @foreach($availableDestinations as $dest)
            <div role="option" class="city-option" data-value="{{ $dest }}">{{ $dest }}</div>
        @endforeach
    </div>
</div>
<div class="catalogue-controls-row">
    <label class="catalogue-control-label"><span>{{ __('taxikh.sort_by') }}</span><select name="sort" data-catalogue-auto-submit>@foreach(['recommended','price_asc','price_desc','duration','name'] as $sort)<option value="{{ $sort }}" @selected(request('sort',setting('routes_sort','recommended'))===$sort)>{{ __('taxikh.sort_'.$sort) }}</option>@endforeach</select></label>
    <label class="catalogue-control-label"><span>{{ __('taxikh.display') }}</span><select name="layout" data-catalogue-auto-submit>@foreach(['grid','list'] as $layout)<option value="{{ $layout }}" @selected(request('layout',setting('routes_layout','grid'))===$layout)>{{ __('taxikh.'.$layout) }}</option>@endforeach</select></label>
    <div class="catalogue-actions-group">
        <button class="button small filter-action-btn" type="submit">{{ __('ui.filter') }}</button>
        <a class="text-link clear-filters-btn" href="{{ $catalogueUrl }}#routes-catalogue" data-clear-filters>{{ __('ui.clear_filters') }}</a>
    </div>
</div>
</form>
<div class="catalogue-results-shell" data-catalogue-results-shell>
    <div class="route-grid catalogue-grid columns-{{ (int)setting('routes_columns',3) }} layout-{{ request('layout',setting('routes_layout','grid')) }} list-cols-{{ (int)setting('routes_list_columns',2) }}" style="--route-columns:{{ max(2,min(5,(int)setting('routes_columns',3))) }}">
    @forelse($routes as $trip)@include('components.route-card')@empty<div class="empty-state"><h3>{{ __('ui.no_results') }}</h3><a class="button" href="{{ route('contact') }}">{{ __('ui.contact_support') }}</a></div>@endforelse
    </div>{{ $routes->links() }}
</div>
<script type="application/json" data-available-destinations>@json($availableDestinations)</script>
</section>
