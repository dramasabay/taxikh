@if($booking->dispatch_review)
<section class="panel padded dispatch-review">
    <span class="eyebrow">{{ __('ui.needs_dispatch') }}</span><h2>{{ __('ui.driver_return_request') }}</h2>
    <p class="preserve-lines">{{ $booking->dispatch_reason }}</p><small>{{ $booking->dispatch_requested_at?->timezone('Asia/Phnom_Penh')->format('d M Y H:i') }}</small>
    <p>{{ $booking->driver_id ? __('ui.review_active_help') : __('ui.reassign_first') }}</p>
    @if($booking->driver_id)
        <form method="post" action="{{ route('admin.booking.resolve',$booking->id) }}">
            @csrf<input type="hidden" name="dispatch_version" value="{{ $booking->dispatch_version }}">
            <label class="field">{{ __('ui.dispatch_note') }} *<textarea name="dispatch_note" rows="3" maxlength="1000" required>{{ old('dispatch_note') }}</textarea></label>
            <button type="submit" class="button outline full">{{ __('ui.keep_driver_resolve') }}</button>
        </form>
    @endif
</section>
@endif
