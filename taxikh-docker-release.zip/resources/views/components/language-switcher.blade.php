@php
    $languages = ['en' => ['EN', 'English', 'gb'], 'km' => ['KH', 'ខ្មែរ', 'kh'], 'zh' => ['中文', '中文', 'cn']];
    $currentLanguage = $languages[app()->getLocale()] ?? $languages['en'];
@endphp
<div class="language-menu" data-language-menu>
    <button type="button" class="language-trigger" data-toggle="language-options" aria-controls="language-options" aria-expanded="false" aria-label="{{ __('ui.language') }}: {{ $currentLanguage[1] }}">
        <img class="language-flag" src="{{ asset('assets/flags/'.$currentLanguage[2].'.svg') }}" width="24" height="16" alt="">
        <span>{{ $currentLanguage[0] }}</span><svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="m3 4.5 3 3 3-3" stroke="currentColor" stroke-width="1.5"/></svg>
    </button>
    <nav id="language-options" class="language-options" aria-label="{{ __('ui.language') }}">
        @foreach($languages as $language => [$short, $label, $flag])
            @php
                $segments = request()->segments();
                $segments[0] = $language;
                $languageUrl = ($staff ?? false) ? route('staff.language', $language) : url(implode('/', $segments)).(request()->getQueryString() ? '?'.request()->getQueryString() : '');
            @endphp
            <a href="{{ $languageUrl }}" lang="{{ $language }}" hreflang="{{ $language }}" @if(app()->getLocale() === $language)aria-current="true"@endif>
                <img class="language-flag" src="{{ asset('assets/flags/'.$flag.'.svg') }}" width="24" height="16" alt=""><span>{{ $label }}</span><small>{{ $short }}</small>
            </a>
        @endforeach
    </nav>
</div>
