@php($indexable=setting('seo_indexable','0')==='1' && !request()->routeIs('booking.show'))
<meta name="robots" content="{{ $indexable?'index, follow':'noindex, nofollow' }}">
@if(!request()->routeIs('booking.show'))
@php($canonical=seo_base_url().request()->getPathInfo())
<link rel="canonical" href="{{ $canonical }}">
@foreach(['en'=>'en','km'=>'km','zh'=>'zh-CN'] as $lang=>$hreflang)<link rel="alternate" hreflang="{{ $hreflang }}" href="{{ seo_base_url().preg_replace('~^/(en|km|zh)(?=/|$)~','/'.$lang,request()->getPathInfo()) }}">@endforeach
<meta property="og:type" content="website"><meta property="og:site_name" content="{{ setting('brand_name') }}"><meta property="og:title" content="{{ $title??setting('seo_title_'.app()->getLocale(),__('ui.private_rides')) }} · {{ setting('brand_name') }}"><meta property="og:description" content="{{ $description??setting('seo_description_'.app()->getLocale(),setting('tagline_en')) }}"><meta property="og:url" content="{{ $canonical }}"><meta property="og:image" content="{{ seo_base_url().'/demo/taxi-hero-v2.png' }}"><meta name="twitter:card" content="summary_large_image">
@php($schema=['@context'=>'https://schema.org','@type'=>'TaxiService','name'=>setting('brand_name'),'url'=>seo_base_url(),'areaServed'=>['@type'=>'Country','name'=>'Cambodia'],'provider'=>array_filter(['@type'=>'Organization','name'=>setting('brand_name'),'url'=>seo_base_url(),'logo'=>seo_base_url().'/assets/taxikh-logo.svg','telephone'=>setting('phone'),'email'=>setting('email')])])
<script type="application/ld+json">{!! json_encode($schema,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) !!}</script>
@endif
