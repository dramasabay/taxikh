<!doctype html>
<html lang="{{ app()->getLocale() }}" data-default-theme="{{ setting('default_theme','system') }}">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? setting('seo_title_'.app()->getLocale(),__('ui.private_rides')) }} · {{ setting('brand_name','TAXIKH') }}</title>
    <meta name="description" content="{{ $description ?? setting('seo_description_'.app()->getLocale(),setting('tagline_'.app()->getLocale(),setting('tagline_en'))) }}">
    <link rel="icon" href="{{ asset('assets/taxikh-icon.svg') }}" type="image/svg+xml">
    @include('components.theme-head')
    @include('components.seo')
    @stack('head')
</head>
<body class="public-body {{ request()->routeIs('route.detail')?'booking-page':'' }}">
<a class="skip-link" href="#main">{{ __('ui.skip_content') }}</a>
<header class="site-header"><div class="container header-inner">
    <a class="brand" href="{{ route('home') }}">
        @if(setting('logo_path'))
            <img src="{{ media_url(setting('logo_path')) }}" alt="{{ setting('brand_name') }}">
        @else
            @include('components.brand-mark')
        @endif
        <span>{{ setting('brand_name') }}<small>{{ setting('tagline_'.app()->getLocale(),setting('tagline_en')) }}</small></span>
    </a>
    <nav id="main-nav" class="main-nav" aria-label="{{ __('ui.menu') }}">@foreach($siteContent->get('menu',collect()) as $link)<a href="{{ local_link($link->link) }}" @if(url()->current()===local_link($link->link))aria-current="page"@endif>{{ $link->text('title') }}</a>@endforeach @auth<a class="mobile-only-link" href="{{ route(auth()->user()->role==='driver'?'driver.home':'admin.home') }}">{{ __('ui.dashboard') }}</a>@endauth</nav>
    <div class="header-actions">
        @include('components.language-switcher')
        @include('components.theme-toggle')
        @auth
            <a class="button small outline staff-top" href="{{ route(auth()->user()->role==='driver'?'driver.home':'admin.home') }}">@include('components.icon',['name'=>'dashboard']) <span>{{ __('ui.dashboard') }}</span></a>
        @endauth
        <a class="button small contact-top" href="{{ route('contact') }}">{{ __('ui.support') }}</a>
        <button type="button" class="icon-button mobile-toggle" data-toggle="main-nav" aria-controls="main-nav" aria-expanded="false" aria-label="{{ __('ui.menu') }}">@include('components.icon',['name'=>'menu'])</button>
    </div>
</div></header>
<main id="main">@yield('content')</main>
<footer class="site-footer"><div class="container"><div class="footer-top">
    <div><a class="brand" href="{{ route('home') }}">@include('components.brand-mark')<span>{{ setting('brand_name') }}</span></a><p>{{ setting('footer_note_'.app()->getLocale(),setting('footer_note_en')) }}</p><span class="pill">@include('components.icon',['name'=>'cash']) {{ __('ui.cash_on_arrival') }}</span>@if(google_reviews_link())<a class="footer-reviews" href="{{ google_reviews_link() }}" target="_blank" rel="noopener noreferrer">{{ __('ui.read_google_reviews') }} ↗</a>@endif</div>
    <div><h3>{{ __('ui.services') }}</h3>@foreach($siteContent->get('menu',collect()) as $link)<a href="{{ local_link($link->link) }}">{{ $link->text('title') }}</a>@endforeach</div>
    <div><h3>{{ __('ui.about') }}</h3>@foreach($siteContent->get('footer',collect()) as $link)<a href="{{ local_link($link->link) }}">{{ $link->text('title') }}</a>@endforeach</div>
    <div><h3>{{ __('ui.contact') }}</h3>@if(setting('phone'))<a href="tel:{{ preg_replace('/[^+0-9]/','',setting('phone')) }}">{{ setting('phone') }}</a>@endif @if(setting('email'))<a href="mailto:{{ setting('email') }}">{{ setting('email') }}</a>@endif<p>{{ setting('address_'.app()->getLocale()) }}</p><a href="{{ route('contact') }}">{{ __('ui.contact_support') }} ↗</a></div>
</div><div class="footer-bottom"><span>© {{ date('Y') }} {{ setting('brand_name') }}</span><span>English · ខ្មែរ · 中文</span></div></div></footer>
<nav class="mobile-app-nav" aria-label="{{ __('ui.mobile_navigation') }}">
    <a href="{{ route('home') }}" @if(request()->routeIs('home'))aria-current="page"@endif><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 10 9-7 9 7v11h-6v-7H9v7H3Z"/></svg><span>{{ __('ui.home') }}</span></a>
    <a href="{{ route('routes') }}" @if(request()->routeIs('routes','route.detail','booking.show'))aria-current="page"@endif>@include('components.icon',['name'=>'car'])<span>{{ __('ui.booking') }}</span></a>
    <a href="{{ route('contact') }}" @if(request()->routeIs('contact','faq','partners'))aria-current="page"@endif><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 14v-3a9 9 0 0 1 18 0v3M3 12h3v7H3ZM18 12h3v7h-3ZM20 19c0 3-4 3-8 3"/></svg><span>{{ __('ui.support') }}</span></a>
</nav>
<div class="support-strip"><a class="support-contact" href="{{ route('contact') }}">@include('components.icon',['name'=>'mail']) <span>{{ __('ui.contact_support') }}</span></a>@include('components.social-icons')</div>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
<script type="application/json" id="ui-text">@php($uiText=['loading'=>__('ui.loading'),'processing'=>__('ui.processing'),'error'=>__('ui.request_error'),'network'=>__('ui.network_error'),'session_expired'=>__('ui.session_expired'),'too_many_requests'=>__('ui.too_many_requests'),'server_error'=>__('ui.server_error'),'signin_required'=>__('ui.signin_required'),'price_loading'=>__('ui.price_loading'),'copied'=>__('ui.copied')])@json($uiText)</script>
<script type="application/json" id="google-config">@php($googleConfig=['key'=>setting('google_maps_api_key'),'maps'=>setting('google_maps_enabled','0')==='1','reviews'=>false,'placeId'=>setting('google_place_id'),'language'=>app()->getLocale()==='zh'?'zh-CN':app()->getLocale(),'messages'=>collect(['location_searching','location_unavailable','location_empty','location_selected','location_denied','location_locating','location_not_supported','location_from_gps','review_count','read_google_review','reviews_order','translated_review'])->mapWithKeys(fn($key)=>[$key=>__('ui.'.$key)])->all()])@json($googleConfig)</script>
<script src="{{ ride_asset('assets/app.js') }}" defer></script>
@if(request()->routeIs('route.detail'))<script src="{{ ride_asset('assets/google.js') }}" defer></script>@endif
<script type="application/json" id="taxikh-text">@php($taxikhText=['choose_city'=>__('taxikh.choose_city'),'choose_route_city'=>__('taxikh.choose_route_city')])@json($taxikhText)</script><script src="{{ ride_asset('assets/taxikh.js') }}" defer></script>
@stack('scripts')
</body></html>
