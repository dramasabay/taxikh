@extends('layouts.public')
@section('content')
@foreach(array_filter(explode(',',setting('home_sections','hero,search,routes,benefits,fleet,guides,faq,reviews'))) as $section)
@if($section==='routes')@include('components.catalogue')
@elseif(in_array($section,['hero','search','benefits','fleet','guides','faq','reviews']))@include('components.home-'.$section)@endif
@endforeach
@endsection
