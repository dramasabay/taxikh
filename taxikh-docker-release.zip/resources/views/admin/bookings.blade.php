@extends('layouts.admin',['title'=>__('ui.bookings')])
@section('content')<div class="admin-heading"><div><span class="eyebrow">{{ __('ui.manage') }}</span><h1>{{ __('ui.bookings') }}</h1></div>@if(auth()->user()->role!=='driver')<a class="button outline" href="{{ route('admin.bookings.export',request()->query()) }}">@include('components.icon',['name'=>'download']) {{ __('ui.export') }} CSV</a>@endif</div>
<nav class="booking-status-tabs" aria-label="{{ __('ui.status') }}">
    <a href="{{ route((auth()->user()->role==='driver'?'driver':'admin').'.bookings', request()->except('status', 'page')) }}" class="pill-badge {{ !request('status') ? 'active' : '' }}">{{ __('ui.all_statuses') }}</a>
    @foreach(\App\Models\Booking::STATUSES as $s)
        <a href="{{ route((auth()->user()->role==='driver'?'driver':'admin').'.bookings', array_merge(request()->except('page'), ['status' => $s])) }}" class="pill-badge {{ request('status') === $s ? 'active' : '' }}">{{ __('ui.'.$s) }}</a>
    @endforeach
</nav>
<form class="admin-filters" method="get"><input name="q" value="{{ request('q') }}" placeholder="{{ __('ui.reference') }} / {{ __('ui.customer') }} / {{ __('ui.phone') }}" aria-label="{{ __('ui.search') }}"><select name="status" aria-label="{{ __('ui.status') }}"><option value="">{{ __('ui.all_statuses') }}</option>@foreach(\App\Models\Booking::STATUSES as $s)<option value="{{ $s }}" @selected(request('status')===$s)>{{ __('ui.'.$s) }}</option>@endforeach</select><input type="date" name="date" value="{{ request('date') }}" aria-label="{{ __('ui.departure_date') }}">@if(auth()->user()->role!=='driver')<label class="check-label dispatch-filter"><input type="checkbox" name="dispatch_review" value="1" @checked(request()->boolean('dispatch_review'))>{{ __('ui.needs_dispatch') }}</label>@endif<button class="button dark">{{ __('ui.filter') }}</button></form><section class="panel">@include('components.booking-table')</section>{{ $bookings->links() }}@endsection

