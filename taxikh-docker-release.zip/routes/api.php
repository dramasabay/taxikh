<?php

use App\Http\Controllers\BookingController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->middleware('locale')->group(function () {
    Route::get('/catalog', [BookingController::class, 'catalog'])->middleware('throttle:quote');
    Route::post('/quote', [BookingController::class, 'quote'])->middleware('throttle:quote');
    // Public guest creation, rate-limited; price and capacity always validated on the server.
    Route::post('/bookings', [BookingController::class, 'store'])->middleware('throttle:booking');
});
