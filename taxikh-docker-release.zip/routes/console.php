<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('ride:recover-notifications')->everyFiveMinutes()->withoutOverlapping();
