<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\ResourceController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\SystemController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect('/'.setting('default_language', 'en')));
Route::get('/robots.txt', [PublicController::class, 'robots']);
Route::get('/sitemap.xml', [PublicController::class, 'sitemap']);
Route::get('/media/{path}', [PublicController::class, 'media'])->where('path', '.*');
Route::middleware('locale')->group(function () {
    Route::get('/staff/login', [AuthController::class, 'form'])->name('login');
    Route::post('/staff/login', [AuthController::class, 'login'])->middleware('throttle:login');
    Route::post('/staff/logout', [AuthController::class, 'logout'])->name('logout');
    Route::middleware(['staff:admin,dispatcher,driver', 'auth.session'])->group(function () {
        Route::get('/staff/language/{locale}', [AuthController::class, 'language'])->name('staff.language');
        Route::get('/staff/alerts', [DashboardController::class, 'alerts'])->name('staff.alerts');
        Route::post('/staff/alerts/read', [DashboardController::class, 'readAlerts'])->name('staff.alerts.read');
        Route::view('/staff/profile', 'admin.profile')->name('staff.profile');
        Route::post('/staff/password', [AuthController::class, 'password'])->middleware('throttle:password')->name('staff.password');
    });
    Route::prefix('admin')->name('admin.')->middleware(['staff:admin,dispatcher', 'auth.session'])->group(function () {
        Route::get('/', [DashboardController::class, 'home'])->name('home');
        Route::get('/bookings', [DashboardController::class, 'bookings'])->name('bookings');
        Route::get('/bookings/export', [DashboardController::class, 'export'])->name('bookings.export');
        Route::get('/bookings/{booking}', [DashboardController::class, 'show'])->whereNumber('booking')->name('booking');
        Route::patch('/bookings/{booking}', [DashboardController::class, 'update'])->whereNumber('booking')->name('booking.update');
        Route::post('/bookings/{booking}/resolve-dispatch', [DashboardController::class, 'resolveDispatch'])->whereNumber('booking')->name('booking.resolve');
        Route::get('/inquiries', [DashboardController::class, 'inquiries'])->name('inquiries');
        Route::patch('/inquiries/{inquiry}', [DashboardController::class, 'inquiry'])->name('inquiry.update');
        Route::get('/notifications', [DashboardController::class, 'notifications'])->name('notifications');
        Route::post('/notifications/{delivery}/retry', [DashboardController::class, 'retry'])->name('notification.retry');
        Route::get('/reports', [DashboardController::class, 'reports'])->name('reports');
        Route::middleware('staff:admin')->group(function () {
            Route::get('/system', [SystemController::class, 'index'])->name('system');
            Route::get('/system/backups/{file}', [SystemController::class, 'download'])->name('system.download');
            Route::post('/system/backup', [SystemController::class, 'backup'])->middleware('throttle:system-tools')->name('system.backup');
            Route::post('/system/restore', [SystemController::class, 'restore'])->middleware('throttle:system-tools')->name('system.restore');
            Route::post('/system/clear', [SystemController::class, 'clear'])->middleware('throttle:system-tools')->name('system.clear');
            Route::post('/system/maintenance', [SystemController::class, 'maintenance'])->name('system.maintenance');
            Route::get('/settings', [SettingsController::class, 'index'])->name('settings');
            Route::post('/settings', [SettingsController::class, 'save'])->name('settings.save');
            Route::get('/manage/{resource}', [ResourceController::class, 'index'])->name('resource.index');
            Route::get('/manage/{resource}/create', [ResourceController::class, 'create'])->name('resource.create');
            Route::post('/manage/{resource}/arrange', [ResourceController::class, 'arrange'])->name('resource.arrange');
            Route::delete('/manage/{resource}/{id}', [ResourceController::class, 'destroy'])->middleware('throttle:system-tools')->whereNumber('id')->name('resource.destroy');
            Route::post('/manage/{resource}', [ResourceController::class, 'store'])->name('resource.store');
            Route::get('/manage/{resource}/{id}/edit', [ResourceController::class, 'edit'])->whereNumber('id')->name('resource.edit');
            Route::put('/manage/{resource}/{id}', [ResourceController::class, 'update'])->whereNumber('id')->name('resource.update');
            Route::post('/manage/{resource}/{id}/archive', [ResourceController::class, 'archive'])->whereNumber('id')->name('resource.archive');
        });
    });
    Route::prefix('driver')->name('driver.')->middleware(['staff:driver', 'auth.session'])->group(function () {
        Route::get('/', [DashboardController::class, 'home'])->name('home');
        Route::get('/bookings', [DashboardController::class, 'bookings'])->name('bookings');
        Route::get('/bookings/{booking}', [DashboardController::class, 'show'])->whereNumber('booking')->name('booking');
        Route::patch('/bookings/{booking}', [DashboardController::class, 'update'])->whereNumber('booking')->name('booking.update');
        Route::post('/bookings/{booking}/action', [DashboardController::class, 'driverAction'])->whereNumber('booking')->name('booking.action');
    });
});
Route::prefix('{locale}')->where(['locale' => 'en|km|zh'])->middleware('locale')->group(function () {
    Route::get('/', [PublicController::class, 'home'])->name('home');
    Route::get('/booking', [PublicController::class, 'startBooking'])->name('booking.start');
    Route::get('/routes', [PublicController::class, 'routes'])->name('routes');
    Route::get('/routes/{slug}', [PublicController::class, 'detail'])->name('route.detail');
    Route::get('/fleet', [PublicController::class, 'fleet'])->name('fleet');
    Route::get('/guides', [PublicController::class, 'guides'])->name('guides');
    Route::get('/guides/{slug}', [PublicController::class, 'article'])->name('guide');
    Route::get('/page/{slug}', [PublicController::class, 'page'])->name('page');
    Route::get('/faq', [PublicController::class, 'faq'])->name('faq');
    Route::get('/contact', [PublicController::class, 'contact'])->name('contact');
    Route::get('/partners', [PublicController::class, 'partners'])->name('partners');
    Route::post('/inquiry', [PublicController::class, 'inquiry'])->middleware('throttle:inquiry')->name('inquiry');
    Route::post('/booking', [BookingController::class, 'store'])->middleware('throttle:booking')->name('booking.store');
    Route::get('/reservation/{token}', [BookingController::class, 'show'])->middleware('throttle:quote')->name('booking.show');
});
